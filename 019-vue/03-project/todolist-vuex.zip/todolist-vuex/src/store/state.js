
//唯一数据源
export default {
    todos:[
        {
            task:'吃饭',
            done:true
        },
        {
            task:'睡觉',
            done:false
        },
        {
            task:'打豆豆',
            done:false
        },                             
    ]
}