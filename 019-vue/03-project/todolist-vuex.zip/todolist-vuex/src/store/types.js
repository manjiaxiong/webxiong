/*
* @Author: TomChen
* @Date:   2019-09-03 19:59:22
* @Last Modified by:   TomChen
* @Last Modified time: 2019-09-03 20:02:17
*/
export const ADD_TODO = 'addTodo'
export const DEL_TODO = 'delTodo'
export const SELECT_ALL_TODO = 'select_All_Todo'
export const DEL_ALL_TODO = 'del_All_Todo'