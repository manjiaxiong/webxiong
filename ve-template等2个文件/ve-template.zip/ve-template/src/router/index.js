// 模板页面静态页面
export default [
  {
    path: "/home",
    component: () => import("@/views/dashboard/index")
  }
];
