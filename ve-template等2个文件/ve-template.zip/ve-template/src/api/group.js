import request from "ve-framework/utils/request";

/**
 * 用户数据权限接口
 */

// 获取用户的数据权限树列表
export function apiPurviewsGet(params, data = {}) {
  return request({
    // url: `/purviews/data`,
    url: `/purviews`,
    method: "get",
    params,
  });
}

// 保存用户的数据权限
export function apiPurviewsSave(params, data = {}) {
  return request({
    url: `/purviews`,
    method: "put",
    params,
    data
  });
}
