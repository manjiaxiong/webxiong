export default {
  app: {
    title: 'Web Template'
  },
  home: {
    document: 'Document'
  }
};
