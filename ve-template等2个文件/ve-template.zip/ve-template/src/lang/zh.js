export default {
  app: {
    title: 'web前端模板'
  },
  home: {
    document: '文档'
  }
};
