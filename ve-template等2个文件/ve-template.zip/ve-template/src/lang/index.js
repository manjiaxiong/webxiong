import enLocale from "./en";
import zhLocale from "./zh";

export default {
  en: {
    ...enLocale,
  },
  zh: {
    ...zhLocale,
  }
};
