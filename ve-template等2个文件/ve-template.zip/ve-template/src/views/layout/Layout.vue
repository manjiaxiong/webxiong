<template>
  <layout>
    <!-- 此处可自定义整个头部导航栏 -->
    <!-- <template slot="navbar">
			可自定义整个头部导航栏
    </template>-->

    <!-- 此处可新增头部右侧的内容 -->
    <template slot="right-menu"> </template>

    <!-- 此处可新增头部坐侧的LOGO -->
    <template slot="logo">
      <img class="logo" src="@/assets/img/logo.png" alt="" />
    </template>
    <template slot="title">
      {{ $t("app.title") }}
    </template>

    <!-- 此处可自定义尾部的内容 -->
    <!-- <template #footer>
      我是尾部
    </template>-->
  </layout>
</template>

<script>
import Layout from "ve-framework/views/layout/Layout";

export default {
  components: {
    Layout
  },
  data() {
    return {};
  },

  methods: {}
};
</script>
<style lang="scss" scoped>
.logo {
  margin-right: 10px;
}
</style>
