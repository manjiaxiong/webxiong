<template>
  <div class="login-container">
    <div class="login-weaper animated bounceInDown" style="z-index: 100">
      <div class="login-left">
        <div class="login-time">
          {{ time }}
        </div>
        <el-image class="size" :src="require('./imgs/login.png')"> </el-image>
      </div>
      <div class="login-border">
        <div class="login-main">
          <h4 class="login-title">登录</h4>
          <h3 class="login-sub-title">请使用账号密码登录</h3>
          <el-form
            ref="loginForm"
            :model="loginForm"
            :rules="loginRules"
            auto-complete="on"
            label-position="left"
            style="margin-top: 40px"
          >
            <div class="form_inline">
              <el-form-item prop="username">
                <span class="svg-container">
                  <i class="iconfont">&#xe645;</i>
                </span>
                <el-input
                  v-model="loginForm.username"
                  placeholder="用户名"
                  name="username"
                  type="text"
                  auto-complete="on"
                  class="user_txt"
                />
              </el-form-item>
            </div>
            <div class="form_inline">
              <el-form-item prop="password">
                <span class="svg-container">
                  <i class="iconfont">&#xe672;</i>
                </span>
                <el-input
                  v-model="loginForm.password"
                  :type="passwordType"
                  placeholder="密码"
                  name="password"
                  auto-complete="off"
                />
                <span class="show-pwd" @click="showPwd">
                  <i
                    class="iconfont"
                    v-html="
                      passwordType === 'password' ? '&#xe60c;' : '&#xe61b;'
                    "
                  />
                </span>
              </el-form-item>
            </div>

            <div class="form_inline" v-if="$config.captcha">
              <el-form-item prop="verify">
                <el-input
                  v-model="loginForm.verify"
                  placeholder="验证码"
                  name="verify"
                  class="verify-warp"
                  auto-complete="on"
                  @keyup.enter.native="handleLogin"
                />
                <img
                  v-if="captchaData"
                  :src="captchaData"
                  @click="renderCaptcha"
                  alt
                />
              </el-form-item>
            </div>

            <div class="form_inline">
              <el-button
                :loading="loading"
                type="primary"
                class="btn"
                style="width: 100%; margin-bottom: 30px"
                @click.native.prevent="handleLogin"
                >登录</el-button
              >
            </div>
          </el-form>
        </div>
        <el-image class="right" :src="require('./imgs/right.png')"></el-image>
      </div>
    </div>
  </div>
</template>

<script>
import dayjs from "dayjs";
import { jcaptcha } from "ve-framework/api/login";
export default {
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!value) {
        callback(new Error("请输入正确的用户名"));
      } else {
        callback();
      }
    };
    const validatePassword = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error("密码不能小于6位"));
      } else {
        callback();
      }
    };
    return {
      time: "",
      logo: "",
      loading: false,
      captchaData: "",
      __token: "",
      loginForm: {
        username: "13783698404",
        password: "tmkj@zgb123",
        verify: ""
      },
      loginRules: {
        username: [
          { required: true, trigger: "blur", validator: validateUsername }
        ],
        password: [
          { required: true, trigger: "blur", validator: validatePassword }
        ],
        verify: [{ required: true, trigger: "blur", message: "验证码不能为空" }]
      },
      passwordType: "password",
      loading: false,
      redirect: null
    };
  },
  created() {
    this.renderCaptcha();
    this.getTime();
    setInterval(() => {
      this.getTime();
    }, 1000);
  },
  watch: {
    $route: {
      handler(route) {
        this.redirect = route.query && route.query.redirect;
      },
      immediate: true
    }
  },
  methods: {
    getTime() {
      this.time = dayjs(new Date()).format("YYYY-MM-DD HH:mm:ss");
    },
    showPwd() {
      if (this.passwordType === "password") {
        this.passwordType = "text";
      } else {
        this.passwordType = "password";
      }
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true;
          var params = Object.assign(
            { loginUrl: "/login", __token: this.__token },
            this.loginForm
          );
          this.$store
            .dispatch("LoginByUsername", params)
            .then(() => {
              this.loading = false;
              this.$router.push({
                path: this.$config.multiSystem ? "/home" : "/"
              });
              // this.$router.push({ path: this.redirect && this.redirect !== "/" ? this.redirect : "/" });
            })
            .catch(() => {
              this.renderCaptcha();
              this.loading = false;
            });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    renderCaptcha() {
      if (this.$config.captcha) {
        jcaptcha().then(data => {
          if (data) {
            const { __token, verify } = data;
            if (__token && verify) {
              this.captchaData = "data:image/jpeg;base64," + verify;
              this.__token = __token;
            }
          }
        });
      }
    }
  }
};
</script>

<style lang="scss">
@import "./scss/login.scss";
.h1 {
  position: relative;
}
</style>

<style lang="scss" scoped>
.verify-warp {
  width: 210px !important;
}
.verify-warp + img {
  vertical-align: middle;
}
.login-container {
  color: #60a2ee;
  font-family: "microsoft yahei";
  font-size: 14px;
  line-height: 1.5;
  background-repeat: no-repeat;
  background-position: center center;
  background-size: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.box {
  width: 1150px;
  height: 550px;
}
.left {
  width: 657px;
  float: left;
}
.right {
  width: 480px;
  float: right;
}
.right .logo {
  width: 100%;
  text-align: center;
  color: #fff;
  font-size: 30px;
  height: 50px;
}
.right .form {
  width: 480px;
  height: 470px;
  position: relative;
}
.right .form .form_tit {
  width: 100%;
  text-align: center;
  color: #fff;
  font-size: 18px;
  height: 40px;
  padding-top: 50px;
}
.right .form .form_error {
  width: 280px;
  margin: 0 auto;
  color: #f00;
}
.right .form .form_inline {
  width: 280px;
  height: 42px;
  margin: 0 auto;
  margin-top: 30px;
}
.right .form .form_inline input[type="text"] {
  width: 280px;
  height: 40px;
  border: 1px solid #73a0cf;
  border-radius: 6px;
  // background-color: rgba(154, 194, 237, 0.3);
  outline: none;
  text-indent: 36px;
}

.right .form .btn {
  margin-top: 10px;
  width: 280px;
  height: 40px;
  border-width: 0;
  border-radius: 6px;
  // background: linear-gradient(#2a8dfd, #284eda);
  color: #fff;
  font-size: 18px;
  outline: none;
}
.right .form .form_tips {
  position: absolute;
  bottom: 60px;
  left: 40px;
}
.right .form .form_tips a {
  display: inline-block;
  width: 30px;
  vertical-align: middle;
}
.foot {
  position: fixed;
  bottom: 8px;
  left: 0;
  width: 100%;
  text-align: center;
}
</style>
<style rel="stylesheet/scss" lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #eee;
$cursor: #fff;

/* reset element-ui css */
.login-container {
  .el-input {
    display: inline-block;
    height: 47px;
    width: 85%;
    input {
      border: 0px;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      height: 47px;
    }
  }
}
</style>

<style rel="stylesheet/scss" lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_gray: #eee;

.login-container {
  min-height: 100%;
  width: 100%;
  // background-color: $bg;
  overflow: hidden;
  .login-form {
    position: relative;
    width: 520px;
    max-width: 100%;
    padding: 160px 35px 0;
    margin: 0 auto;
    overflow: hidden;
  }
  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;
    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }
  .svg-container {
    padding: 6px 5px 6px 15px;
    color: $dark_gray;
    vertical-align: middle;
    width: 30px;
    display: inline-block;
  }
  .title-container {
    position: relative;
    .title {
      font-size: 26px;
      color: $light_gray;
      margin: 0px auto 40px auto;
      text-align: center;
      font-weight: bold;
    }
    .set-language {
      color: #fff;
      position: absolute;
      top: 3px;
      font-size: 18px;
      right: 0px;
      cursor: pointer;
    }
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
  .thirdparty-button {
    position: absolute;
    right: 0;
    bottom: 6px;
  }
}
</style>
