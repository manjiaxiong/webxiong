<template>
  <dashboard class="dashboard" ref="dashboard">
    <div class="wrapper">
      <div class="header">
        <div class="item">
          <icon content="fa-user-o" :size="16" color="#fff" />
          <span>{{ userName ? userName + "，" : "" }}您好</span>
        </div>
        <div class="item" @click="logout">
          <icon content="fa-sign-out" :size="18" color="#fff" />
          <span>退出</span>
        </div>
      </div>
      <div class="main">
        <div class="title">前端模板服务平台</div>
        <div class="menu-box">
          <div
            :key="item.id"
            class="item"
            :class="'board' + (key + 1)"
            v-for="(item, key) in menuList"
            @click="$refs.dashboard.toPage(item)"
          >
            <div class="wrapper">
              <icon :content="item.ico" :size="48" color="#fff" />
              <span>{{ item.name }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </dashboard>
</template>

<script>
/**
 * 案例页面，根据项目需要进行重写
 */
import Dashboard from "ve-framework/views/home";
import { getToken } from "ve-framework/utils/auth";
import { getResource } from "ve-framework/api/resource";
export default {
  components: {
    Dashboard
  },
  data() {
    return {
      menuList: [],
      userName: ""
    };
  },
  methods: {
    logout() {
      this.$store.dispatch("FedLogOut").then(() => {
        this.$router.push("/login");
      });
    }
  },
  mounted() {
    const token = getToken();
    if (token) {
      const data = JSON.parse(token);
      if (data && data.props && data.props.nickname) {
        this.userName = data.props.nickname;
      }
    }
    const data = this.$config.multiSystem;
    if (data) {
      if (data.subSystems && data.subSystems.length) {
        this.menuList = data.subSystems;
      } else {
        getResource({ level: 0 }).then(data => {
          if (Array.isArray(data)) {
            this.menuList = data;
          }
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.menu-box {
  display: flex;
  height: 600px;
  flex-wrap: wrap;
  .item {
    display: block;
    width: 200px;
    height: 100px;
    margin: 5px;
    background: #fff;
    height: 100px;
    cursor: pointer;
  }
}
.dashboard {
  user-select: none;
  width: 100%;
  height: 100%;
  background: url("./img/4.jpg") no-repeat center center;
  background-size: cover;

  > .wrapper {
    height: 100%;
    position: relative;
    overflow: hidden;
    margin: 0 8%;

    .main {
      width: 100%;
      position: absolute;
      top: 50%;
      transform: translateY(-68%);
    }
  }
  .header {
    position: absolute;
    top: 20px;
    right: 0;
    display: flex;
    z-index: 999;

    .item {
      margin-left: 30px;
      display: flex;
      align-items: center;
      cursor: pointer;
      opacity: 0.75;
      &:hover {
        opacity: 0.95;
      }
      span {
        padding-left: 6px;
        color: #fff;
        font-size: 14px;
      }
    }
  }

  .title {
    color: #fff;
    font-size: 36px;
    text-align: center;
    margin-top: 120px;
  }

  .board {
    margin-top: 88px;
    display: grid;
    grid-template-columns: repeat(50, 1fr);
    grid-template-rows: 126px 126px;
    grid-gap: 16px;
    .item {
      border-radius: 6px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      background-position: 0 0;
      background-repeat: no-repeat;
      // background-size: 100% 100%;
      background-size: cover;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.4);
      opacity: 0.9;
      // transition: opacity margin 10s;
      margin: 1px;
      &:hover {
        box-shadow: 0 0 16px rgba(0, 0, 0, 0.4);
        opacity: 1;
        margin: 0;
      }
      .wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        span {
          line-height: 1.2;
          padding-top: 15px;
          color: #fff;
          font-size: 18px;
        }
      }
    }
    .board1 {
      background-image: url("./img/1.png");
      grid-column: 1/12;
      grid-row: 1/3;
    }
    .board2 {
      background-image: url("./img/2.png");
      grid-column: 12/28;
      grid-row: 1/2;
    }

    &.count4 {
      .board3 {
        background-image: url("./img/3.png");
        grid-column: 28/51;
        grid-row: 1/2;
      }
      .board4 {
        background-image: url("./img/6.png");
        grid-column: 12/51;
        grid-row: 2/2;
      }
    }

    &.count5 {
      .board3 {
        background-image: url("./img/3.png");
        grid-column: 28/51;
        grid-row: 1/2;
      }
      .board4 {
        background-image: url("./img/4.png");
        grid-column: 12/34;
        grid-row: 2/2;
      }
      .board5 {
        background-image: url("./img/5.png");
        grid-column: 34/51;
        grid-row: 2/2;
      }
    }

    &.count6 {
      .board3 {
        background-image: url("./img/3.png");
        grid-column: 28/51;
        grid-row: 1/2;
      }
      .board4 {
        background-image: url("./img/4.png");
        grid-column: 12/23;
        grid-row: 2/2;
      }
      .board5 {
        background-image: url("./img/5.png");
        grid-column: 23/39;
        grid-row: 2/2;
      }
      .board6 {
        background-image: url("./img/8.png");
        grid-column: 39/51;
        grid-row: 2/2;
      }
    }

    &.count7 {
      .board3 {
        background-image: url("./img/3.png");
        background-position: right center;
        grid-column: 28/39;
        grid-row: 1/2;
      }
      .board4 {
        background-image: url("./img/1.png");
        background-position: center bottom;
        grid-column: 39/51;
        grid-row: 1/2;
      }
      .board5 {
        background-image: url("./img/4.png");
        grid-column: 12/23;
        grid-row: 2/2;
      }
      .board6 {
        background-image: url("./img/5.png");
        grid-column: 23/39;
        grid-row: 2/2;
      }
      .board7 {
        background-image: url("./img/8.png");
        grid-column: 39/51;
        grid-row: 2/2;
      }
    }

    &.count8 {
      .board3 {
        background-image: url("./img/3.png");
        background-position: right center;
        grid-column: 28/39;
        grid-row: 1/2;
      }
      .board4 {
        background-image: url("./img/1.png");
        background-position: center bottom;
        grid-column: 39/51;
        grid-row: 1/2;
      }
      .board5 {
        background-image: url("./img/4.png");
        grid-column: 12/22;
        grid-row: 2/2;
      }
      .board6 {
        background-image: url("./img/5.png");
        grid-column: 22/32;
        grid-row: 2/2;
      }
      .board7 {
        background-image: url("./img/7.png");
        grid-column: 32/42;
        grid-row: 2/2;
      }
      .board8 {
        background-image: url("./img/8.png");
        grid-column: 42/51;
        grid-row: 2/2;
      }
    }
  }
}
</style>
