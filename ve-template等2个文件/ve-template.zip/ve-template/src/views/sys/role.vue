<template>
  <role />
</template>

<script>
import Role from "ve-framework/views/sys/role";
export default {
  name: "sys-role",
  components: {
    Role
  }
};
</script>
