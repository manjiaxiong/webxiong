<template>
  <page />
</template>

<script>
import Page from "ve-framework/views/sys/config";
export default {
  name: "sys-config",
  components: {
    Page
  }
};
</script>
