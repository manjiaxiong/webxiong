<template>
  <page
    :dialogMaps="dialogMaps"
    :buttonsPrepend="buttons"
    :operationWidth="280"
  />
</template>

<script>
import groupPermission from "./dialog/permission";
import Page from "ve-framework/views/sys/group";
export default {
  name: "sys-organization",
  components: {
    Page
  },
  data() {
    return {
      dialogMaps: {
        permission: {
          title: this.$t("_tm.table.actions.setRole"),
          width: "400px",
          component: groupPermission
        }
      },
      buttons: [
        {
          name: this.$t("_tm.table.actions.setRole"),
          command: "permission",
          // disabled: ({ enabled }) => {
          //   return enabled === 0;
          // },
          show: ({ tenant }) => {
            //根据系统配置-组织模式, 隐藏
            const { customize = {} } = this.$config;
            const { purviewMode } = customize;
            return tenant == 0 && purviewMode !== "SUBSIDIARY";
          }
        }
      ]
    };
  }
};
</script>
