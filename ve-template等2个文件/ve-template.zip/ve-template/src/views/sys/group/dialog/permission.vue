<template>
  <div class="clearfix">
    <div class="permission-tree">
      <tm-tree
        class="auth-tree"
        ref="tm-tree"
        v-loading="treeLoading"
        :showCheckbox="true"
      >
        <div class="custom-node" slot-scope="{ data }">
          <span> {{ data.name }}</span>
        </div>
      </tm-tree>
    </div>
    <span class="dialog-footer pull-right">
      <el-button @click="cancel">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </span>
  </div>
</template>

<script>
import { apiPurviewsGet, apiPurviewsSave } from "@/api/group";
export default {
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      treeLoading: true,
      data: [],
      id: null
    };
  },
  methods: {
    opened() {
      this.$refs["tm-tree"].clear();
      this.treeLoading = true;
      var id = this.params.id;
      id &&
        apiPurviewsGet({ type: 0, tid: id, model: 0 }).then(data => {
          // apiPurviewsGet({ decorated: 0, level: 0, model: 0, type:0}).then(data => {
          if (data && Array.isArray(data) && data.length) {
            this.$refs["tm-tree"].setData(data);
            let checkedIds = this.getCheckIds(data);
            this.$refs["tm-tree"].setCheckedKeys(checkedIds);
            this.id = id;
          } else {
            this.data = [];
          }
          this.treeLoading = false;
        });
    },
    closed() {
      this.treeLoading = true;
    },
    cancel() {
      this.$emit("close");
    },
    save() {
      const { id } = this;
      let checkedNodes = this.$refs["tm-tree"].getCheckedNodes();
      let parameters = checkedNodes.map(item => {
        let { checked, indeterminate } = item;
        return {
          id: item.id,
          level: item.level,
          pid: item.pid || "",
          checked: indeterminate ? 2 : 1
        };
      });
      apiPurviewsSave({ tid: id, type: 0, model: 0 }, parameters).then(res => {
        this.$emit("close");
        this.$message.success("保存成功!");
      });
    },
    // 深度遍历, 使用递归
    getCheckIds(data) {
      const result = [];
      data.forEach(item => {
        const map = data => {
          if (data.checked === 1) result.push(data.id);
          data.children && data.children.forEach(child => map(child));
        };
        map(item);
      });
      return result;
    }
  }
};
</script>

<style lang="scss" scoped>
.permission-tree {
  height: 500px;
  // overflow-y: scroll;
}
</style>
