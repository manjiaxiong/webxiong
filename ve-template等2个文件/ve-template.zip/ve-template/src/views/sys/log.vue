<template>
  <log />
</template>
<script>
import Log from "ve-framework/views/sys/log";
export default {
  name: "sys-log",
  components: {
    Log
  }
};
</script>
