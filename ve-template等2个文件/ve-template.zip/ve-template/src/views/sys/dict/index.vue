<template>
  <page />
</template>

<script>
import Page from "ve-framework/views/sys/dict/index.vue";
export default {
  name: "sys-dict",
  components: {
    Page
  }
};
</script>
