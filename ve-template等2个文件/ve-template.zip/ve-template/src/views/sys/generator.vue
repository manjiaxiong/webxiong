<template>
  <generator />
</template>

<script>
import Generator from "ve-framework/views/sys/generator";
export default {
  name: "sys-generator",
  components: {
    Generator
  }
};
</script>
