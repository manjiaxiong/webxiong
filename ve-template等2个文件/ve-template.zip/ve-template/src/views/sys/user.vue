<template>
  <user />
</template>

<script>
import User from "ve-framework/views/sys/user";
export default {
  name: "sys-user",
  components: {
    User
  }
};
</script>
