<template>
  <resource />
</template>

<script>
import Resource from "ve-framework/views/sys/resource";
export default {
  name: "sys-resource",
  components: {
    Resource
  }
};
</script>
