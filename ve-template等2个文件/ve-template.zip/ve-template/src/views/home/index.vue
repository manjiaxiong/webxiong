<template>
  <div class="pan-btn blue-btn" @click="openSwagger">
    {{ $t("home.document") }}
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    openSwagger() {
      // let url = `${process.env.VUE_APP_PROXY_DOMAIN}/doc.html`;
      let url = `${this.$config.baseURL}/doc.html`;
      window.open(url);
    }
  }
};
</script>

<style scoped>
.box-card {
  margin-bottom: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
}
.pan-btn {
  cursor: pointer;
}
</style>
