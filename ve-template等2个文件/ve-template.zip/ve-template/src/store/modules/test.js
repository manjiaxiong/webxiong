export default {
    state: {},
    mutations: {},
    actions: {},
    getters: {}
  };
  