import test from "./modules/test";
export default { test };
