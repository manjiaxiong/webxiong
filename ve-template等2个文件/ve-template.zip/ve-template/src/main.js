import Vue from "vue";
import App from "./App";
// 项目静态路由
import routers from "@/router";
// 项目自定义的store
import stores from "@/store";
// 项目的国际化语言包
import langMessage from "@/lang";
// 引入天迈前端框架 framework
import {
  VeFramework,
  router,
  store,
  i18n,
  getServerConfig
} from "ve-framework";
// 项目全局样式
import "@/styles/global.scss";


Vue.use(VeFramework);

// 注入静态路由案例
router.registerRoutes(routers);

// 注入项目 vuex store
Object.keys(stores).forEach(v => {
  store.registerModule(v, stores[v]);
});

// 注册本地语言包
Reflect.ownKeys(langMessage).forEach(key => {
  i18n.mergeLocaleMessage(key, langMessage[key]);
})

Vue.config.productionTip = false;

getServerConfig().then(config => {
  new Vue({
    router,
    store,
    i18n,
    render: h => h(App)
  }).$mount("#app");
});
