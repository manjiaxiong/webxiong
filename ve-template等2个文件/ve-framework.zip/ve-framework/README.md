# ve-framework

## 安装依赖包
```
npm install ve-framework
```

# 使用
```
import {
  VeFramework,
  router,
  store,
  request,
  i18n,
  getServerConfig
} from "ve-framework";

Vue.use(VeFramework);

new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount("#app");
```

# 文档地址

http://192.168.247.136:8181/docs/ve/ve-1cc2ls788rcrm


# 内置依赖
- normalize.css
- screenfull
- vxe-table
- @tiamaes/tree
- js-cookie
- vue-i18n
- lodash
