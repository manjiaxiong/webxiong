import Vue from 'vue';
const maxTrack = 200;
const monitor = {
  state: {
    carList: {},
    trackList: {},
    vision: ''
  },
  mutations: {
    SET_CAR_LIST: (state, data) => {
      state.carList = data;
    },
    UPDATE_CAR_LIST: (state, data) => {
      const { key, value, subKey } = data;
      if (key && value) {
        if (subKey) {
          Vue.set(state.carList[key], subKey, value);
        } else {
          Vue.set(state.carList, key, value);
        }
      }
    },
    REMOVE_CAR_LIST: (state, key) => {
      Vue.delete(state.carList, key);
    },
    UPDATE_TRACK_LIST: (state, data) => {
      const { key, value, remove } = data;
      if (key && (value || remove)) {
        if (remove) {
          Vue.delete(state.trackList, key);
          if (Object.keys(state.trackList).length === 0) {
            state.vision = '';
          }
        } else {
          if (state.trackList[key]) {
            if (state.trackList[key].length === maxTrack) {
              state.trackList[key].shift();
            }
            state.trackList[key].push(value);
          } else {
            Vue.set(state.trackList, key, [value]);
          }
        }
      }
    },
    SET_TRACK_LIST: (state, data) => {
      state.trackList = data;
    },
    SET_VISION: (state, data) => {
      state.vision = data;
    }
  },
  actions: {
    setCarList({ commit }, data) {
      commit('SET_CAR_LIST', data);
    },
    updateCarList({ commit }, data) {
      commit('UPDATE_CAR_LIST', data);
    },
    removeCarList({ commit }, data) {
      commit('REMOVE_CAR_LIST', data);
    },
    setTrackList({ commit }, data) {
      commit('SET_TRACK_LIST', data);
    },
    updateTrackList({ commit }, data) {
      commit('UPDATE_TRACK_LIST', data);
    },
    setVision({ commit }, data) {
      commit('SET_VISION', data);
    }
  },
  getters: {
    carList: state => state.carList,
    trackList: state => state.trackList,
    vision: state => state.vision
  }
};

export default monitor;
