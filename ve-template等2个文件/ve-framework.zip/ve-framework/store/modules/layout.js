let layoutMode = localStorage.getItem("layoutMode") || "vertical";
let layoutTheme = localStorage.getItem("layoutTheme") || "default";
window.document.body.setAttribute("data-layout", layoutMode);
window.document.body.setAttribute("data-theme", layoutTheme);

const app = {
  state: {
    mode: layoutMode, //布局模式 vertical | horizontal
    theme: layoutTheme, // 默认主题 default night
    multipage: localStorage.getItem("multipage") !== "false", // 开启多页签
    primaryColor: "#f1f2f5", // 主题色
    mainBgColor: localStorage.getItem("mainBgColor") || "#F1F4F5" // 内容主体的背景色 #F1F4F5
  },
  mutations: {
    SET_MODE(state, val) {
      state.mode = val;
      window.document.body.setAttribute("data-layout", val);
      localStorage.setItem("layoutMode", val);
    },
    SET_THEME(state, val) {
      state.theme = val;
      window.document.body.setAttribute("data-theme", val);
      localStorage.setItem("layoutTheme", val);
    },
    SET_MULTIPAGE(state, val) {
      state.multipage = val;
      localStorage.setItem("multipage", val);
    },
    SET_MAINBGCOLOR(state, val) {
      state.mainBgColor = val;
      localStorage.setItem("mainBgColor", val);
    }
  },
  actions: {}
};

export default app;
