import Cookies from "js-cookie";
import i18n, { getLang } from "../../lang";
import { getConfig } from "../../config";

var systemInfo = localStorage.getItem("systemInfo");
if (systemInfo) {
  systemInfo = JSON.parse(systemInfo);
} else {
  systemInfo = { id: "", name: "" };
}

const app = {
  state: {
    // 侧边栏
    sidebar: {
      opened: Cookies.get("sidebarStatus")
        ? !!+Cookies.get("sidebarStatus")
        : true,
      withoutAnimation: false
    },
    device: "desktop",
    // 国际化
    language: getLang(),  // 国际化语言
    size: Cookies.get("size") || "medium",
    systemInfo
  },
  mutations: {
    TOGGLE_SIDEBAR: state => {
      state.sidebar.opened = !state.sidebar.opened;
      state.sidebar.withoutAnimation = false;
      if (state.sidebar.opened) {
        Cookies.set("sidebarStatus", 1);
      } else {
        Cookies.set("sidebarStatus", 0);
      }
    },
    CLOSE_SIDEBAR: (state, withoutAnimation) => {
      Cookies.set("sidebarStatus", 0);
      state.sidebar.opened = false;
      state.sidebar.withoutAnimation = withoutAnimation;
    },
    TOGGLE_DEVICE: (state, device) => {
      state.device = device;
    },
    SET_LANGUAGE: (state, language) => {
      if (!i18n) return;
      i18n.locale = language;
      state.language = language;
      Cookies.set("language", language);
    },
    SET_SIZE: (state, size) => {
      state.size = size;
      Cookies.set("size", size);
    },
    SET_SYSTEM_INFO: (state, systemInfo) => {
      state.systemInfo = systemInfo;
      localStorage.setItem("systemInfo", JSON.stringify(systemInfo));
    }
  },
  actions: {
    toggleSideBar({ commit }) {
      commit("TOGGLE_SIDEBAR");
    },
    closeSideBar({ commit }, { withoutAnimation }) {
      commit("CLOSE_SIDEBAR", withoutAnimation);
    },
    toggleDevice({ commit }, device) {
      commit("TOGGLE_DEVICE", device);
    },
    setSize({ commit }, size) {
      commit("SET_SIZE", size);
    }
  }
};

export default app;
