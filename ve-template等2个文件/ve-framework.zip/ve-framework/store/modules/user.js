import {
  loginByUsername,
  logout,
  // getUserInfo,
  refreshToken
} from "../../api/login";
import { getToken, setToken, removeToken } from "../../utils/auth";
import router, { resetRouter } from "../../router";
import { getConfig } from "../../config";

const data = getToken();
let token = "";
let nickname = "";
if (data) {
  const dataJson = JSON.parse(data);
  if (dataJson) {
    token = dataJson?.accessToken
    nickname = dataJson?.props?.nickname ?? ''
  }
}

const user = {
  state: {
    token: token,
    nickname: nickname,
    roles: [],
    setting: {
      articlePlatform: []
    }
  },
  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token;
    },
    SET_NICKNAME: (state, nickname) => {
      state.nickname = nickname;
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles;
    },
    SET_SETTING: (state, setting) => {
      state.setting = setting;
    },
  },

  actions: {
    // 用户名登录
    LoginByUsername({ commit }, userInfo) {
      return new Promise((resolve, reject) => {
        loginByUsername(userInfo)
          .then(data => {
            if (data) {
              const { accessToken, expires, props } = data;
              if (accessToken) {
                data.expires = Date.now() + parseInt(expires);
                const dataString = JSON.stringify(data);
                commit("SET_TOKEN", accessToken);
                commit("SET_NICKNAME", props.nickname);
                setToken(dataString, expires);
              }
              resolve();
            }
          })
          .catch(error => {
            reject(error);
          });
      });
    },
    // eslint-disable-next-line
    refreshToken(
      {
        commit,
        // eslint-disable-next-line
        state
      },
      data
    ) {
      return refreshToken(data).then(data => {
        if (data) {
          const {
            accessToken,
            // refreshToken,
            expires,
            props
          } = data;
          if (accessToken) {
            const oldToken = JSON.parse(getToken());
            if (oldToken && oldToken.props && !props) {
              data.props = oldToken.props;
            }
            data.expires = Date.now() + expires;
            const dataString = JSON.stringify(data);
            commit("SET_TOKEN", accessToken);
            setToken(dataString, expires);
            return data;
          }
        }
      });
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout(state.token)
          .then(() => {
            commit("SET_TOKEN", "");
            commit("SET_ROLES", []);
            removeToken();
            resetRouter();
            resolve();
          })
          .catch(error => {
            reject(error);
          });
      });
    },

    // 前端 登出登录并跳转到登录页
    FedLogOut({ dispatch, commit }) {
      return Promise.all([dispatch("delAllViews")]).then(() => {
        commit("SET_TOKEN", "");
        commit("SET_ROUTERS", []);
        removeToken();
        resetRouter();
        sessionStorage.clear();
        localStorage.removeItem("systemId");
      }).then(()=>{
        const multiSystem = getConfig("multiSystem");
        // 如果开启多子系统，且配置登录页地址，强制跳转
        if (multiSystem && multiSystem.loginURL) {
          location.href = multiSystem.loginURL;
        } else {
          router.push("/login");
        }
      })
    }
    // 动态修改权限
    // ChangeRoles({ commit, dispatch }, role) {
    //   return new Promise(resolve => {
    //     getUserInfo(role).then(response => {
    //       const data = response.data;
    //       // dispatch("GenerateRoutes", data); // 动态修改权限后 重绘侧边菜单
    //       resolve();
    //     });
    //   });
    // }
  }
};

export default user;
