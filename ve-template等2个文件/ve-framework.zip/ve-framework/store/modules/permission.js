// import { Message } from "element-ui";
import { constantRoutes } from "../../router";
import { getResource } from "../../api/resource";
/**
 * 递归过滤异步路由表，返回用户的动态一维路由表
 * @param routes asyncRouterMap
 * @param roles
 */
function filterAsyncRouter(routes, res = []) {
  routes.forEach(route => {
    const tmp = {
      ...route
    };

    tmp.meta = tmp.meta || {};
    tmp.meta.id = tmp.id;
    tmp.meta.title = tmp.name;
    tmp.meta.type = tmp.type;

    tmp.name = tmp.id;

    // Iframe 或者 外链
    if (tmp.type === 4 || tmp.type === 2) {
      tmp.meta.path = tmp.path
      tmp.path = '/' + tmp.path
      tmp.component = null
    } else {
      tmp.meta.permTypes =
        tmp.buttons && tmp.buttons.length > 0
          ? tmp.buttons.map(btn => btn.key)
          : [];

      if (tmp.path) {
        let pagePath = tmp.path;
        // 特殊符号文件路径处理
        if (tmp.path === "/") {
          pagePath = "/home";
        }
        // 动态路由
        if (pagePath.indexOf("/:") != -1) {
          pagePath = pagePath.substring(0, pagePath.indexOf("/:"));
        }
        // 懒加载页面
        tmp.component = () => import(`@/views${pagePath}`);
      }

      if (tmp.children) {
        res = filterAsyncRouter(tmp.children, res);
        delete tmp.children;
      }
    }

    if (tmp.path) {
      res.push(tmp);
    }
  });
  return res;
}

const permission = {
  state: {
    // 静态路由
    routers: constantRoutes,
    // 动态添加路由列表
    addRouters: [],
    // 用户导航菜单列表 - 原数据
    asyncRouters: []
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers;
    },
    SET_ASYNC_ROUTERS: (state, routers) => {
      state.asyncRouters = routers;
    }
  },
  actions: {
    // 请求资源管理配置的路由，动态添加路由
    GenerateRoutes({ commit }, systemId) {
      return getResource({ parentId: systemId }).then(data => {
        if (data && data.length > 0) {
          var filterRouter = filterAsyncRouter(data);
          const constantRouterMap = [
            {
              path: "/",
              component: () => import("@/views/layout/Layout"),
              redirect: filterRouter[0].path,
              children: filterRouter
            },
            { path: "*", redirect: "/404" }
          ];
          commit("SET_ROUTERS", constantRouterMap);
          commit("SET_ASYNC_ROUTERS", data);
          return data;
        } else {
          // 没有菜单数据,但是不需要退出登录。前端展示一个欢迎首页
          // Message({
          //   message: "没有菜单数据，请检查您的权限",
          //   type: "warning"
          // });
          let mockData = [
            {
              hidden: false,
              ico: "",
              id: "welcome",
              name: "首页",
              orderNo: 1,
              path: "/welcome",
              rank: 0,
              type: 1
            }
          ];
          var filterRouter = filterAsyncRouter(mockData);
          const constantRouterMap = [
            {
              path: "/",
              component: () => import("@/views/layout/Layout"),
              redirect: filterRouter[0].path,
              children: filterRouter
            },
            { path: "*", redirect: "/404" }
          ];
          commit("SET_ROUTERS", constantRouterMap);
          commit("SET_ASYNC_ROUTERS", mockData);
          return mockData;
        }
      });
    }
  }
};

export default permission;
