import deepmerge from "./utils/deepmerge";
import cloneDeep from "lodash/cloneDeep";
import isEqual from "lodash/isEqual";
// 定义全局方法
Object.clone = cloneDeep;
Object.merge = deepmerge;
Object.isEqual = isEqual;
// 数组删除元素
Array.prototype.remove = function (val) {
  var index = this.indexOf(val);
  if (index > -1) {
    this.splice(index, 1);
  }
};
// 数组切割分组
Array.chunk = (collection, size) => {
  let result = [];
  // default size to two item
  size = parseInt(size) || 2;
  const len = Math.ceil(collection.length / size);
  // add each chunk to the result
  for (let x = 0; x < len; x++) {
    let start = x * size;
    let end = start + size;
    result.push(collection.slice(start, end));
  }
  return result;
};
// 树形数组过滤，将要废弃不推荐使用，推荐使用 utils/tree
Array.prototype.filterTree = function (cb, opts = {}) {
  if (!Array.isArray(this) || typeof cb !== "function") {
    console.error("参数错误");
    return [];
  }
  const { key, parent } = Object.assign(
    {
      key: "children",
      // 默认包含父节点
      parent: true
    },
    opts
  );
  if (!parent) {
    let res = [];
    // 不包含父节点
    this.forEachTree(v => {
      if (cb(v)) {
        res.push(v);
      }
    }, opts);
    return res;
  }
  return this.filter(item => {
    return cb(item);
  }).map(item => {
    if (item && item[key] && item[key].length) {
      item[key] = item[key].filterTree(cb, opts);
    }
    return item;
  });
};
// 树形数组遍历，将要废弃不推荐使用，推荐使用 utils/tree
Array.prototype.forEachTree = function (cb, opts = {}) {
  if (!Array.isArray(this) || typeof cb !== "function") {
    console.error("参数错误");
    return;
  }
  const { key, parent } = Object.assign(
    {
      key: "children",
      parent: false
    },
    opts
  );
  for (var i = 0; i < this.length; i++) {
    if (this[i][key] && this[i][key].length) {
      if (parent) {
        cb(this[i]);
      }
      this[i][key].forEachTree(cb, opts);
    } else {
      cb(this[i]);
    }
  }
};

// 判断对象是否为空
Object.isEmpty = obj => {
  return !obj || (obj && Object.keys(obj).length === 0);
};
// 个位数补零
String.zero = t => {
  return t < 10 ? "0" + t : t;
};

//四舍五入保留n位小数（若第n位小数为0，则保留n-1位小数）
Math.fixed = (num, n = 2) => {
  let result = parseFloat(num);
  if (isNaN(result)) {
    console.error("传递参数错误，请检查！");
    return num;
  }
  const x = Math.pow(10, n);
  return Math.round(result * x) / x;
};
