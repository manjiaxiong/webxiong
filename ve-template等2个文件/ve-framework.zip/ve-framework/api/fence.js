import request from "../utils/request";
import { formatPoints } from "../utils/map";
import { getConfig } from "./config";
export const { baseURL, compatible } = getConfig("fence");
const url = baseURL + "/fencedata";

const subRegionURL = compatible ? "region" : "regions";
const subRuleURL = compatible ? "rule" : "rules";

export function getRegionTreeList() {
  return request({
    url: url + "/" + subRegionURL + "/allRegion",
    method: "get"
  });
}

export function getRegion(id) {
  return request({
    url: url + "/" + subRegionURL + "/detail/" + id,
    method: "get"
  }).then(data => {
    const { borderList, regionType, id, regionName } = data;
    if (borderList) {
      const points = formatPoints(borderList, regionType);
      return {
        id,
        regionName,
        regionType,
        points
      };
    }
    return null;
  });
}

export function deleteRegion(id) {
  return request({
    url: url + "/" + subRegionURL + "/" + id,
    method: "delete"
  });
}

export function saveRegion(data) {
  return request({
    url: url + "/" + subRegionURL + "/add",
    method: "post",
    data
  });
}

export function saveRegionEdit(data) {
  return request({
    url: url + "/" + subRegionURL + "/update",
    method: "post",
    data
  });
}

export function getRuleList(type) {
  return request({
    url: url + "/" + subRuleURL + "/allByType",
    method: "get",
    params: {
      ruleType: type
    }
  }).then(data => {
    if (data.length) {
      // console.log(data);
      return (
        data
          // .filter(v => v.ruleParameterEntities)
          .map(v => {
            let params = {
              id: v.id,
              ruleName: v.ruleName
            };
            if (v.regionEntity) {
              params.regionId = v.regionEntity.id;
              params.regionName = v.regionEntity.regionName;
            }
            v.ruleParameterEntities &&
              v.ruleParameterEntities.forEach(m => {
                if (m.parameterDesc) {
                  params[m.parameterName + "_NAME"] = m.parameterDesc;
                }
                params[m.parameterName + "_VALUE"] = m.parameterValue;
              });
            return params;
          })
      );
    }
    return [];
  });
}

export function getCarByRuleId(id) {
  return request({
    url: url + "/" + subRuleURL + "/ruleCarByRuleId/" + id,
    method: "get"
  });
}

export function saveRuleAdd(data) {
  return request({
    url: url + "/" + subRuleURL + "/add",
    method: "post",
    data
  });
}

export function saveRuleEdit(data) {
  return request({
    url: url + "/" + subRuleURL + "/update",
    method: "put",
    data
  });
}

export function deleteRule(id) {
  return request({
    url: url + "/" + subRuleURL + "/" + id,
    method: "delete"
  });
}
