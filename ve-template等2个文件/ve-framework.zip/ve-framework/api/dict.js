import request from "../utils/request";
export const subURL = "/dictionaries";


// 获取所有启用的字典
export function getAllDict() {
  return request({
    url: subURL + "/dictinfoall",
    method: "get"
  });
}

// 获取所有的字典类型
export function getAllType() {
  return request({
    url: subURL + "/dicttypeall",
    method: "get"
  });
}

// 添加数据字典类型
export function addCategory(data) {
  return request({
    url: subURL + "/dicttype",
    method: "post",
    data
  });
}

// 修改字典类型名称
export function updateCategory(data, id) {
  return request({
    url: subURL + "/dicttype",
    method: "put",
    params: {
      id,
      ...data
    }
  });
}

// 添加字典明细
export function addData(data) {
  return request({
    url: subURL + "/dictinfo",
    method: "post",
    data
  });
}

// 修改字典明细;
export function updateData(data, id) {
  return request({
    url: subURL + "/dictinfo",
    method: "put",
    params: {
      id,
      ...data
    }
  });
}
