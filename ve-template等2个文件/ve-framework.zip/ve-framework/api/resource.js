import request from "../utils/request";

// 获取当前登陆用户的导航菜单列表 （动态添加路由使用）
export function getResource(data = {}) {
  return request({
    url: "/authority/resources/navigation",
    method: "get",
    params: data
  });
}

//  以树形的方式获取资源权限列表 - 资源管理页面
export function getResourceTree(data = {}) {
  return request({
    url: "/authority/resources/tree",
    method: "get",
    params: data
  });
}

// 更新资源信息 - 资源管理页面
export function updateResource(data, id) {
  return request({
    url: "/authority/resources/" + id,
    method: "put",
    data
  });
}

// 新增资源信息 - 资源管理页面
export function addResource(data, id) {
  return request({
    url: id ? "/authority/resources/" + id : "/authority/resources",
    method: "post",
    data
  });
}

// 删除资源信息 -  资源管理页面
export function deleteResource(id) {
  return request({
    url: "/authority/resources/" + id,
    method: "delete"
  });
}

// 移动资源 -  资源管理页面
export function moveResource(id, tid, type) {
  return request({
    url: "/authority/resources/" + id,
    method: "PATCH",
    params: { id, tid, type }
  });
}
