import request from "../utils/request";

/**
 * 用户数据权限接口
 *
 */


// 获取用户的数据权限树列表
export function apiPurviewsGet(params, data = {}) {
    return request({
        url: `/purviews`,
        method: "get",
        params,
        data
    });
}

// 获取用户的数据权限树列表
export function apiPurviewsDataGet(params, data = {}) {
    return request({
        url: `/purviews/data`,
        method: "get",
        params,
        data
    });
}

// 保存用户的数据权限
export function apiPurviewsSave(params, data = {}) {
    return request({
        url: `/purviews`,
        method: "put",
        params,
        data
    });
}
