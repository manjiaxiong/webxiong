import request from "../utils/request";
import MD5 from "../utils/md5.js";
import i18n from "../lang/index.js";
import {
  Notification
} from "element-ui";

export function update(data, id) {
  return request({
    url: "/authority/users/" + id,
    method: "put",
    data
  });
}

export function add(data) {
  let message;
  if (data.password) {
    message = data.password
    data.password = MD5(MD5(data.password))
  }
  return request({
    url: "/authority/users",
    method: "post",
    data
  }).then(resp => {
    if (resp) {
      if (resp.password) message = resp.password
      Notification({
        title: `${i18n.t('_tm.table.columns.username')}: ${resp.username}`,
        message: `${i18n.t('_tm.table.columns.password')}: ${message}`,
        duration: 0
      })
      return resp
    }
  })
}

export function remove(id) {
  return request({
    url: "/authority/users/" + id,
    method: "delete"
  });
}

export function passwordEdit(data) {
  return request({
    url: "/authority/users/password/edit",
    method: "put",
    data
  });
}

export function passwordReset(data) {
  return request({
    url: "/authority/users/password/reset",
    method: "put",
    data
  });
}


// 禁用用户
export function apiUserDisabled(id) {
  return request({
    url: `/authority/users/${id}/disabled`,
    method: "patch"
  });
}

// 启用用户
export function apiUserEnabled(id) {
  return request({
    url: `/authority/users/${id}/enabled`,
    method: "patch"
  });
}

// 解锁用户
export function apiUserUnlock(id) {
  return request({
    url: `/authority/users/${id}/unlock`,
    method: "patch"
  });
}
