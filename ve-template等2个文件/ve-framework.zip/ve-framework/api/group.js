import request from "../utils/request";

// 新增
export function addGroup(data, id) {
  return request({
    url: id ? "/authority/organization/" + id : "/authority/organization",
    method: "post",
    data
  });
}

// 更新
export function updateGroup(data, id) {
  return request({
    url: "/authority/organization/" + id,
    method: "put",
    data
  });
}

// 删除
export function deleteGroup(id) {
  return request({
    url: "/authority/organization/" + id,
    method: "delete"
  });
}

// 组织树
export function getGroupTree(data = {}) {
  return request({
    url: "/authority/organization/tree",
    method: "get",
    params: data
  });
}

// 组织平铺列表
export function getGroupList(data = {}) {
  return request({
    url: "/authority/organization/list",
    method: "get",
    params: data
  });
}


// 禁用组织机构
export function apiGroupDisabled(id) {
  return request({
    url: `/authority/organization/${id}/disabled`,
    method: "patch"
  });
}

// 启用组织机构
export function apiGroupEnabled(id) {
  return request({
    url: `/authority/organization/${id}/enabled`,
    method: "patch"
  });
}
