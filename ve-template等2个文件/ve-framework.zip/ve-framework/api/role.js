import request from "../utils/request";

export function getRoles() {
  return request({
    url: "/authority/roles",
    method: "get"
  });
}

export function getRoleAuth(role) {
  return request({
    url: "/authority/roles/auth/" + role,
    method: "get"
  });
}

export function setRoleAuth(role, auth) {
  return request({
    url: "/authority/roles/auth/" + role + "/" + auth,
    method: "put"
  });
}

export function deleteRoleAuth(role, auth) {
  return request({
    url: "/authority/roles/auth/" + role + "/" + auth,
    method: "delete"
  });
}

export function update(data, id) {
  return request({
    url: "/authority/roles/" + id,
    method: "put",
    data
  });
}

export function add(data) {
  return request({
    url: "/authority/roles",
    method: "post",
    data
  });
}

export function remove(id) {
  return request({
    url: "/authority/roles/" + id,
    method: "delete"
  });
}


// 禁用组织机构
export function apiRoleDisabled(id) {
  return request({
    url: `/authority/roles/${id}/disabled`,
    method: "patch"
  });
}

// 启用组织机构
export function apiRoleEnabled(id) {
  return request({
    url: `/authority/roles/${id}/enabled`,
    method: "patch"
  });
}
