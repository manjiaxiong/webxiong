import request from "../utils/request";
import { getConfig } from "./config";

export function getAlarmCount(ptId = 1) {
  const { baseURL } = getConfig("alarm");
  return request({
    url: baseURL + "/alarm/undo",
    method: "get",
    params: {
      ptId
    }
  });
}

export function updateAlarm(data, id) {
  const { baseURL } = getConfig("alarm");
  return request({
    url: baseURL + "/talarm/disposeTaxiAlarm",
    method: "put",
    params: {
      id,
      ...data
    }
  });
}

export function alarm(ptId = 1) {
  const { baseURL } = getConfig("alarm");
  return request({
    url: baseURL + "/alarm/undoBoard",
    method: "get",
    params: {
      ptId
    }
  });
}
