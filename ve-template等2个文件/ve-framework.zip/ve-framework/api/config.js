import { getConfig as get } from "../config";

export const getConfig = key => get(["api", key].join("."));
