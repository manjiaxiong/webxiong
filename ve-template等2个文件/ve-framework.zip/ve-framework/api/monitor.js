import request from "../utils/request";
import { getConfig } from "./config";
export const { baseURL, compatible } = getConfig("monitor");

let baseurl = baseURL;

export function getCarTreeList() {
  return request({
    url:
      baseurl +
      (compatible ? "/monitor/orgtree/data" : "/monitor/realtimes/tree"),
    method: "get"
  });
}

export function getCarCount() {
  return request({
    url:
      baseurl +
      (compatible
        ? "/monitor/realtime/car/count"
        : "/monitor/realtimes/vehicles/count"),
    method: "get"
  });
}

export function getCars(data) {
  if (typeof data === "string") {
    data = data.split(",");
  }
  return request({
    url:
      baseurl +
      (compatible ? "/monitor/realtime/cars" : "/monitor/realtimes/vehicles"),
    method: "post",
    data
  });
}

export function getAllCars() {
  return request({
    url:
      baseurl +
      (compatible ? "/monitor/realtime/cars" : "/monitor/realtimes/vehicles"),
    method: "get"
  });
}

export function getDriver(params) {
  return request({
    url:
      baseurl +
      (compatible
        ? "/monitor/realtime/currentDriver"
        : "/monitor/realtimes/vehicles/currentDriver"),
    method: "get",
    params
  });
}

export function getBusList(data) {
  return request({
    url:
      baseurl + (compatible ? "/monitor/realtime/search" : "/monitor/search"),
    method: "get",
    params: data
  });
}

export function setBaseURL(url) {
  baseurl = url;
}
