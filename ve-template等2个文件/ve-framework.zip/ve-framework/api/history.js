import request from "../utils/request";
import { getConfig } from "./config";
export const { baseURL, compatible } = getConfig("history");

export function getPositionHistory(data) {
  if (typeof data.type === "undefined") {
    // 修复网约车字段必填报错
    data.type = 1;
  }
  return request({
    url: baseURL + "/replay/" + (compatible ? "test" : "list"),
    method: "get",
    params: data
  });
}
