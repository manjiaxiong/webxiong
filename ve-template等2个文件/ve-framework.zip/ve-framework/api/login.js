import request from "../utils/request";
import md5 from "../utils/md5";
import { getConfig } from "../config";

const getBaseURL = ()=>{
  let baseURL = getConfig('loginBaseURL') ?? getConfig('baseURL')
  return baseURL
}

export function refreshToken(data) {
  const compatible = getConfig("api.authority.compatible");
  return request({
    baseURL: getBaseURL(),
    url: "/refreshToken",
    method: "post",
    data
  });
}

export function loginByUsername({
  loginUrl,
  username,
  password,
  verifyCode,
  verify,
  ...others // 兼容验证码校验附加参数。新版本 __token 字段， 旧版本 token 字段
}) {
  username = username.trim();
  // 密码强制加密,不向下兼容
  password = md5(md5(password));

  const data = {
    username,
    password,
    yzm: verifyCode,
    verify,
    ...others
  };
  return request({
    baseURL: getBaseURL(),
    url: loginUrl || "/login",
    method: "post",
    params: data,
    data: {}
  });
}

export function logout() {
  return request({
    baseURL: getBaseURL(),
    url: "/logout",
    method: "post"
  });
}

// 获取验证码
export function jcaptcha() {
  return request({
    baseURL: getBaseURL(),
    url: "/jcaptcha",
    method: "get"
  });
}

export function getUserInfo(token) {
  return request({
    url: "/authority/user/info",
    method: "get",
    params: {
      token
    }
  });
}
