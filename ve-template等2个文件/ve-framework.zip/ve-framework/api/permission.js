import request from "../utils/request";
import { getConfig } from "./config";
export const { baseURL } = getConfig("purviews");

let baseurl = baseURL;

export function purviews(data) {
  return request({
    url: baseurl + "/purviews",
    method: "get",
    params: {
      uid: data
    }
  });
}

export function savePurviews(data) {
  const { purviews, uid } = data;
  return request({
    url: baseurl + "/purviews",
    method: "put",
    params: {
      uid
    },
    data: purviews
  });
}

// export function purviewsData() {
//   return request({
//     url: baseurl + '/purviews/data',
//     method: 'get'
//   });
// }

export function setBaseURL(url) {
  baseurl = url;
}
