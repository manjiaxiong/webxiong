const pager = {
  pagination: "urlParams",
  pageIndexKey: "page",
  pageSizeKey: "size"
};
let config = {
  // 子系统配置
  multiSystem: false,
  // 默认版权信息
  copyright: "版权 &copy; 郑州天迈科技",
  // 网站标题
  title: "web前端通用平台",
  // 自定义密码正则校验
  pwdValidate: {
    RegExp:"",
    message:""
  },
  // 超时退出时长  0表示不永不退出
  timeoutLogout: 0,
  // 国际化多语言
  i18n:{
    show: true,   // 是否显示中英文切换按钮 （导航栏）
    locale: 'zh', // zh en
  },
  // 默认网关
  baseURL: "/gateway",
  /**
   * 登录等主应用用户状态接口的 baseURL
   * 优先级大于 baseURL,默认取baseURL      loginBaseURL ?? baseURL
   * 影响接口: [login | jcaptcha | logout | refreshToken]
   */
  loginBaseURL: null,
  // 地图默认中心点为郑州，地图默认缩放级别为12
  map: {
    center: {
      lng: 113.663221,
      lat: 34.7568711
    },
    zoom: 12
  },
  // 登录默认开启验证码
  captcha: true,
  // 全局分页配置
  pager,
  // 公共接口相关配置
  api: {
    // 告警模块
    alarm: {
      baseURL: ""
    },
    // 用户管理模块配置
    authority: {
      // 兼容模式，是否兼容微服务旧版本
      compatible: false
    },
    // 数据权限模块
    purviews: {
      baseURL: ""
    },
    // 实时定位监控模块配置
    monitor: {
      baseURL: "",
      // 兼容模式，是否兼容微服务旧版本
      compatible: false
    },
    // 轨迹回放模块
    history: {
      baseURL: "",
      compatible: false
    },
    // 电子围栏模块
    fence: {
      baseURL: "",
      compatible: false
    }
  }
};

const setConfig = cfg => {
  config = Object.merge(config, cfg);
};

const getConfig = key => {
  if (typeof key === "string") {
    const arr = key.split(".");
    if (arr && arr.length) {
      let data = config;
      arr.forEach(v => {
        if (data && typeof data[v] !== "undefined") {
          data = data[v];
        } else {
          data = null;
        }
      });
      return data;
    }
  }
  return config;
};

export { getConfig, setConfig };
