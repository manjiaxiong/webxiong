import router, { initRouterMap, resetRouter } from "./router";
import store from "./store";
import NProgress from "nprogress"; // progress bar
import "nprogress/nprogress.css"; // progress bar style
import { getToken, setToken, getTokenBySSO, removeToken } from "./utils/auth"; // getToken from cookie
import { getConfig } from "./config";
import DICT from "./utils/dict";

NProgress.configure({
  showSpinner: false
});

router.beforeEach((to, _from, next) => {
  // start progress bar
  NProgress.start();
  let token = getToken() || getTokenBySSO();
  const multiSystem = getConfig("multiSystem");
  const production = process.env.NODE_ENV === "production";
  const multiSystemEnabled = multiSystem && production;
  let auth = null;
  // SSO 或 多子系统
  if (to.query.auth) {
    let tokenStr = decodeURIComponent(to.query.auth);
    auth = JSON.parse(tokenStr);
    // SSO
    if (auth && auth.accessToken) {
      store.commit("SET_ROUTERS", []); //清空路由信息
      store.commit("SET_ASYNC_ROUTERS", []); //清空动态生成路由
      store.dispatch("delAllVisitedViews"); //清空所有打开的标签页
      localStorage.removeItem("systemId"); //清空模块信息
      removeToken(); // 清空本地信息确保用户不受污染
      setToken(tokenStr);
      token = tokenStr;
    }
    // 多子系统
    if (auth && auth.id) {
      localStorage.setItem("systemId", auth.id);
      store.commit("SET_SYSTEM_INFO", {
        id: auth.id,
        name: auth.name
      });
    }
  }
  let systemId = auth && auth.id ? auth.id : localStorage.getItem("systemId");
  if (token) {
    // 加载字典
    let $dict = DICT.getInstance();
    if (!$dict.data) {
      $dict.init();
    }
    if (
      multiSystemEnabled &&
      !multiSystem.systemId &&
      !auth &&
      to.path !== "/home" &&
      !systemId
    ) {
      return next({
        path: "/home"
      });
    }
    if (to.path === "/login") {
      next({
        path: "/"
      });
      NProgress.done(); // if current page is dashboard will not trigger	afterEach hook, so manually handle it
    } else if (to.path === "/home") {
      store.commit("SET_ROUTERS", []); //清空路由信息
      store.commit("SET_ASYNC_ROUTERS", []); //清空动态生成路由
      store.dispatch("delAllVisitedViews"); //清空所有打开的标签页
      store.commit("SET_SYSTEM_INFO", {
        id: "",
        name: ""
      }); //清空子系统信息
      resetRouter();
      localStorage.removeItem("systemId");
      next();
      NProgress.done();
    } else {
      if (store.getters.addRouters.length > 0) {
        if (auth) {
          next({ path: to.path });
        } else {
          next();
        }
      } else {
        const routerInfo = getConfig("router");
        if (routerInfo && routerInfo.local) {
          // 如果配置本地路由模式，跳过动态获取资源菜单
          return next();
        }
        if (typeof multiSystem.systemId === "string") {
          systemId = multiSystem.systemId;
        }
        initRouterMap(systemId).then(data => {
          // 没有菜单权限，不代表需要退出登录。
          // 现没数据时前端会mock欢迎页面，此处无需再控制是否有菜单数据
          if (auth) {
            return next({ path: to.path });
          } else {
            next({
              ...to,
              replace: true
            });
          }
        });
      }
    }
  } else {
    if (multiSystem && auth && auth.token) {
      setToken(auth.token);
      return next({
        path: to.path
      });
    }

    let whiteList = ["/login", "/auth-redirect", "/errors/401", "/errors/403"];
    const publicRouters = getConfig("public.routers");
    if (Array.isArray(publicRouters) && publicRouters.length) {
      whiteList = whiteList.concat(publicRouters);
    }
    /* has no token*/
    if (whiteList.indexOf(to.path) !== -1) {
      if (
        multiSystemEnabled &&
        multiSystem.loginURL &&
        to.path.indexOf("/login") > -1
      ) {
        location.href = multiSystem.loginURL;
      } else {
        next();
      }
    } else {
      NProgress.done();
      if (multiSystemEnabled && multiSystem.loginURL) {
        location.href = multiSystem.loginURL;
      } else {
        next(`/login?redirect=${to.path}`); // 否则全部重定向到登录页
      }
    }
  }
});

router.afterEach(() => {
  NProgress.done(); // finish progress bar
});

export { store, router };
