import EventBusMixin from "./mixins/global/eventBus";
export default {
  install(Vue) {
    // 注入全局事件注册全局mixin
    Vue.mixin(EventBusMixin);
    // 定义全局事件总线，全局弹窗管理，全局延时执行
    const EventBus = new Vue();
    Object.defineProperties(Vue.prototype, {
      $bus: {
        get() {
          return EventBus;
        }
      },
      delay: {
        get() {
          return t =>
            new Promise(resolve => {
              setTimeout(() => {
                resolve();
              }, t);
            });
        }
      },
      $dialog: {
        get() {
          return {
            open: (...args) => {
              let scope = "";
              let type = "";
              let params = {};
              if (args.length === 1) {
                [type] = args;
              } else if (args.length === 2) {
                if (typeof args[1] === "object") {
                  [type, params] = args;
                } else {
                  [scope, type] = args;
                }
              } else if (args.length === 3) {
                [scope, type, params] = args;
              }
              if (type) {
                this.$bus.$emit(
                  (scope || this.$route.name || this.$route.path) +
                    "DialogOpen",
                  type,
                  params
                );
              }
            }
          };
        }
      }
    });
  }
};
