<template>
  <div class="tree-container flex-vertical">
    <tree ref="tree" @node-click="nodeClick" :exclude="selectedVals"/>
    <el-button
      class="btn"
      :loading="loading"
      @click="confirm"
      :disabled="!this.checkedVal"
      type="primary"
      size="small"
    >确定</el-button>
  </div>
</template>

<script>
import SimpleTree from "../../widget/Tree/simpleRegion";
import { getRegion } from "../../api/fence";
export default {
  components: {
    tree: SimpleTree
  },
  props: {
    params: {
      type: Object,
      default: {}
    }
  },
  computed: {
    selectedVals() {
      return this.params.cars || [];
    }
  },
  data() {
    return {
      loading: false,
      checkedVal: ""
    };
  },
  methods: {
    nodeClick(data) {
      const { id } = data;
      // console.log(id);
      this.checkedVal = id;
    },
    closed() {
      const $tree = this.$refs.tree;
      if ($tree) {
        $tree.clearInput();
        $tree.change();
      }
    },
    open() {
      if (this.selectedVals.length) {
        this.$refs.tree.change(this.selectedVals);
      }
    },
    confirm() {
      const { index, methods } = this.params;
      // console.log(index);
      if (this.selectedVals.includes(this.checkedVal)) {
        this.checkedVal = "";
        return this.$message.warning("区域已在监控中");
      }
      this.selectedVals.push(this.checkedVal);
      this.loading = true;
      this.$refs.tree.clearInput();
      getRegion(this.checkedVal).then(data => {
        this.loading = false;
        this.checkedVal = "";
        // console.log(data);
        if (data && typeof methods === "function") {
          methods(index, data);
        }
        this.$emit("close");
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.tree-container {
  ::v-deep .region-tree {
    height: 340px;
    flex: none;
  }
  .btn {
    margin-top: 20px;
  }
}
</style>
