<template>
  <div class="tree-container flex-vertical">
    <tree ref="tree" :checkbox="false" @node-click="nodeClick" :exclude="cars" only-online />
    <div class="tag-group">
      <el-tag v-if="carNo" type effect="plain" closable @close="closeTag">{{ carNo }}</el-tag>
    </div>
    <el-button
      class="btn"
      :loading="loading"
      @click="confirm"
      :disabled="!this.carNo"
      type="primary"
      size="small"
    >确定</el-button>
  </div>
</template>

<script>
import SimpleTree from "../../components/Tree/simple";
import { fixPosition } from "../../utils/map";
import { getCars } from "../../api/monitor";
export default {
  components: {
    tree: SimpleTree
  },
  props: {
    params: {
      type: Object,
      default: {}
    }
  },
  computed: {
    cars() {
      return this.params.cars || [];
    }
  },
  data() {
    return {
      loading: false,
      carNo: ""
    };
  },
  methods: {
    closed() {
      this.$refs.tree.clearSearch();
      this.closeTag();
    },
    closeTag() {
      this.carNo = "";
    },
    nodeClick(id, data) {
      const { properties } = data;
      if (properties && properties.status > 0) {
        if (this.cars.includes(id)) {
          return this.$message.warning("车辆已在监控中");
        }
        this.carNo = id;
      } else {
        this.$message.warning("车辆离线");
      }
    },
    confirm() {
      const { index, methods } = this.params;
      if (this.cars.includes(this.carNo)) {
        this.carNo = "";
        return this.$message.warning("车辆已在监控中");
      }
      this.loading = true;
      getCars(this.carNo).then(data => {
        this.loading = false;
        if (data && data.length) {
          if (typeof methods === "function") {
            this.cars.push(this.carNo);
            methods(index, [fixPosition(data[0])]);
          }
        } else {
          this.$message.warning("暂无车辆定位信息");
        }
        this.$emit("close");
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.tree-container {
  ::v-deep .car-tree {
    height: 340px;
    flex: none;
  }
  .tag-group {
    margin-top: 10px;
  }
  .btn {
    margin-top: 10px;
  }
}
</style>
