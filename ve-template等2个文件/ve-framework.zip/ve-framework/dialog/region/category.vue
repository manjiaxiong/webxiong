<template>
  <el-form ref="form" :rules="rules" :model="form" label-width="80px">
    <el-form-item label="分类名称" prop="name">
      <el-input v-model="form.name" maxlength="20" show-word-limit placeholder="请输入分类名称"></el-input>
    </el-form-item>

    <el-form-item class="item-footer">
      <el-button type="primary" :loading="loading" @click="onSubmit">保存</el-button>
      <el-button @click="close">取消</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { saveRegion, saveRegionEdit } from "../../api/fence";
export default {
  props: {
    params: {
      type: Object,
      default: {}
    }
  },
  watch: {
    params(v) {
      if (v.regionName) {
        this.form.name = v.regionName;
      }
    }
  },
  data() {
    return {
      loading: false,
      form: {
        name: ""
      },
      rules: {
        name: [{ required: true, message: "请输入分类名称", trigger: "blur" }]
      }
    };
  },
  methods: {
    getRegionTreeData() {
      this.$bus.$emit("getRegionTreeData");
    },
    closed() {
      const form = this.$refs.form;
      if (form) {
        this.form.name = "";
        this.delay(200).then(() => {
          form.clearValidate();
        });
      }
    },
    close() {
      this.$emit("close");
    },
    onSubmit() {
      const form = this.$refs.form;
      form.validate(valid => {
        if (valid) {
          this.loading = true;
          let params = {
            regionName: this.form.name
          };
          if (this.params.pid > 0) {
            params.parentRegionId = this.params.pid;
          } else if (this.params.id > 0) {
            params.id = this.params.id;
          }
          (params.id > 0 ? saveRegionEdit : saveRegion)(params).then(data => {
            this.loading = false;
            form.resetFields();
            if (data === "success") {
              this.getRegionTreeData();
              this.$message({
                type: "success",
                message: params.id > 0 ? "保存成功" : "添加成功"
              });
              this.close();
            }
          });
        }
      });
    }
  },
  created() {
    const { regionName } = this.params;
    if (regionName) {
      this.form.name = regionName;
    }
  }
};
</script>

<style lang="scss" scoped>
.item-footer {
  margin-bottom: 0;
}
</style>
