<template>
  <div v-if="treeLoading" class="loading">
    <i class="el-icon-loading"></i>
  </div>
  <div v-else class="permission-tree">
    <el-tree
      node-key="id"
      :props="defaultProps"
      :data="data"
      :default-checked-keys="checkedIds"
      :default-expand-all="isTreeStatus"
      show-checkbox
      @check="handleCheckChange"
    ></el-tree>
    <!-- <el-button type="default" @click="cancel">取消</el-button> -->
  </div>
</template>

<script>
import { getRoleAuth, setRoleAuth, deleteRoleAuth } from "../../api/role";
export default {
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  inject:['isTreeStatus'],
  data() {
    return {
      treeLoading: true,
      data: [],
      checkedIds: [],
      authority: null,
      defaultProps: {
        label: "name"
      }
    };
  },
  methods: {
    // cancel() {},
    getCheckedIds(data = [], ids = []) {
      data.length &&
        data.forEach(item => {
          if (item.checked && (!item.children || !item.children.length)) {
            ids.push(item.id);
          }
          if (item.children && item.children.length) {
            this.getCheckedIds(item.children, ids);
          }
        });
      return ids;
    },
    handleCheckChange(data, status) {
      const { authority } = this;
      const { id } = data;
      if (authority && id) {
        if (status.checkedKeys.includes(id)) {
          setRoleAuth(authority, id);
        } else {
          deleteRoleAuth(authority, id);
        }
      }
    },
    closed() {
      this.treeLoading = true;
    },
    opened() {
      this.data = [];
      const { authority } = this.params.data || {};
      authority &&
        getRoleAuth(authority).then(data => {
          if (data && Array.isArray(data) && data.length) {
            this.checkedIds = this.getCheckedIds(data);
            this.data = data;
            this.authority = authority;
          } else {
            this.data = [];
          }
          this.treeLoading = false;
        }).catch(e=>{
          this.treeLoading = false;
          this.$emit("close");
        })
    }
  }
};
</script>

<style lang="scss" scoped>
.loading {
  text-align: center;
  i {
    font-size: 32px;
    color: #999;
  }
}
.permission-tree {
  height: 400px;
  overflow: auto;
}
</style>
