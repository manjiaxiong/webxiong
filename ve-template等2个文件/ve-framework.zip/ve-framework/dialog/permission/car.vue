<template>
  <div>
    <el-radio-group class="v-radio-group" v-if="params.tabs" v-model="radio" @change="change">
      <el-radio-button :key="key" v-for="(item, key) in params.tabs" :label="key">{{ item.name }}</el-radio-button>
    </el-radio-group>

    <div v-if="treeLoading" class="loading">
      <i class="el-icon-loading"></i>
    </div>
    <div v-else class="permission-tree flex-vertical">
      <simple-tree
        ref="tree"
        :default-data="data"
        :checked-keys="checkedIds"
        :placeholder="params.placeholder"
        check-all
        local-search
        :type="2"
      ></simple-tree>
      <div class="buttons">
        <el-button type="default" @click="cancel">取消</el-button>
        <el-button type="primary" :loading="loading" @click="confirm">确定</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import SimpleTree from "../../components/Tree/simple";
import {
  purviews,
  savePurviews,
  baseURL,
  setBaseURL
} from "../../api/permission";
export default {
  components: {
    SimpleTree
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      radio: 0,
      data: [],
      checkedIds: [],
      id: null,
      loading: false,
      treeLoading: true
    };
  },
  methods: {
    change(radio) {
      const data = this.params.tabs[radio];
      if (data) {
        if (typeof data.baseURL === "string") {
          setBaseURL(data.baseURL);
        } else if (radio === 0) {
          setBaseURL(baseURL);
        }
        this.closed();
        this.open();
      }
    },
    cancel() {
      this.$emit("close");
    },
    confirm() {
      if (this.id) {
        this.loading = true;
        const params = {
          uid: this.id,
          purviews: []
        };
        const checkedNodes = this.$refs.tree.getCheckedNodes(false, true);
        if (checkedNodes.length) {
          params.purviews = checkedNodes.map(v => ({
            id: v.id,
            level: v.level,
            pid: v.pid
          }));
        }
        savePurviews(params).then(data => {
          // console.log(data);
          this.loading = false;
          this.cancel();
          this.$message.success("权限设置成功");
        });
      }
    },
    getCheckedIds(data = []) {
      if (data && data.length) {
        return data
          .filterTree(v => v.checked, {
            parent: false
          })
          .map(v => v.id);
      }
      return [];
    },
    closed() {
      this.treeLoading = true;
    },
    open() {
      const data = this.params.data || {};
      const id = data.username || data.id;
      if (id) {
        this.id = id;
        purviews(id).then(data => {
          if (data && Array.isArray(data) && data.length) {
            this.checkedIds = this.getCheckedIds(data);
            this.data = data;
          } else {
            this.data = [];
          }
          this.treeLoading = false;
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.v-radio-group {
  user-select: none;
  width: 100%;
  display: flex;
  margin-bottom: 15px;
  .el-radio-button {
    flex: 1;
    ::v-deep .el-radio-button__inner {
      width: 100%;
    }
  }
}
.loading {
  text-align: center;
  i {
    font-size: 32px;
    color: #999;
  }
}
.permission-tree {
  ::v-deep .car-tree {
    height: 310px;
    flex: none;
  }

  .buttons {
    margin-top: 20px;
    display: flex;
    justify-content: flex-end;
  }
}
</style>
