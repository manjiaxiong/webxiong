<!--
 * @Author: your name
 * @Date: 2020-11-07 17:19:52
 * @LastEditTime: 2020-12-05 18:23:04
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ve-framework\views\welcome\index.vue
-->
<template>
  <div class="welcome no-right">
    <div class="img-dv">
      <img :src="src" alt />
      <span>{{$t('_tm.errorPage.403')}}</span>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      src: require("../../assets/403_images/no-right.png")
    };
  }
};
</script>
<style lang="scss" scoped>
.welcome {
  padding: 20px;
}
.no-right {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 60px;
  left: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: #fff;
}
.no-right .img-dv {
  width: 400px;
}
.no-right .img-dv img {
  width: auto;
  height: auto;
  max-width: 100%;
  max-height: 100%;
}
.no-right .img-dv span {
  display: block;
  font-size: 28px;
  padding-top: 10px;
  color: #707070;
  text-align: center;
}
</style>
