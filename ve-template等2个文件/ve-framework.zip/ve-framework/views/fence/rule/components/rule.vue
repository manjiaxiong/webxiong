<!--
 * @Author: your name
 * @Date: 2020-11-07 17:19:52
 * @LastEditTime: 2020-12-09 19:51:37
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \ve-framework\views\fence\rule\components\rule.vue
-->
<template>
  <div class="wrapper-content">
    <div class="toolbar">
      <el-button type="primary" size="mini" icon="el-icon-plus" @click="open()">新增规则</el-button>
    </div>

    <el-table class="rule-table" border :data="data">
      <el-table-column
        :key="key"
        v-for="(item, key) in columns"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :align="item.aligin || 'center'"
        :formatter="(a, b, c) => item.render ? item.render(c) : c"
      ></el-table-column>

      <el-table-column :label="$t('_tm.table.columns.operation')" width="200" align="center">
        <template #default="{ row: item }">
          <el-button type="primary" icon="el-icon-edit-outline" size="mini" @click="open(item)">编辑</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="remove(item)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getRuleList, deleteRule } from "../../../../api/fence";

export default {
  props: {
    type: Number,
    columns: Array,
    dialog: Object
  },
  data() {
    return {
      data: []
    };
  },
  methods: {
    open(params) {
      let titlePrefix = params ? "编辑" : "新增";
      this.$dialog.open("rule", this.type, {
        title: titlePrefix + this.dialog.title,
        type: this.type,
        refresh: this.refresh,
        data: params
      })
    },
    remove(item) {
      const { id } = item;
      if (id > 0) {
        this.$confirm("此操作将永久删除该数据, 是否继续?", "提示", {
          type: "warning"
        })
          .then(() => {
            deleteRule(id).then(data => {
              if (data === 1) {
                this.refresh();
                this.$message.success("删除成功!");
              } else {
                this.$message.error("规则存在关联，不能删除");
              }
            });
          })
          .catch(() => {});
      }
    },
    refresh() {
      getRuleList(this.type).then(data => {
        if (data && data.length) {
          this.data = data;
        } else {
          this.data = [];
        }
      });
    }
  },
  created() {
    this.refresh();
  }
};
</script>

<style lang="scss" scoped>
.wrapper-content {
  .toolbar {
    text-align: right;
  }
  .rule-table {
    margin-top: 10px;
  }
}
</style>
