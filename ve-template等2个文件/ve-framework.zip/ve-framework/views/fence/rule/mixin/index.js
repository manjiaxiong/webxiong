import { saveRuleAdd, saveRuleEdit } from "../../../../api/fence";
export default {
  props: {
    params: {
      type: Object,
      default: null
    }
  },
  watch: {
    // "params.data"(v) {
    //   console.log("watch", v);
    //   if (v) {
    //     this.initFormData(v);
    //   } else {
    //     this.resetFields();
    //   }
    // }
  },
  data() {
    return {
      loading: false
    };
  },
  methods: {
    opened() {
      if (this.params && this.params.data) {
        // console.log("mounted");
        this.initFormData(this.params.data);
      }
    },
    closed() {
      this.resetFields();
    },
    refresh() {
      const { refresh } = this.params;
      if (typeof refresh === "function") {
        refresh();
      }
    },
    close() {
      // this.clearValidate();
      this.$emit("close");
    },
    resetFields() {
      this.clearValidate();
      Object.keys(this.form).forEach(v => {
        if (typeof this.form[v] === "number") {
          this.form[v] = ["region", "count"].includes(v) ? "" : 0;
        } else if (Array.isArray(this.form[v])) {
          this.form[v] = v === "time" ? "" : [];
        } else if (typeof this.form[v] === "string") {
          this.form[v] = "";
        }
      });
    },
    formatTime(t) {
      return [String.zero(t.getHours()), String.zero(t.getMinutes())].join(":");
    },
    formatType(level) {
      let fix = 1;
      if (this.$project === "car" && level === 2) {
        fix = 2;
      }
      return level + fix;
    },
    clearValidate() {
      this.$refs.form.clearValidate();
    },
    onSubmit() {
      const form = this.$refs.form;
      form.validate(valid => {
        if (valid) {
          this.loading = true;
          const params = this.formatParams();
          if (this.params && this.params.data) {
            const { id } = this.params.data;
            if (id > 0) {
              params.id = id;
            }
          }
          // console.log(params);
          (params.id > 0 ? saveRuleEdit : saveRuleAdd)(params).then(data => {
            if (data === "success") {
              this.$message({
                type: "success",
                message: params.id > 0 ? "修改成功" : "添加成功"
              });
              this.refresh();
              this.close();
            }
            this.loading = false;
            // console.log(data);
          });
        }
      });
    }
  }
};
