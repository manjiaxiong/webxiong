<template>
  <div class="main-content no-select">
    <el-tabs type="card">
      <el-tab-pane lazy :key="key" v-for="(item, key) in tabs" :label="item.name">
        <rule :type="item.type" :dialog="dialogMaps[item.type]" :columns="item.columns" />
      </el-tab-pane>
    </el-tabs>

    <v-dialog scope="rule" :dialogMaps="dialogMaps" :modalClose="false"></v-dialog>
  </div>
</template>

<script>
import Rule from "./components/rule";
import Region from "./dialog/region";
// import Speed from "./dialog/speed";
import Gather from "./dialog/gather";
import Cross from "./dialog/cross";
export default {
  components: {
    Rule
  },
  data() {
    return {
      tabs: [
        {
          name: "区域规则",
          type: 1,
          columns: [
            {
              prop: "ruleName",
              label: "规则名称",
              width: 280
            },
            {
              prop: "RULE_REGION_TYPE_NAME",
              label: "规则类型",
              width: 160
            },
            {
              prop: "regionName",
              label: "区域名称"
            },
            {
              prop: "RULE_REGION_BEGIN_TIME_VALUE",
              label: "开始时间",
              width: 120
            },
            {
              prop: "RULE_REGION_END_TIME_VALUE",
              label: "结束时间",
              width: 120
            }
          ]
        },
        // {
        //   name: "超速规则",
        //   type: 2,
        //   columns: [
        //     {
        //       prop: "ruleName",
        //       label: "规则名称"
        //     },
        //     {
        //       prop: "RULE_SPEED_NUM_VALUE",
        //       label: "限速",
        //       render(v) {
        //         return v + " Km/h";
        //       }
        //     },
        //     {
        //       prop: "RULE_SPEED_BEGIN_TIME_VALUE",
        //       label: "开始时间"
        //     },
        //     {
        //       prop: "RULE_SPEED_END_TIME_VALUE",
        //       label: "结束时间"
        //     }
        //   ]
        // },
        {
          name: "聚集规则",
          type: 3,
          columns: [
            {
              prop: "ruleName",
              label: "规则名称",
              width: 320
            },
            {
              prop: "RULE_GATHER_NUM_VALUE",
              label: "最大聚集车辆"
            },
            {
              prop: "RULE_GATHER_BEGIN_TIME_VALUE",
              label: "开始时间"
            },
            {
              prop: "RULE_GATHER_END_TIME_VALUE",
              label: "结束时间"
            }
          ]
        },
        {
          name: "跨区域运营",
          type: 4,
          columns: [
            {
              prop: "ruleName",
              label: "规则名称",
              width: 280
            },
            {
              prop: "regionName",
              label: "区域名称"
            },
            {
              prop: "RULE_OUTREGION_VOICE_VALUE",
              label: "消息提示"
            }
          ]
        }
      ],
      dialogMaps: {
        1: {
          title: "区域规则",
          component: Region
        },
        // 2: {
        //   title: "超速规则",
        //   component: Speed
        // },
        3: {
          title: "聚集规则",
          component: Gather
        },
        4: {
          title: "跨区域运营",
          component: Cross
        }
      }
    };
  },
  methods: {
    onRefreshData() {
      this.$bus.$emit("getRegionTreeData");
    }
  }
};
</script>
