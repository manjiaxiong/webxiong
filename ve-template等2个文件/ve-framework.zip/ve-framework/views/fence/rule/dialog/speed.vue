<template>
  <el-form ref="form" :rules="rules" :model="form" label-width="80px">
    <el-form-item label="规则名称" prop="name">
      <el-input v-model="form.name" placeholder="规则名称"></el-input>
    </el-form-item>
    <el-form-item label="最高速度" prop="speed">
      <el-input v-model="form.speed" placeholder="最高速度">
        <template slot="append">Km/h</template>
      </el-input>
    </el-form-item>
    <el-form-item label="区域" prop="region">
      <region-select v-model="form.region"/>
    </el-form-item>
    <el-form-item label="规则分配" prop="car">
      <car-select v-model="form.car"/>
    </el-form-item>
    <el-form-item label="时间范围" prop="time">
      <el-time-picker
        is-range
        arrow-control
        :editable="false"
        v-model="form.time"
        format="HH:mm"
        :picker-options="{
          format: 'HH:mm'
        }"
        range-separator="至"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        placeholder="选择时间范围"
      ></el-time-picker>
    </el-form-item>
    <el-form-item label="语音提示" prop="voiceTips">
      <el-input type="textarea" v-model="form.voiceTips"></el-input>
    </el-form-item>

    <el-form-item label="规则说明" class="rule-info">
      <p>① 车辆在指定时间范围内；</p>
      <p>② 行驶速度持续超过《最高速度》；</p>
      <p>③ 如果指定区域，只在该区域内才会产生超速报警；</p>
    </el-form-item>

    <el-form-item class="dialog-no-mb align-right">
      <el-button @click="close">取消</el-button>
      <el-button type="primary" :loading="loading" @click="onSubmit">保存</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import RegionSelect from "../../../../widget/Select/region";
import CarSelect from "../../../../widget/Select/car";
import mixin from "../mixin";
import { getCarByRuleId } from "../../../../api/fence";
export default {
  components: {
    RegionSelect,
    CarSelect
  },
  mixins: [mixin],
  data() {
    return {
      form: {
        name: "",
        speed: "",
        time: "",
        region: "",
        car: [],
        voiceTips: ""
      },
      rules: {
        name: [{ required: true, message: "请输入规则名称", trigger: "blur" }],
        speed: [{ required: true, message: "请输入最高速度", trigger: "blur" }],
        // region: [{ required: true, message: "请选择区域", trigger: "focus" }],
        car: [{ required: true, message: "请选择规则分配", trigger: "focus" }],
        time: [{ required: true, message: "请选择时间范围", trigger: "blur" }]
      }
    };
  },
  methods: {
    initFormData(data) {
      const {
        id,
        ruleName,
        RULE_SPEED_NUM_VALUE: speed,
        RULE_SPEED_BEGIN_TIME_VALUE: stime,
        RULE_SPEED_END_TIME_VALUE: etime,
        RULE_SPEED_VOICE_VALUE: voiceTips
      } = data;
      if (id > 0) {
        getCarByRuleId(id).then(data => {
          if (data.length) {
            this.form.car = data;
          }
        });
      }
      this.form.name = ruleName;
      this.form.speed = speed;
      this.form.region = data.regionId;
      this.form.voiceTips = voiceTips;
      const starttime = stime.split(":");
      const endtime = etime.split(":");
      this.form.time = [
        new Date(2019, 4, 21, starttime[0], starttime[1]),
        new Date(2019, 4, 21, endtime[0], endtime[1])
      ];
    },
    formatParams() {
      const { region, car, name, time, speed, voiceTips } = this.form;
      let params = {
        ruleName: name,
        ruleType: this.params.type,
        ruleParameterEntities: [],
        carList: []
      };
      if (region) {
        params.regionId = region;
      }
      if (car.length) {
        params.carList = car.map(v => {
          return {
            refContent: v.id,
            refType: this.formatType(v.level)
          };
        });
      }
      if (time && speed) {
        const paramList = [
          {
            key: "RULE_SPEED_NUM",
            value: speed
          },
          {
            key: "RULE_SPEED_BEGIN_TIME",
            value: this.formatTime(time[0])
          },
          {
            key: "RULE_SPEED_END_TIME",
            value: this.formatTime(time[1])
          }
        ];
        if (voiceTips) {
          paramList.push({
            key: "RULE_SPEED_VOICE",
            value: voiceTips
          });
        }
        paramList.forEach((v, k) => {
          const param = {
            parameterName: v.key,
            parameterValue: v.value
          };
          params.ruleParameterEntities.push(param);
        });
      }
      return params;
    }
  }
};
</script>

<style lang="scss" scoped>
.el-select {
  width: 100%;
}

.rule-info {
  p {
    line-height: 1;
    padding: 0;
    margin-top: 10px;
  }
}
</style>
