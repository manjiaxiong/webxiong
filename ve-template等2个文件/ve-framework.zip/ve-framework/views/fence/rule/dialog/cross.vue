<template>
  <el-form ref="form" :rules="rules" :model="form" label-width="80px">
    <el-form-item label="规则名称" prop="name">
      <el-input v-model="form.name" placeholder="规则名称"></el-input>
    </el-form-item>

    <el-form-item label="区域" prop="region">
      <region-select v-model="form.region" />
    </el-form-item>
    <el-form-item label="规则分配" prop="car">
      <car-select ref="carSelect" v-model="form.car" />
    </el-form-item>
    <el-form-item label="消息提示" prop="voiceTips">
      <el-input type="textarea" v-model="form.voiceTips"></el-input>
    </el-form-item>

    <el-form-item label="规则说明" class="rule-info">
      <p>① 乘客上下车位置都不在设定的区域范围内，将产生一次报警；</p>
    </el-form-item>

    <el-form-item class="dialog-no-mb align-right">
      <el-button @click="close">取消</el-button>
      <el-button type="primary" :loading="loading" @click="onSubmit">保存</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import RegionSelect from "../../../../widget/Select/region";
import CarSelect from "../../../../widget/Select/car";
import { getCarByRuleId } from "../../../../api/fence";
import mixin from "../mixin";
export default {
  components: {
    RegionSelect,
    CarSelect
  },
  mixins: [mixin],
  data() {
    return {
      form: {
        name: "",
        region: "",
        car: [],
        voiceTips: ""
      },
      rules: {
        name: [{ required: true, message: "请输入规则名称", trigger: "blur" }],
        region: [{ required: true, message: "请选择区域", trigger: "change" }],
        car: [{ required: true, message: "请选择规则分配", trigger: "change" }]
      }
    };
  },
  methods: {
    closed() {
      const $form = this.$refs.form;
      if ($form) {
        this.form = {
          name: "",
          region: "",
          car: [],
          voiceTips: ""
        };
        // $form.resetFields();
        this.delay(200).then(() => {
          $form.clearValidate();
        });
      }
    },
    initFormData(data) {
      const { id, ruleName, RULE_OUTREGION_VOICE_VALUE: voiceTips } = data;
      if (id > 0) {
        getCarByRuleId(id).then(data => {
          if (data.length) {
            this.$refs.carSelect.setData(data);
            this.form.car = data;
          }
        });
      }
      this.form.name = ruleName;
      this.form.region = data.regionId;
      this.form.voiceTips = voiceTips;
    },
    formatParams() {
      const { region, car, name, voiceTips } = this.form;
      let params = {
        ruleName: name,
        ruleType: this.params.type,
        ruleParameterEntities: [],
        carList: []
      };
      if (region) {
        params.regionId = region;
      }
      if (car.length) {
        params.carList = car.map(v => {
          return {
            refContent: v.id,
            refType: this.formatType(v.level)
          };
        });
      }
      const paramList = [];
      if (voiceTips) {
        paramList.push({
          key: "RULE_OUTREGION_VOICE",
          value: voiceTips
        });
      }
      paramList.forEach((v, k) => {
        const param = {
          parameterName: v.key,
          parameterValue: v.value
        };
        params.ruleParameterEntities.push(param);
      });
      return params;
    }
  }
};
</script>

<style lang="scss" scoped>
.el-select {
  width: 100%;
}

.rule-info {
  p {
    line-height: 1;
    padding: 0;
    margin-top: 10px;
  }
}
</style>
