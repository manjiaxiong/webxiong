<template>
  <el-form ref="form" :rules="rules" :model="form" label-width="80px">
    <el-form-item label="规则名称" prop="name">
      <el-input v-model="form.name" placeholder="规则名称"></el-input>
    </el-form-item>
    <el-form-item label="规则类型" prop="type">
      <el-select v-model="form.type" placeholder="请选择规则类型">
        <el-option :key="key" v-for="(item, key) in options" :label="item.name" :value="item.value"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="区域" prop="region">
      <region-select v-model="form.region" />
    </el-form-item>
    <el-form-item label="规则分配" prop="car">
      <car-select ref="carSelect" v-model="form.car" />
    </el-form-item>
    <el-form-item label="时间范围" prop="time">
      <el-time-picker
        is-range
        arrow-control
        :editable="false"
        v-model="form.time"
        format="HH:mm"
        :picker-options="{
          format: 'HH:mm'
        }"
        range-separator="至"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        placeholder="选择时间范围"
      ></el-time-picker>
    </el-form-item>
    <el-form-item label="语音提示" prop="voiceTips">
      <el-input type="textarea" v-model="form.voiceTips"></el-input>
    </el-form-item>

    <el-form-item label="规则说明" class="rule-info">
      <p>① 跨出区域报警：车辆跨出指定区域后，将产生一次报警；</p>
      <p>② 跨入跨出区域：车辆跨入或跨出指定区域后，将产生一次报警。</p>
    </el-form-item>

    <el-form-item class="dialog-no-mb align-right">
      <el-button @click="close">取消</el-button>
      <el-button type="primary" :loading="loading" @click="onSubmit">保存</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import RegionSelect from "../../../../widget/Select/region";
import CarSelect from "../../../../widget/Select/car";
import { getCarByRuleId } from "../../../../api/fence";
import mixin from "../mixin";
export default {
  components: {
    RegionSelect,
    CarSelect
  },
  mixins: [mixin],
  data() {
    return {
      form: {
        name: "",
        type: "",
        time: "",
        region: "",
        car: [],
        voiceTips: ""
      },
      options: [
        {
          name: "禁止跨入区域",
          value: "1"
        },
        {
          name: "禁止跨出区域",
          value: "2"
        }
      ],
      rules: {
        name: [{ required: true, message: "请输入规则名称", trigger: "blur" }],
        type: [
          { required: true, message: "请选择规则类型", trigger: "change" }
        ],
        region: [{ required: true, message: "请选择区域", trigger: "change" }],
        car: [{ required: true, message: "请选择规则分配", trigger: "change" }],
        time: [{ required: true, message: "请选择时间范围", trigger: "blur" }]
      }
    };
  },
  methods: {
    closed() {
      const $form = this.$refs.form;
      if ($form) {
        this.form = {
          name: "",
          type: "",
          time: "",
          region: "",
          car: [],
          voiceTips: ""
        };
        // $form.resetFields(); // 使用此方法清空会有bug
        this.delay(200).then(() => {
          $form.clearValidate();
        });
      }
    },
    initFormData(data) {
      const {
        id,
        ruleName,
        RULE_REGION_TYPE_VALUE: type,
        RULE_REGION_BEGIN_TIME_VALUE: stime,
        RULE_REGION_END_TIME_VALUE: etime,
        RULE_REGION_VOICE_VALUE: voiceTips
      } = data;
      if (id > 0) {
        getCarByRuleId(id).then(data => {
          if (data.length) {
            this.$refs.carSelect.setData(data);
            this.form.car = data;
          }
        });

        this.form.name = ruleName;
        this.form.type = type;
        this.form.region = data.regionId;
        this.form.voiceTips = voiceTips;
        const starttime = stime.split(":");
        const endtime = etime.split(":");
        this.form.time = [
          new Date(2019, 4, 21, starttime[0], starttime[1]),
          new Date(2019, 4, 21, endtime[0], endtime[1])
        ];
      }
    },
    formatParams() {
      const { region, car, name, time, type, voiceTips } = this.form;
      let params = {
        ruleName: name,
        ruleType: this.params.type,
        ruleParameterEntities: [],
        carList: []
      };
      if (region) {
        params.regionId = region;
      }
      if (car.length) {
        params.carList = car.map(v => {
          return {
            refContent: v.id,
            refType: this.formatType(v.level)
          };
        });
      }
      if (time && type) {
        const paramList = [
          {
            key: "RULE_REGION_TYPE",
            value: type
          },
          {
            key: "RULE_REGION_BEGIN_TIME",
            value: this.formatTime(time[0])
          },
          {
            key: "RULE_REGION_END_TIME",
            value: this.formatTime(time[1])
          }
        ];
        if (voiceTips) {
          paramList.push({
            key: "RULE_REGION_VOICE",
            value: voiceTips
          });
        }
        paramList.forEach((v, k) => {
          const param = {
            parameterName: v.key,
            parameterValue: v.value
          };
          if (v.key === "RULE_REGION_TYPE") {
            const filter = this.options.find(m => m.value === v.value);
            if (filter) {
              param.parameterDesc = filter.name;
            }
          }
          params.ruleParameterEntities.push(param);
        });
      }
      return params;
    }
  }
};
</script>

<style lang="scss" scoped>
.el-select {
  width: 100%;
}

.rule-info {
  p {
    line-height: 1;
    padding: 0;
    margin-top: 10px;
  }
}
</style>
