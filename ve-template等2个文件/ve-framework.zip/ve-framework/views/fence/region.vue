<template>
  <div class="flex full-height">
    <collapse class="slideMenu">
      <tree ref="tree" />
    </collapse>

    <div class="auto-fill flex-vertical">
      <v-map class="auto-fill" :params="params" :tree="tree" />
    </div>

    <v-dialog scope="region" width="30%" :dialogMaps="dialogMaps" />
  </div>
</template>

<script>
import Tree from "../../widget/Tree/region";
import Map from "../../widget/Map/region";
import Category from "../../dialog/region/category";
import Region from "../../dialog/region/region";

export default {
  components: {
    Tree,
    "v-map": Map
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      tree: null,
      dialogMaps: {
        category: {
          title: "新增分类",
          modalClose: false,
          component: Category
        },
        region: {
          title: "新增区域",
          modalClose: false,
          component: Region
        }
      }
    };
  },
  mounted() {
    this.tree = this.$refs.tree;
  }
};
</script>

<style lang="scss" scoped>
.slideMenu {
  width: 285px;
  height: 100%;
  background-color: #fff;
  border-right: 1px solid #ccc;
}
</style>
