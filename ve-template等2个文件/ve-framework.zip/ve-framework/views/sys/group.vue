<template>
  <div class="main-content">
    <auto-table ref="table" :methods="methods" :controls="controls" :table="table" :dialog="dialog">
      <template #enabled="{row}">
        <span
          class="enablestate"
          :class="row.enabled === 0?'error' : ''"
        >{{row.enabled ===0?"禁用":"启用"}}</span>
      </template>
    </auto-table>
  </div>
</template>

<script>
import { getToken } from "../../utils/auth";
import {
  updateGroup,
  addGroup,
  deleteGroup,
  apiGroupDisabled,
  apiGroupEnabled
} from "../../api/group";
export default {
  props: {
    dialogMaps: {
      type: Object,
      default: () => ({})
    },
    buttonsPrepend: {
      type: Array,
      default: () => []
    },
    operationWidth: {
      type: Number,
      default: 280
    }
  },
  data() {
    return {
      id: null,
      methods: {
        add: addGroup,
        update: updateGroup,
        remove: deleteGroup
      },
      controls: [],
      dialog: {
        maps: {
          ...this.dialogMaps
        },
        options: [
          {
            id: "organization",
            name: this.$t('_tm.table.columns.group.organization'),
            placeholder: this.$t('_tm.placeholders.message_10'),
            maxlength: 40,
            showWordLimit: true,
            required: true
          },
          {
            id: "alias",
            name: this.$t('_tm.table.columns.group.alias'),
            placeholder: this.$t('_tm.placeholders.message_11'),
            maxlength: 40,
            required: true,
            showWordLimit: true
          },
          {
            id: "tenant",
            name: this.$t('_tm.table.columns.group.tenant'),
            required: true,
            radio: () => {
              return [
                {
                  id: "0",
                  name: this.$t('_tm.table.columns.group.type_0')
                },
                {
                  id: "1",
                  name: this.$t('_tm.table.columns.group.type_1')
                }
              ];
            },
            show: type => {
              return type === "add";
            }
          },
          {
            id: "remarks",
            name: this.$t('_tm.table.columns.remarks'),
            placeholder: this.$t('_tm.table.columns.remarks')
          }
        ]
      },
      table: {
        url: "/authority/organization/tree",
        showPagination: false,
        showOrderNo: false,
        rowKey: "id",
        defaultExpandAll: true,
        // align: "center",
        operation: {
          width: this.operationWidth + "px",
          type: "text",
          size: "mini",
          buttons: [
            ...this.buttonsPrepend,
            {
              name: this.$t('_tm.table.columns.group.addChildren'),
              command: "add",
              disabled: ({ type }) => {
                return type === 3;
              }
            },
            {
              name: this.$t('_tm.table.actions.edit'),
              command: "edit"
            },
            {
              name: this.$t('_tm.table.actions.enable'),
              click: ({ id }) => {
                if (!id) return;
                apiGroupEnabled(id).then(() => {
                  this.$refs.table.refresh();
                });
              },
              show: ({ enabled }) => {
                return enabled === 0;
              }
            },
            {
              name: this.$t('_tm.table.actions.disable'),
              click: ({ id }) => {
                if (!id) return;
                this.$confirm(this.$t("_tm.messages.tip_14"), this.$t("_tm.dialog.tip"), {
                  type: "warning"
                }).then(() => {
                  apiGroupDisabled(id).then(() => {
                    this.$refs.table.refresh();
                  });
                });
              },
              show: ({ enabled }) => {
                return enabled === 1;
              }
            },
            {
              name: this.$t('_tm.table.actions.delete'),
              command: "remove"
            }
          ]
        },
        columns: [
          {
            label: this.$t('_tm.table.columns.group.organization'),
            prop: "organization",
            align: "left"
          },
          {
            label: this.$t('_tm.table.columns.group.alias'),
            prop: "alias",
            align: "left",
            width: 200
          },
          {
            label: this.$t('_tm.table.columns.tenant'),
            prop: "tenant",
            render: ({ tenant }) => {
              return tenant === 1 ? this.$t('_tm.table.columns.group.type_2') :  this.$t('_tm.table.columns.group.type_0');
            }
          },
          {
            label: this.$t('_tm.table.columns.enabled'),
            prop: "enabled",
            slotName: "enabled"
          },
          {
            label: this.$t('_tm.table.columns.remarks'),
            prop: "remarks"
          },
          {
            label: this.$t('_tm.table.columns.createDate'),
            prop: "createDate",
            width: 160
          }
        ]
      }
    };
  },
  mounted() {
    const token = getToken();
    if (token) {
      const userInfo = JSON.parse(token);
      if (userInfo && userInfo.props) {
        const { authorities } = userInfo.props;
        if (authorities) {
          const roleDev = authorities.find(v => v.authority === "ROLE_DEV");
          if (roleDev) {
            this.controls.push({
              name: this.$t('_tm.table.actions.addOrganization'),
              command: "add"
            });
          }
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.enablestate {
  color: #1fba00;
  &.error {
    color: red;
  }
}
</style>
