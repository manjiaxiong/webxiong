<template>
  <div class="main-content">
    <auto-table
      :name="$t('_tm.common.role')"
      ref="table"
      primaryKey="authority"
      :methods="methods"
      :controls="controls"
      :table="table"
      :dialog="dialog"
    >
      <template #enabled="{ row }">
        <span class="enablestate" :class="row.enabled === 0 ? 'error' : ''">{{
          row.enabled === 0 ? "禁用" : "启用"
        }}</span>
      </template>
    </auto-table>
  </div>
</template>

<script>
import MenuAuth from "./dialog/menuAuth";
import DataAuth from "./dialog/dataAuth";
import {
  update,
  add,
  remove,
  apiRoleDisabled,
  apiRoleEnabled
} from "../../../api/role";
import { parseTime } from "../../../utils";
export default {
  props: {
    isTreeOpen: {
      type: Boolean,
      default: false
    },
    dialogMaps: {
      type: Object,
      default: () => ({})
    },
    // 追加的按钮
    buttonsPrepend: {
      type: Array,
      default: () => []
    },
    // 操作栏宽度
    operationWidth: {
      type: Number,
      default: 220
    },
    // 数据角色权限接口参数：查询模式,
    // 0:联动查询(兼容老的权限存储方案，存储所有树节点到末级节点),
    // 1:固定查询(仅存储勾选的节点，支持授权到非末级)
    model: {
      type: Number,
      default: 0
    },
    // 数据角色权限接口参数：下探层级,默认为空
    level: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      methods: {
        add,
        update,
        remove
      },
      dialog: {
        maps: {
          menuAuth: {
            title: this.$t('_tm.dialog.roleSettings'),
            width: "400px",
            modalClose: true,
            component: MenuAuth
          },
          dataAuth: {
            title: this.$t('_tm.dialog.dataSettings'),
            width: "400px",
            modalClose: true,
            component: DataAuth
          },
          ...this.dialogMaps
        },
        options: [
          {
            id: "alias",
            name: this.$t('_tm.table.columns.role.alias'),
            placeholder: this.$t('_tm.placeholders.message_14'),
            maxlength: 30,
            showWordLimit: true,
            required: true
          },
          {
            id: "roleType",
            name: this.$t('_tm.table.columns.role.roleType'),
            required: true,
            radio: () => {
              return [
                {
                  id: 0,
                  name: this.$t('_tm.table.columns.role.roleFeat')
                },
                {
                  id: 1,
                  name: this.$t('_tm.table.columns.role.roleData')
                }
              ];
            },
            default: () => 0,
            show: (type, form) => {
              return type === "add";
            }
          },
          {
            id: "dataType",
            name: this.$t('_tm.common.dataType'),
            required: true,
            select: () => {
              return this.$dict
                .getFormatByIdName("datatype")
                .map(item =>
                  Object.assign({}, item, { id: parseInt(item.id) })
                );
            },
            show: (type, form) => {
              return form.roleType && !!parseInt(form.roleType);
            }
          },
          {
            id: "remarks",
            name: this.$t('_tm.table.columns.role.remarks'),
            placeholder: this.$t('_tm.placeholders.message_13'),
            maxlength: 100,
            showWordLimit: true,
            textarea: {
              autosize: {
                minRows: 3,
                maxRows: 6
              }
            }
          }
        ]
      },
      table: {
        url: "/authority/roles",
        pagination: "urlParams",
        pageIndexKey: "page",
        pageSizeKey: "size",
        operation: {
          width: this.operationWidth + "px",
          type: "text",
          size: "mini",
          buttons: [
            ...this.buttonsPrepend,
            {
              name: this.$t('_tm.table.actions.setRole'),
              // command: "menuAuth",
              auth: "role_permission",
              click: data => {
                if (data.roleType === 0) {
                  this.$dialog.open("menuAuth", { data });
                } else {
                  this.$dialog.open("dataAuth", {
                    data,
                    model: this.model,
                    level: this.level
                  });
                }
              }
              // disabled: ({ enabled }) => {
              //   return enabled === 0;
              // }
            },
            {
              name: this.$t('_tm.table.actions.edit'),
              command: "edit",
              auth: "role_edit",
              icon: true
            },
            {
              name: this.$t('_tm.table.actions.enable'),
              click: ({ authority }) => {
                if (!authority) return;
                apiRoleEnabled(authority).then(() => {
                  this.$refs.table.refresh();
                });
              },
              show: ({ enabled }) => {
                return enabled === 0;
              }
            },
            {
              name: this.$t('_tm.table.actions.disable'),
              click: ({ authority }) => {
                if (!authority) return;
                this.$confirm("此操作将禁用角色, 是否继续?", "提示", {
                  type: "warning"
                }).then(() => {
                  apiRoleDisabled(authority).then(() => {
                    this.$refs.table.refresh();
                  });
                });
              },
              show: ({ enabled }) => {
                return enabled === 1;
              }
            },
            {
              name: this.$t('_tm.table.actions.delete'),
              command: "remove",
              auth: "role_delete",
              disabled: data => {
                let { builtIn } = data;
                return !!builtIn;
              },
              icon: true
            }
          ]
        },
        columns: [
          {
            label: this.$t('_tm.table.columns.alias'),
            prop: "alias",
            width: 180
          },
          {
            label: this.$t('_tm.table.columns.role.roleType'),
            prop: "roleType",
            render: ({ roleType }) => {
              return roleType === 0 ? this.$t('_tm.table.columns.role.roleFeat') : this.$t('_tm.table.columns.role.roleData');
            }
          },
          {
            label: this.$t('_tm.table.columns.remarks'),
            prop: "remarks"
          },
          {
            label: this.$t('_tm.table.columns.enabled'),
            prop: "enabled",
            width: 70,
            slotName: "enabled"
          },
          {
            label: this.$t('_tm.table.columns.createDate'),
            prop: "createDate",
            width: 180,
            render: row => {
              return parseTime(row.createDate);
            }
          }
        ],
        formOptions: {
          inline: true,
          submitBtnText: this.$t('_tm.table.actions.search'),
          forms: [{ prop: "alias", placeholder: this.$t('_tm.placeholders.message_12'), clearable: true }]
        }
      },
      controls: [
        {
          command: "add",
          name: this.$t('_tm.table.actions.addRole'),
          auth: "role_add"
        }
      ]
    };
  },
  provide() {
    return { isTreeStatus: this.isTreeOpen };
  }
};
</script>
<style lang="scss" scoped>
.enablestate {
  color: #1fba00;
  &.error {
    color: red;
  }
}
</style>
