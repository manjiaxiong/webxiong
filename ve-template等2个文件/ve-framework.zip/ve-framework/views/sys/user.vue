<template>
  <div class="main-content">
    <auto-table
      :name="$t('_tm.common.user')"
      ref="table"
      primaryKey="username"
      :methods="methods"
      :controls="controls"
      :table="table"
      :dialog="dialog"
    >
      <template #enabled="{ row }">
        <span class="enablestate" :class="row.enabled ? '' : 'error'">{{
          row.enabled ? '启用' : '禁用'
        }}</span>
      </template>
    </auto-table>
  </div>
</template>

<script>
import { getRoles } from "../../api/role";
import { getGroupTree } from "../../api/group";
import {
  add,
  update,
  remove,
  passwordReset,
  apiUserDisabled,
  apiUserEnabled,
  apiUserUnlock
} from "../../api/user";
import { parseTime } from "../../utils";
import md5 from "../../utils/md5";
import { getConfig } from "../../config";
import TreeUtils from "../../utils/tree";
const treeUtil = new TreeUtils();

export default {
  props: {
    dialogMaps: {
      type: Object,
      default: () => ({})
    },
    buttonsPrepend: {
      type: Array,
      default: () => []
    },
    operationWidth: {
      type: Number,
      default: 300
    }
  },
  data() {
    return {
      roles: [],
      groups: [], // 组织
      methods: {
        add,
        update,
        remove
      },
      dialog: {
        maps: {
          ...this.dialogMaps
        },
        options: [
          {
            id: "username",
            name: this.$t('_tm.table.columns.username'),
            placeholder: this.$t('_tm.rules.message_3'),
            maxlength: 32,
            showWordLimit: true,
            // required: true,
            // validator: {
            //   callback: (r, v, callback, form) => {
            //     if (!v) {
            //       callback(new Error("用户账号不能为空"));
            //     }
            //     let reg = /[\u4e00-\u9fa5]+/;
            //     if (reg.test(v)) {
            //       callback(new Error("不能输入中文"));
            //     } else {
            //       callback();
            //     }
            //   }
            // },
            rules: [
              { required: true, message: this.$t('_tm.rules.message_3'), trigger: "blur" },
              {
                validator: (r, v, callback) => {
                  let reg = /[\u4e00-\u9fa5]+/;
                  if (reg.test(v)) {
                    callback(new Error(this.$t('_tm.rules.message_9')));
                  } else {
                    callback();
                  }
                },
                message: this.$t('_tm.rules.message_5'),
                trigger: "blur"
              }
            ],
            disabled(type) {
              return type === "edit";
            }
          },
          {
            id: "password",
            name: this.$t('_tm.table.columns.password'),
            placeholder: this.$t('_tm.messages.tip_34'),
            maxlength: 32,
            showWordLimit: true,
            show(type) {
              return type === "add";
            }
          },
          {
            id: "authorities",
            name: this.$t('_tm.table.columns.authorities'),
            placeholder: this.$t('_tm.placeholders.message_0'),
            rules: [
              { required: true, message: this.$t('_tm.rules.message_6'), trigger: "blur" }
            ],
            select: () => {
              return this.roles;
            },
            multiple: true
          },
          {
            id: "organization",
            name: this.$t('_tm.table.columns.organization'),
            placeholder: this.$t('_tm.placeholders.message_1'),
            cascader: () => {
              return this.groups;
            },
            clearable: true,
            filterable: true,
            format(v) {
              if (Array.isArray(v) && v.length) {
                return v[v.length - 1];
              }
              return "";
            },
            props: {
              multiple: false,
              checkStrictly: true, //父子节点取消选中关联，从而达到选择任意一级选项
              value: "id",
              label: "alias"
            },
            rules: [
              // { required: true, message: "所属组织不能为空", trigger: "blur" }
            ]
          },
          {
            id: "nickname",
            name: this.$t('_tm.table.columns.nickname'),
            placeholder: this.$t('_tm.placeholders.message_2'),
            maxlength: 20,
            showWordLimit: true,
            required: true
          },
          {
            id: "mobile",
            name: this.$t('_tm.table.columns.mobile'),
            placeholder: this.$t('_tm.placeholders.message_3'),
            rules: [
              // { required: true, message: "手机号码不能为空", trigger: "blur" },
              {
                pattern: /^1[3456789]\d{9}$/,
                message: this.$t('_tm.rules.message_7'),
                trigger: "blur"
              }
            ]
          },
          {
            id: "email",
            name: this.$t('_tm.table.columns.email'),
            placeholder: this.$t('_tm.placeholders.message_4'),
            rules: [
              { type: "email", message: this.$t('_tm.rules.message_8'), trigger: "blur" }
            ]
          }
        ]
      },
      table: {
        url: "/authority/users",
        pagination: "urlParams",
        pageIndexKey: "page",
        pageSizeKey: "size",
        indexIncrease: true,
        operation: {
          width: this.operationWidth + "px",
          size: "mini",
          type: "text",
          buttons: [
            ...this.buttonsPrepend,
            {
              name: this.$t('_tm.table.actions.detail'),
              command: "detail",
              icon: true
            },
            {
              name: this.$t('_tm.table.actions.edit'),
              command: "edit",
              auth: "user_edit",
              icon: true
            },
            {
              name: this.$t('_tm.table.actions.delete'),
              command: "remove",
              auth: "user_delete",
              icon: true
            },
            {
              name: this.$t('_tm.table.actions.resetPassword'),
              click: this.resetPassword,
              auth: "user_edit"
            },
            {
              name: this.$t('_tm.table.actions.enable'),
              click: ({ username }) => {
                if (!username) return;
                apiUserEnabled(username).then(() => {
                  this.$refs.table.refresh();
                });
              },
              show: ({ enabled }) => {
                return !enabled;
              }
            },
            {
              name: this.$t('_tm.table.actions.disable'),
              click: ({ username }) => {
                if (!username) return;
                this.$confirm(this.$t('_tm.messages.tip_9'), this.$t('_tm.dialog.tip'), {
                  type: "warning"
                }).then(() => {
                  apiUserDisabled(username).then(() => {
                    this.$refs.table.refresh();
                  });
                });
              },
              show: ({ enabled }) => {
                return !!enabled;
              }
            },
            {
              name: this.$t('_tm.table.actions.unlock'),
              click: ({ username }) => {
                if (!username) return;
                this.$confirm(this.$t('_tm.messages.tip_10'), this.$t('_tm.dialog.tip'), {
                  type: "warning"
                }).then(() => {
                  apiUserUnlock(username).then(() => {
                    this.$refs.table.refresh();
                  });
                });
              },
              disabled: ({ locked }) => {
                return !locked;
              }
            }
          ]
        },
        columns: [
          {
            label: this.$t('_tm.table.columns.username'),
            prop: "username",
            width: 120
          },
          {
            label: this.$t('_tm.table.columns.nickname'),
            prop: "nickname",
            width: 90
          },
          // {
          //   label: "手机号码",
          //   prop: "mobile",
          //   width: 120
          // },
          // {
          //   label: "电子邮箱",
          //   prop: "email"
          // },
          {
            label: this.$t('_tm.table.columns.organization'),
            prop: "organization",
            render: row => {
              return row.organization ? row.organization.alias : "";
            }
          },
          {
            label: this.$t('_tm.table.columns.authorities'),
            prop: "authorities",
            render: row => {
              return row.authorities.map(v => v.alias).join(", ");
            }
          },
          {
            label: this.$t('_tm.table.columns.enabled'),
            prop: "enabled",
            slotName: "enabled"
          },
          {
            label: this.$t('_tm.table.columns.locked'),
            prop: "locked",
            width: 80,
            render: ({ locked }) => { // 表格数据不转换
              return locked ? "是" : "否";
            }
          },
          {
            label: this.$t('_tm.table.columns.createDate'),
            prop: "createDate",
            width: 164,
            render: row => {
              return parseTime(row.createDate);
            }
          }
        ],
        formOptions: {
          inline: true,
          submitBtnText: this.$t('_tm.table.actions.search'),
          forms: [
            {
              prop: "authority",
              placeholder: this.$t('_tm.table.columns.authorities'),
              itemType: "select",
              options: [],
              valueKey: "authority",
              labelKey: "alias",
              clearable: true
            },
            {
              placeholder: this.$t('_tm.table.columns.organization'),
              // 旧版列表展示
              //  prop: "organizationId",
              // itemType: "select",
              // valueKey: "id",
              // labelKey: "alias",
              // options: [],

              // 新版级联下拉框
              prop: "organizationId",
              itemType: "cascader",
              clearable: true,
              filterable: true,
              options: [],
              format(v, prop) {
                if (
                  Object.prototype.toString.call(v) === "[object Array]" &&
                  v.length > 0
                ) {
                  return v[v.length - 1];
                }
                return "";
              },
              // change: v => {
              //   console.log(v);
              // },
              props: {
                multiple: false,
                checkStrictly: true, //父子节点取消选中关联，从而达到选择任意一级选项
                value: "id",
                label: "alias"
              }
            },
            { prop: "username", placeholder: this.$t('_tm.table.columns.username'), clearable: true },
            { prop: "nickname", placeholder: this.$t('_tm.table.columns.nickname'), clearable: true },
            { prop: "mobile", placeholder: this.$t('_tm.table.columns.mobile'), clearable: true },
            { prop: "email", placeholder: this.$t('_tm.table.columns.email'), clearable: true }
          ]
        }
      },
      controls: [
        {
          command: "add",
          name: this.$t('_tm.table.actions.addUser'),
          message: this.$t('_tm.messages.tip_6'),
          auth: "user_add"
        }
      ]
    };
  },
  methods: {
    resetPassword({ username }) {
      if (username) {
        this.$confirm(this.$t('_tm.messages.tip_7'), this.$t('_tm.dialog.continueAsk'), this.$t('_tm.dialog.tip'), {
          confirmButtonText: this.$t('_tm.dialog.confirm'),
          cancelButtonText: this.$t('_tm.dialog.cancel'),
          type: "warning"
        })
          .then(() => {
            const compatible = getConfig("api.authority.compatible");
            passwordReset({
              username,
              newPassword: compatible ? "123456" : md5(md5("123456"))
            }).then(data => {
              // this.refresh();
              this.$message({
                type: "success",
                message: this.$t('_tm.messages.tip_8')
              });
            });
          })
          .catch(() => {});
      }
    },
    setRoleSelectData(data) {
      this.roles = data.map(v => ({
        id: v.authority,
        name: v.alias + (v.roleType === 1 ? this.$t('_tm.common.roleData') : this.$t('_tm.common.roleFeat'))
      }));
      this.table.formOptions.forms[0].options = data;
    },
    findNodes(data, id, path = []) {
      const result = treeUtil.findNodes(data, item => item.id === id);
      if (result && result.length) {
        path.unshift(id);
        const pid = result[0].parentId;
        if (pid) {
          this.findNodes(data, pid, path);
        }
      }
    },
    formatData(data) {
      data.authorities = data.authorities.map(v => v.authority);
      if (data.organization) {
        const id = data.organization.id;
        const path = [];
        this.findNodes(
          treeUtil.filterNodes(this.groups, item => {
            return item.id === id;
          }),
          id,
          path
        );
        data.organization = path;
      }
      return data;
    },
    // 格式化树状数据： 删除掉children为空的children属性
    getTreeFormatData(arr) {
      if (!arr || !arr.length) return;
      let res = [];
      arr.forEach((v, i) => {
        if (v.children && !!v.children.length) {
          let children = this.getTreeFormatData(v.children);
          v.children = children;
        } else {
          delete v.children;
        }
        res.push(v);
      });
      return res;
    },
    onRefreshData() {
      getRoles().then(data => {
        if (data.length) {
          this.setRoleSelectData(data);
        }
      });
      // 树状
      getGroupTree().then(res => {
        const data = this.getTreeFormatData(res);
        this.table.formOptions.forms[1].options = data;
        this.groups = data;
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.enablestate {
  color: #1fba00;
  &.error {
    color: red;
  }
}
</style>
