<template>
  <div class="app-container">
    <auto-table
      :table="table"
      :dialog="dialog"
      :controls="controls"
    ></auto-table>
  </div>
</template>
<script>
import { parseTime } from "../../utils";

export default {
  data() {
    let starttime = parseTime(Date.now() - 86400000 * 30);
    let endtime = parseTime(Date.now());

    return {
      operationMap: {
        PUT: this.$t('_tm.table.actions.update'),
        DELETE: this.$t('_tm.table.actions.delete'),
        POST: this.$t('_tm.table.actions.add')
      },
      operation: [],
      dialog: {
        width: "800px",
        modalClose: true,
        grid: 1,
        labelWidth: "120px",
        options: [
          {
            name:  this.$t('_tm.table.columns.module'),
            id: "module"
          },
          {
            name:  this.$t('_tm.table.columns.operation'),
            id: "operation"
          },
          {
            name:  this.$t('_tm.table.columns.description'),
            id: "description"
          },
          {
            name: this.$t('_tm.table.columns.detail'),
            id: "detail",
            textarea: {
              autosize: { minRows: 2, maxRows: 4 }
            }
          },
          {
            name:  this.$t('_tm.table.columns.operator'),
            id: "operator"
          },
          {
            name:  this.$t('_tm.table.columns.cast'),
            id: "cast"
          },
          {
            name:  this.$t('_tm.table.columns.time'),
            id: "time"
          }
        ]
      },
      table: {
        url: "/authority/logs/operations",
        align: "left",
        pagination: "urlParams",
        pageIndexKey: "page",
        pageSizeKey: "size",
        indexIncrease: true,
        operation: {
          width: "100px",
          size: "mini",
          type: "text",
          buttons: [
            {
              name: this.$t('_tm.table.actions.detail'),
              command: "detail",
              icon: true
            }
          ]
        },
        formOptions: {
          inline: true,
          submitBtnText: this.$t('_tm.table.actions.search'),
          forms: [
            {
              prop: "module",
              label: this.$t('_tm.table.columns.module'),
              placeholder: this.$t('_tm.placeholders.message_6'),
              clearable: true
            },
            {
              prop: "operation",
              label: this.$t('_tm.table.columns.operation'),
              clearable: true,
              placeholder: this.$t('_tm.placeholders.message_8'),
              itemType: "select",
              options: []
            },
            {
              prop: "operator",
              label: this.$t('_tm.table.columns.operator'),
              placeholder: this.$t('_tm.placeholders.message_7'),
              clearable: true
            },
            {
              prop: ["starttime", "endtime"],
              label: this.$t('_tm.common.date'),
              itemType: "datetimerange",
              default: [starttime, endtime],
              clearable: false
            }
          ]
        },
        columns: [
          {
            label: this.$t('_tm.table.columns.module'),
            prop: "module"
          },
          {
            label: this.$t('_tm.table.columns.operation'),
            prop: "operation",
            width: 120,
            render: ({ operation }) => this.operationMap[operation] || "-"
          },
          {
            label: this.$t('_tm.table.columns.description'),
            prop: "description"
          },
          {
            label: this.$t('_tm.table.columns.operator'),
            prop: "operator",
            width: 160
          },
          {
            label: this.$t('_tm.table.columns.cast'),
            prop: "cast",
            width: 100,
            render({ cast }) {
              return cast + "ms";
            }
          },
          {
            label: this.$t('_tm.table.columns.time'),
            prop: "time",
            width: 164
          }
        ]
      },
      controls: [
        {
          name: this.$t('_tm.table.actions.print'),
          command: "print",
          type: "success"
        }
      ]
    };
  },
  methods: {
    loadDictData() {
      let operation_dictinfor = this.$dict.get("operation");
      this.table.formOptions.forms[1].options = operation_dictinfor;
      let operationMap = {};
      operation_dictinfor.forEach(item => {
        if (!operationMap[item.value]) {
          operationMap[item.value] = item.label;
        }
      });
      this.operationMap = operationMap;
    }
  },
  mounted() {
    this.loadDictData();
  },
  activated() {
    this.loadDictData();
  }
};
</script>
