<template>
  <div class="main-content">
    <div style="text-align: right">
      <el-button-group size="small">
        <el-button
          type="primary"
          size="small"
          icon="el-icon-plus"
          @click="addResource"
          >{{ $t("_tm.table.actions.addResource") }}</el-button
        >
        <el-button
          type="primary"
          size="small"
          icon="el-icon-refresh"
          @click="refshTable"
          :loading="loading"
          >{{ $t("_tm.table.actions.refresh") }}</el-button
        >
        <el-button
          type="primary"
          size="small"
          icon="el-icon-folder-opened"
          @click="openAll"
          >{{ $t("_tm.table.actions.openAll") }}</el-button
        >
        <el-button
          type="primary"
          size="small"
          icon="el-icon-folder"
          @click="zipAll"
          >{{ $t("_tm.table.actions.zipAll") }}</el-button
        >
      </el-button-group>
    </div>
    <dragTreeTable
      ref="table"
      :data="treeData"
      :onDrag="onTreeDataChange"
      resize
      border
      fixed
      height="100%"
      :isdraggable="true"
      :beforeDragOver="beforeDragOver"
      :slots="slots"
    >
      <template #myicon="{ data }">
        <icon :content="data.ico" :size="20" color="#606266" />
      </template>
    </dragTreeTable>
    <v-dialog
      scope="resourceIcon"
      :dialogMaps="resourceIcon"
      :modalClose="false"
    />
    <v-dialog
      scope="resourceNew"
      :dialogMaps="resourceNew"
      :modalClose="false"
    />
  </div>
</template>

<script>
import dragTreeTable from "../../../components/DragTreeTable";
import {
  getResourceTree,
  updateResource,
  addResource,
  deleteResource,
  moveResource
} from "../../../api/resource";
import ResourceIcon from "./dialog/icon";
import Form from "../../../components/AutoTable/dialog/form";

export default {
  components: {
    dragTreeTable
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      // 自定义插槽
      slots: [
        {
          name: "myicon"
        }
      ],
      // 弹窗表单options
      formOptions: [
        {
          id: "name",
          name: this.$t("_tm.table.columns.resName"),
          placeholder: this.$t("_tm.placeholders.message_35"),
          maxlength: 20,
          showWordLimit: true,
          required: true
        },
        {
          id: "path",
          name: this.$t("_tm.table.columns.menuPath"),
          placeholder: this.$t("_tm.placeholders.message_36"),
          maxlength: 100,
          showWordLimit: true
        },
        {
          id: "type",
          name: this.$t("_tm.table.columns.res.pathType"),
          default: 1,
          select: [
            {
              id: 1,
              name: this.$t("_tm.table.columns.res.type1")
            },
            {
              id: 2,
              name: this.$t("_tm.table.columns.res.type2")
            },
            {
              id: 3,
              name: this.$t("_tm.table.columns.res.type3"),
              show: ({ data }) => {
                return data ? true : false;
              }
            },
            {
              id: 4,
              name: "Iframe"
            }
          ]
        },
        {
          id: "method",
          name: this.$t("_tm.table.columns.res.method"),
          placeholder: this.$t("_tm.placeholders.message_34"),
          show: (type, model) => {
            return model.type === 3;
          }
        },
        // {
        //   id: "orderNo",
        //   name: "资源序号",
        //   placeholder: "请输入资源序号",
        //   default: 0,
        //   max: 99999,
        //   integer: true,
        //   required: true
        // },
        {
          id: "ico",
          name: this.$t("_tm.table.columns.res.icon"),
          maxlength: 50,
          showWordLimit: true,
          placeholder: this.$t("_tm.placeholders.message_33"),
          unit: {
            icon: "el-icon-setting",
            click: this.iconSettings
          }
        },
        {
          id: "hidden",
          name: this.$t("_tm.table.columns.res.hidden"),
          default: false,
          radio: [
            {
              id: false,
              name: this.$t("_tm.common.show")
            },
            {
              id: true,
              name: this.$t("_tm.common.hide")
            }
          ]
        },
        {
          id: "remark",
          name: this.$t("_tm.table.columns.remark"),
          placeholder: this.$t("_tm.placeholders.message_9"),
          maxlength: 100,
          showWordLimit: true
        }
      ],
      method: {
        add: addResource,
        update: updateResource,
        remove: deleteResource
      },
      // 是否在刷新
      loading: false,
      // 图标弹窗
      resourceIcon: {
        icon: {
          title: this.$t("_tm.dialog.title.resourceIcon"),
          component: ResourceIcon
        }
      },
      // 资源表单弹窗
      resourceNew: {
        add: {
          title: this.$t("_tm.dialog.title.resourceAdd"),
          component: Form
        },
        edit: {
          title: this.$t("_tm.dialog.title.resourceEdit"),
          component: Form
        }
      },
      // 拖拽树表格
      treeData: {
        columns: [
          {
            type: "selection",
            title: this.$t("_tm.table.columns.menuName"),
            field: "name",
            width: 200,
            align: "left",
            titleAlign: "left",
            flex: 1,
            formatter: item => {
              return "<span>" + item.name + "</span>";
            }
          },
          {
            title: this.$t("_tm.table.columns.menuType"),
            field: "type",
            width: 100,
            align: "left",
            titleAlign: "left",
            formatter: item => {
              let map = {
                1: this.$t("_tm.table.columns.res.type1"),
                2: this.$t("_tm.table.columns.res.type2"),
                3: this.$t("_tm.table.columns.res.type3"),
                4: "Iframe"
              };
              return "<span>" + map[item.type] + "</span>";
            }
          },
          {
            title: this.$t("_tm.table.columns.menuPath"),
            field: "path",
            width: 200,
            flex: 1,
            align: "left",
            titleAlign: "left"
          },
          {
            title: this.$t("_tm.table.columns.remarks"),
            field: "remark",
            width: 200,
            flex: 1,
            align: "left",
            titleAlign: "left"
          },
          {
            type: "slot",
            slotName: "myicon",
            width: 100,
            title: this.$t("_tm.table.columns.menuIcon"),
            align: "left",
            titleAlign: "left"
          },
          {
            title: this.$t("_tm.table.columns.operation"),
            type: "action",
            align: "left",
            titleAlign: "left",
            width: 200,
            actions: [
              {
                text: this.$t("_tm.table.actions.addMenuChildren"),
                onclick: this.addResource,
                formatter: item => {
                  return `<i>${this.$t(
                    "_tm.table.actions.addMenuChildren"
                  )} &nbsp; &nbsp; </i>`;
                }
              },
              {
                text: this.$t("_tm.table.actions.edit"),
                onclick: this.editResource,
                formatter: item => {
                  let dialogData = {};
                  return `<i>${this.$t(
                    "_tm.table.actions.edit"
                  )} &nbsp; &nbsp;  </i>`;
                }
              },
              {
                text: this.$t("_tm.table.actions.delete"),
                onclick: this.deleteResource,
                formatter: item => {
                  return `<i> ${this.$t("_tm.table.actions.delete")}</i>`;
                }
              }
            ]
          }
        ],
        lists: [],
        custom_field: {
          lists: "children",
          parent_id: "parentId"
        }
      }
    };
  },
  methods: {
    // 默认参数处理，可由项目重置
    onParams(params, data) {
      // 修复微服务不传rank，orderNo 重置为0的Bug
      params.rank = data.rank;
      params.orderNo = data.orderNo;
      return params;
    },
    onTreeDataChange(list, from, to, where) {
      // console.log("<start2>");
      // console.log(list);
      // console.log(from);
      // console.log(to);
      // console.log(where);
      // console.log("<end2>");
      let opMap = {
        center: 0,
        top: 1,
        bottom: 2
      };
      moveResource(from.id, to.id, opMap[where]).then(resp => {
        this.treeData.lists = list;
      });
    },
    beforeDragOver(from, to, where) {
      if (from.type === 3) return false;
      if (to.type === 3) return false;
      if (
        to.children.some(child => {
          return child.type === 3;
        })
      ) {
        return false;
      }
      return true;
    },
    onAdd(pId, data) {
      this.$refs.table.AddRow(pId, data);
    },
    onEdit(id, data) {
      this.$refs.table.EditRow(id, data);
    },
    treeStuts() {
      if (this.params && this.params.isOpenTree) {
        this.openAll();
      } else {
        this.zipAll();
      }
    },
    openAll() {
      this.$refs.table.OpenAll();
    },
    zipAll() {
      this.$refs.table.ZipAll();
    },
    iconSettings({ data, type }, form) {
      this.$dialog.open("resourceIcon", "icon", {
        // icon: type === "edit" ? data.ico : null,
        icon: form.ico || null,
        confirm: value => {
          if (value && form) {
            this.$set(form, "ico", value);
          }
        }
      });
    },
    // 新增资源
    addResource(item) {
      let params = {
        type: "add",
        fullscreen: true,
        methods: this.method,
        options: this.formOptions,
        refresh: this.refshTable
      };
      if (item.id) {
        params.id = item.id;
        params.data = item;
      }
      this.$dialog.open("resourceNew", "add", params);
    },
    // 编辑资源
    editResource(item) {
      let params = {
        type: "edit",
        fullscreen: true,
        data: item,
        copy: item,
        options: this.formOptions,
        id: item.id,
        methods: this.method,
        refresh: this.refshTable,
        // 修复微服务升级rank，orderNo 字段必传
        // 框架默认处理，可由项目重置
        onParams: this.params.onParams || this.onParams
      };
      this.$dialog.open("resourceNew", "edit", params);
    },
    // 删除资源
    deleteResource(item) {
      let id = item.id;
      let { remove } = this.method;
      if (id && remove) {
        this.$confirm(
          this.$t("_tm.messages.tip_11"),
          this.$t("_tm.dialog.tip"),
          {
            type: "warning"
          }
        )
          .then(() => {
            remove(id).then(data => {
              // 本地删除成功;  console.log("当前行的数据", updatedLists);
              const updatedLists = this.$refs.table.DelById(id);
              this.treeData.lists = updatedLists;

              this.$message({
                type: "success",
                message: this.$t("_tm.messages.tip_12")
              });
            });
          })
          .catch(() => {});
      }
    },
    // 刷新表格
    refshTable() {
      this.loading = true;
      this.delay(5000).then(() => {
        this.loading = false;
      });
      getResourceTree().then(resp => {
        this.loading = false;
        this.treeData.lists = resp;
        this.$nextTick(() => {
          this.treeStuts();
        });
      });
    }
  },
  mounted() {
    this.refshTable();
  }
};
</script>
