<template>
  <div class="dialog-content-wrapper">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="Font Awesome" name="first">
        <el-input
          v-model="keyword"
          placeholder="请输入关键词过滤"
          prefix-icon="el-icon-search"
          clearable
        ></el-input>
        <ul v-if="icons.length" class="icon-wrap">
          <li
            :key="key"
            v-for="(icon, key) in icons"
            :class="{ active: choosedIcon === icon }"
            :title="icon"
            @click="chooseIcon(icon)"
          >
            <div class="wrapper">
              <i class="fa" :class="icon"></i>
            </div>
          </li>
        </ul>
        <div v-else class="empty-text">暂无图标</div>
      </el-tab-pane>
      <el-tab-pane v-if="iconfonts" label="Icon Font" name="second">
        <ul class="icon-wrap">
          <li
            :key="key"
            v-for="(item, key) in iconfonts"
            :class="{ active: choosedIcon === item.icon }"
            :title="item.name"
            @click="chooseIcon(item.icon)"
          >
            <div class="wrapper">
              <i class="iconfont" v-html="item.icon"></i>
            </div>
          </li>
        </ul>
      </el-tab-pane>
    </el-tabs>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" :disabled="!choosedIcon" @click="confirm"
        >确 定</el-button
      >
    </div>
  </div>
</template>

<script>
import icons from "./icons";
export default {
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      keyword: "",
      activeTab: "first",
      choosedIcon: ""
    };
  },
  computed: {
    icons() {
      return this.keyword
        ? icons.filter(v => v.indexOf(this.keyword) > -1)
        : icons;
    },
    iconfonts() {
      return this.$config.iconfont || null;
    }
  },
  methods: {
    opened() {
      if (this.$el) {
        const dom = this.$el.querySelector(".active");
        if (dom) {
          dom.scrollIntoView();
        }
      }
    },
    open() {
      let { icon } = this.params;
      if (icon) {
        const awesome = icon.indexOf("fa ") > -1;
        this.chooseIcon(awesome ? icon.split(" ")[1] : icon);
        this.setTab(
          awesome
            ? "first"
            : icon.indexOf("#") > -1 && this.iconfonts
            ? "second"
            : "first"
        );
      } else {
        this.chooseIcon("");
        this.setTab("first");
      }
    },
    closed() {
      this.chooseIcon("");
      this.keyword = "";
    },
    close() {
      this.$emit("close");
    },
    chooseIcon(icon) {
      this.choosedIcon = icon;
    },
    setTab(tab) {
      this.activeTab = tab;
    },
    confirm() {
      const value =
        this.activeTab === "first"
          ? "fa " + this.choosedIcon
          : this.choosedIcon;
      if (typeof this.params.confirm === "function") {
        this.params.confirm(value);
      }
      this.close();
    }
  }
};
</script>

<style lang="scss" scoped>
$active-color: #1d9d74;
.dialog-content-wrapper {
  user-select: none;
  .empty-text {
    color: #666;
    text-align: center;
    line-height: 6;
    margin-top: 10px;
  }
  .dialog-footer {
    margin-top: 15px;
    text-align: right;
  }
  ::v-deep .el-tabs__header {
    margin-bottom: 15px;
  }
}
.icon-wrap {
  max-height: 400px;
  overflow-y: auto;
  padding-left: 5px;
  list-style: none;
  margin-top: 15px;
  margin-bottom: 15px;
  i {
    font-size: 28px;
  }

  li {
    list-style: none;
    display: inline-block;
    width: 40px;
    height: 40px;
    text-align: center;
    cursor: pointer;
    color: #444;
    transition: color 0.3s ease-in-out;
    margin-left: 2px;
    margin-right: 2px;
    margin-bottom: 5px;
    &:hover {
      color: $active-color;
      transition: color 0.3s;
    }
    &.active {
      background-color: $active-color;
      color: #fff;
    }

    .wrapper {
      display: flex;
      height: 100%;
      width: 100%;
      align-items: center;
      justify-content: center;
    }
  }
}
</style>
