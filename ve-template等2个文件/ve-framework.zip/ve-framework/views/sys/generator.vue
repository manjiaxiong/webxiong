<!--
 * @Author: your name
 * @Date: 2020-11-07 17:19:52
 * @LastEditTime: 2020-12-05 16:48:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ve-framework\views\sys\generator.vue
-->
<template>
  <div class="main-content">
    <auto-table :controls="controls" :table="table"></auto-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectionData: [], // 选中数据
      table: {
        url: "/generator",
        pagination: "urlParams",
        pageIndexKey: "page",
        pageSizeKey: "size",
        showCheckBox: true, // 复选框
        indexIncrease: true, // 索引递增
        events: {
          selectionChange: selection => {
            this.selectionData = selection;
          }
        },
        columns: [
          {
            label: $t('_tm.this.table.columns.tableName'),
            prop: "tableName"
          },
          {
            label: $t('_tm.this.table.columns.engine'),
            prop: "engine",
            width: 100
          },
          {
            label: $t('_tm.this.table.columns.comments'),
            prop: "comments"
          },
          {
            label: $t('_tm.this.table.columns.createTime'),
            prop: "createTime",
            width: 160
          }
        ],
        formOptions: {
          inline: true,
          submitBtnText: $t('_tm.this.table.actions.search'),
          forms: [{ prop: "name", placeholder: $t('_tm.this.placeholders.message_5'), clearable: true }]
        }
      },
      controls: [
        {
          name: $t('_tm.this.table.actions.generator'),
          click: () => {
            let tables = this.selectionData.map(item => item.tableName).join();
            if (!tables) {
              this.$message.warning($t('_tm.this.messages.tip_13'));
              return;
            }
            let url = `${ process.env.VUE_APP_PROXY_DOMAIN || '' }/generator/build?tables=${encodeURIComponent(tables)}`;
            window.open(url);
          }
        }
      ]
    };
  }
};
</script>
