<template>
  <div class="main-content">
    <auto-table
      :name="$t('_tm.dialog.title.dictData')"
      scope="dictData"
      :methods="methods"
      :controls="controls"
      :table="table"
      :options="options"
    >
      <template #dictState="{row}">
        <span
          class="enablestate"
          :class="row.enableState ==0?'error' : ''"
        >{{row.enableState == 0 ? $t('_tm.table.columns.dict.state_0') : $t('_tm.table.columns.dict.state_1')}}</span>
      </template>
    </auto-table>
  </div>
</template>

<script>
import { addData, updateData, getAllType, subURL } from "../../../api/dict";

export default {
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      types: [],
      methods: {
        add: addData,
        update: updateData
      },
      options: [
        {
          id: "dictType",
          name: this.$t('_tm.table.columns.dict.dictType'),
          filterable: true,
          required: true,
          select: () => {
            return this.types;
          },
          readonly(type) {
            return type === "edit";
          }
        },
        {
          id: "fieldType",
          name: this.$t('_tm.table.columns.dict.fieldType'),
          placeholder: this.$t('_tm.placeholders.message_19'),
          required: true,
          clearable: true,
          disabled(type) {
            return type === "edit";
          }
        },
        {
          id: "fieldName",
          name: this.$t('_tm.table.columns.dict.fieldName'),
          clearable: true,
          placeholder: this.$t('_tm.placeholders.message_38'),
          required: true
        },
        {
          id: "enableState",
          name: this.$t('_tm.table.columns.dict.enableState'),
          default: 1,
          select: [
            {
              id: 1,
              name:  this.$t('_tm.table.columns.dict.state_1')
            },
            {
              id: 0,
              name: this.$t('_tm.table.columns.dict.state_0')
            }
          ],
          rules: [
            { required: true, message:  this.$t('_tm.rules.message_25'), trigger: "blur" }
          ]
        },
        {
          id: "sort",
          name: this.$t('_tm.table.columns.dict.sort'),
          placeholder: this.$t('_tm.placeholders.message_20'),
          type: "integer",
          // clearable: true,
          default: 0,
          required: true
        },
        {
          id: "remarks",
          name: this.$t('_tm.table.columns.remarks'),
          placeholder: this.$t('_tm.placeholders.message_37')
        }
      ],
      table: {
        url: subURL + "/dictinfo",
        pagination: "urlParams",
        pageIndexKey: "page",
        pageSizeKey: "size",
        operation: {
          width: "90px",
          type: "text",
          size: "mini",
          buttons: [
            {
              name: "编辑",
              command: "edit",
              // auth: "role_edit",
              icon: true
            }
            // {
            //   name: "删除",
            //   command: "remove",
            //   auth: "role_delete",
            //   icon: true
            // }
          ]
        },
        columns: [
          {
            label: this.$t('_tm.table.columns.dict.dictType'),
            prop: "dictType"
          },
          {
            label: this.$t('_tm.table.columns.dict.dictName'),
            prop: "dictName"
          },
          {
            label: this.$t('_tm.table.columns.dict.fieldType'),
            prop: "fieldType"
          },
          {
            label: this.$t('_tm.table.columns.dict.fieldName'),
            prop: "fieldName"
          },
          {
            label:  this.$t('_tm.table.columns.remarks'),
            prop: "remarks"
          },
          {
            label: this.$t('_tm.table.columns.enabled'),
            prop: "enableState",
            slotName: "dictState"
          }
        ],
        formOptions: {
          inline: true,
          submitBtnText: this.$t('_tm.table.actions.search'),
          forms: [
            {
              prop: "dictType",
              label: this.$t('_tm.forms.dictType'),
              clearable: true,
              itemType: "select",
              options: [],
              filterable: true,
              labelKey: "dictName",
              valueKey: "dictType"
            },
            { prop: "fieldName", placeholder: this.$t('_tm.placeholders.message_15'), clearable: true }
          ]
        }
      },
      controls: [
        {
          name: this.$t('_tm.table.actions.add'),
          command: "add"
        }
      ]
    };
  },
  deactivated() {
    this.$dict.init();
  },
  methods: {
    setOptions(data) {
      this.types = data.map(v => ({
        id: v.dictType,
        name: v.dictName
      }));
      this.table.formOptions.forms[0].options = data;
    },
    onRefreshData() {
      getAllType().then(data => {
        if (data && data.length) {
          this.setOptions(data);
        } else if (data && data.list && data.list.length) {
          this.setOptions(data.list);
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.enablestate {
  color: #1fba00;
  &.error {
    color: red;
  }
}
</style>
