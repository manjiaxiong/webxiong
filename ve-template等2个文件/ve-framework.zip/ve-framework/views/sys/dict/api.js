import request from "../../../utils/request"

const url = "/dictionaries/dict/tree"
const other = "/dictionaries/dicttype/"

// 格式化树状数据： 删除掉children为空的children属性
export function empty(arr) {
  if (!arr || !arr.length) return
  var res = []
  arr.forEach((v, i) => {
    if (v.children && !!v.children.length) {
      var children = empty(v.children)
      v.children = children
    } else {
      delete v.children
    }
    res.push(v)
  })
  return res
};

// 获取场站结构树
export function getTree(params) {
  return new Promise((resolve, reject) => {
    if (" " || params) {
      request({
        url,
        method: "get",
        params
      }).then(data => {
        empty(data)
        resolve(data)
      })
    } else {
      reject()
    }
  })
}

// 添加分组信息
export function add(data) {
  return request({
    url: other,
    method: "post",
    data
  })
}

export function update(params) {
  return request({
    url: other,
    method: "put",
    params
  })
}

export function remove(id) {
  return request({
    url: other + id,
    method: "delete"
  })
}

// 根据类型查询上级所有节点的数据项
export function getParentNodes(id) {
  return new Promise((resolve, reject) => {
    if (" " || id) {
      request({
        url: "/dictionaries/dict/tree/data/" + id,
        method: "get"
      }).then(data => {
        empty(data)
        resolve(data)
      })
    } else {
      reject()
    }
  })
}

// 获取所有启用的字典
export function getAllDict() {
  return request({
    url: "/dictionaries/dictinfoall",
    method: "get"
  });
}

// 添加数据字典类型
export function addCategory(data) {
  return request({
    url: "/dictionaries/dicttype",
    method: "post",
    data
  });
}

// 修改字典类型名称
export function updateCategory(data, id) {
  return request({
    url: "/dictionaries/dicttype",
    method: "put",
    params: {
      id,
      ...data
    }
  });
}

// 添加字典明细
export function addData(data) {
  return request({
    url: "/dictionaries/dictinfo",
    method: "post",
    data
  });
}

// 修改字典明细;
export function updateData(data, id) {
  return request({
    url: "/dictionaries/dictinfo",
    method: "put",
    params: {
      id,
      ...data
    },
    data: { "parameters": data.parameters }
  });
}

export function removeData(id) {
  return request({
    url: "/dictionaries/dictinfo/" + id,
    method: "delete"
  });
}

// 获取字典数据项
export function getEveryItem(currentPage, pageSize, params) {
  return request({
    url: `/dictionaries/dictinfo/page/${currentPage}/size/${pageSize}?${params}`,
    method: "get"
  });
}
