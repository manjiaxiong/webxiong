export default {
  //右上角功能条（默认为添加节点，可传查询，图标会自动判断）
  ability: {
    type: String,
    default: "添加节点"
  },
  show: {
    type: Boolean,
    default: true
  },
  // row- key唯一标识
  id: {
    type: String,
    default: ""
  },
  /**
   * 树表格的内容
   * prop  内容显示，跟后端的字段一致
   * label 表头名
   */
  forms: {
    type: Array,
    default: () => {
      return []
    }
  },
  // 获取树表格数据方法
  getTreeTable: {
    type: Promise,
    default: () => { }
  },
  tableData: {
    type: Array,
    default: () => {
      return []
    }
  },
  // 是否初始化时就获取数据
  init: {
    type: Boolean,
    default: false
  },
  // 是否是复杂树形列表（对象取prop）
  complex: {
    type: Boolean,
    default: false
  },
  tableStyle: {
    type: String,
    default: ""
  }
}
