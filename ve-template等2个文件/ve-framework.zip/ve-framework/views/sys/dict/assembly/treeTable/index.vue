<template>
  <div class="custom-tree-container">
    <div class="organ-table">
      <slot />
      <div class="control">
        <el-button-group size="small">
          <el-button
            v-show="show"
            type="primary"
            :icon="ability.includes('加') ? 'el-icon-plus' : 'el-icon-search'"
            @click="handle"
            size="small"
            >{{ ability }}</el-button
          >
          <slot name="add" />
          <el-button
            type="primary"
            icon="el-icon-folder-opened"
            @click="expandAll"
            size="small"
            >{{$t('_tm.table.actions.openAll')}}</el-button
          >
          <el-button
            type="primary"
            icon="el-icon-folder"
            @click="collapseAll"
            size="small"
            >{{$t('_tm.table.actions.zipAll')}}</el-button
          >
        </el-button-group>
      </div>
      <el-table
        ref="tables"
        v-loading="loading"
        border
        :style="tableStyle"
        :row-key="id"
        :data="tableDataOwner"
        :row-class-name="tableRowClassName"
        :row-style="{ cursor: 'pointer' }"
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      >
        <el-table-column
          v-for="(item, key) in forms"
          v-if="complex ? true : false"
          :key="key"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
          :formatter="item.formatter"
        />
        <el-table-column
          v-for="(item, key) in forms"
          v-if="complex ? false : true"
          :key="key"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
        >
          <template slot-scope="scope" :scope="newSlotScope ? 'scope' : false">
            <span>{{
              item.render
                ? item.render(scope.row, scope.row[item.prop])
                : scope.row[item.prop]
            }}</span>
          </template>
        </el-table-column>
        <slot name="progress" />
        <slot name="operation" />
      </el-table>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import props from "./props";
export default {
  props,
  data() {
    return {
      Vue,
      loading: true,
      tableDataOwner: this.tableData
    };
  },
  computed: {
    newSlotScope() {
      return Number(Vue.version.replace(/\./g, "")) >= 250;
    }
  },
  watch: {
    tableData(val) {
      this.tableDataOwner = val;
    },
    getTreeTable: {
      async handler() {
        if (this.init) {
          this.tableDataOwner = await this.getTreeTable;
          this.loading = false;
        } else {
          this.loading = false;
        }
      },
      immediate: true,
      deep: true
    }
  },
  methods: {
    handle() {
      this.$emit("handle");
    },
    tableRowClassName({ row, rowIndex }) {
      this.$emit("tableRowClassName", { row, rowIndex });
    },
    expandAll() {
      this.solve(this.tableDataOwner, true);
    },
    collapseAll() {
      this.solve(this.tableDataOwner, false);
    },
    solve(arr, isExpand) {
      arr.forEach(i => {
        this.$refs.tables.toggleRowExpansion(i, isExpand);
        if (i.children) {
          this.solve(i.children, isExpand);
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.custom-tree-container {
  .control {
    text-align: right;
    margin-bottom: 20px;
  }
  .organ-table {
    margin: 20px;
    position: relative;
    .total_btn {
      position: absolute;
      right: 50px;
      top: 10px;
      z-index: 99;
    }
  }
}
::v-deep .el-table--enable-row-transition .el-table__body td {
  text-align: left !important;
}
::v-deep .el-table__header th {
  text-align: left;
}
</style>
