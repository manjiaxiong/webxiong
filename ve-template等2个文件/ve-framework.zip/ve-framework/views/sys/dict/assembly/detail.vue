<template>
  <div>
    <el-drawer
      title="键值列表"
      :visible.sync="drawer"
      :direction="direction"
      size="50%"
      :before-close="handleClose"
      @opened="opened"
    >
      <el-divider></el-divider>
      <vxeDict ref="dict" />
    </el-drawer>
  </div>
</template>

<script>
import vxeDict from "./vxeDict";
export default {
  components: {
    vxeDict
  },
  props: {
    drawer: {
      type: Boolean,
      default: () => false
    },
    types: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      direction: "rtl"
    };
  },
  methods: {
    handleClose() {
      this.$emit("done");
    },
    opened() {
      this.$refs.dict.dictType = this.types;
      this.$refs.dict.findList(`dictType=${this.types}`);
    }
  }
};
</script>

<style lang="scss" scoped>
::v-deep {
  .el-drawer__header {
    margin: 20px 0 0 0;
    padding: 0 10px 0 10px;
    width: 100%;
    display: flex;
    align-items: center;
    color: #000;
  }
}
::v-deep .el-icon-close {
  color: #000 !important;
}
</style>
