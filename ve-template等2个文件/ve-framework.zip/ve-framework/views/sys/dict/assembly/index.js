import { add, update, remove } from "../api"

export default {
  data() {
    return {
      id: null,
      types: "",
      drawer: false,
      parentId: null,
      action: {
        model: null,
        name: null,
        text: null,
        show: false,
        disabled: false
      }
    }
  },
  methods: {
    // 根类型添加
    add() {
      this.action.show = true
      this.action.text = this.$t('_tm.table.actions.dict.add')
    },
    edit(i, v) {
      this.action.disabled = true
      this.action.show = true
      this.action.text = this.$t('_tm.table.actions.dict.edit')
      this.action.model = v.dictType
      this.action.name = v.dictName
      this.id = v.id
    },
    // 子类型添加
    addSon(i, v) {
      this.parentId = v.id
      this.action.show = true
      this.action.text = this.$t('_tm.table.actions.dict.addChild')
    },
    done() { this.drawer = false },
    cancel() {
      this.action.show = false
      this.action.model = null
      this.action.name = null
      this.action.disabled = false
    },
    save() {
      const params = {
        dictName: this.action.name,
        id: this.id
      }
      const addParams = {
        dictType: this.action.model,
        dictName: this.action.name
      }
      const text = this.action.text
      if (text.includes("编辑")) {
        update(params)
          .then(() => {
            this.action.show = false
            this.handle()
            this.action.disabled = false
          })
          .catch(err => {
            throw err
          })
      } else if (text.includes("根")) {
        add(addParams)
          .then(() => {
            this.action.show = false
            this.handle()
            this.action.disabled = false
          })
          .catch(err => {
            throw err
          })
      } else if (text.includes("子")) {
        add(Object.assign(addParams, { parentId: this.parentId }))
          .then(() => {
            this.action.show = false
            this.handle()
            this.action.disabled = false
          })
          .catch(err => {
            throw err
          })
      }
    },
    del(i, v) {
      this.$confirm(this.$t('_tm.messages.tip_11'), this.$t('_tm.dialog.tip'), {
        confirmButtonText: this.$t('_tm.dialog.confirm'),
        cancelButtonText: this.$t('_tm.dialog.cancel'),
        type: "warning"
      })
        .then(() => {
          //点击确定的操作(调用接口)
          remove(v.id).then(() => {
            this.$message({
              showClose: true,
              message: this.$t('_tm.messages.tip_12'),
              type: "success"
            })
            this.action.show = false
            this.handle()
          })
        })
        .catch(() => {
          return false
        })
    }
  }
}
