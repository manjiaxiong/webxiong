<template>
  <div  style="padding:10px">
    <vxe-grid
      border
      resizable
      height="530"
      ref="xGrid"
      :loading="loading"
      :pager-config="tablePage"
      :columns="tableColumn"
      :data="tableData"
      :seq-config="{
        startIndex: (tablePage.currentPage - 1) * tablePage.pageSize
      }"
      :export-config="{}"
      :toolbar-config="tableToolbar"
      @page-change="handlePageChange"
    >
      <template v-slot:toolbar_buttons>
        <vxe-button status="primary"  size="small" @click="insertEvent" style="marginLeft:10px">{{$t('_tm.table.actions.add')}}</vxe-button>
        <vxe-button status="primary"  size="small" @click="refreshEvent">{{$t('_tm.table.actions.refresh')}}</vxe-button>
      </template>
      <template v-slot:operate="{ row }">
        <vxe-button
          status="primary"
          type="text"
          icon="fa fa-edit"
          title="编辑"
          circle
          @click="editRowEvent(row)"
        >{{$t('_tm.table.actions.edit')}}</vxe-button>
        <vxe-button
          status="primary"
          type="text"
          icon="fa fa-trash"
          title="删除"
          circle
          @click="removeRowEvent(row)"
        >{{$t('_tm.table.actions.delete')}}</vxe-button>
      </template>
    </vxe-grid>
    <vxe-modal
      v-model="showEdit"
      :title="selectRow ? '编辑' : '新增'"
      width="800"
      min-width="600"
      min-height="300"
      resize
      destroy-on-close
      @close="modelClose"
    >
      <template v-slot>
        <vxe-form
          :data="formData"
          :items="formItems"
          :rules="formRules"
          title-align="right"
          title-width="100"
          @submit="submitEvent"
        ></vxe-form>
      </template>
    </vxe-modal>
  </div>
</template>

<script>
import { addData, updateData, removeData, getEveryItem } from "../api";
export default {
  data() {
    return {
      dictType: "", //用于刷新，记录字段类型
      editId: null, //用于修改，记录id
      loading: false,
      tableData: [],
      selectRow: null,
      showEdit: false,
      tableToolbar: {
        // refresh: {},
        export: true,
        zoom: true,
        custom: true,
        slots: {
          buttons: "toolbar_buttons"
        }
      },
      tablePage: {
        total: 0,
        currentPage: 1,
        pageSize: 10,
        align: "left",
        pageSizes: [10, 20, 50, 100, 200, 500],
        layouts: [
          "Sizes",
          "PrevJump",
          "PrevPage",
          "Number",
          "NextPage",
          "NextJump",
          "FullJump",
          "Total"
        ]
      },
      formData: {
        dictType: "",
        fieldName: "",
        fieldType: "",
        enableState: 1,
        sort: 1,
        remarks: ""
      },
      formItems: [
        {
          field: "dictType",
          title: this.$t('_tm.table.columns.dict.dictType'),
          span: 12,
          itemRender: {
            name: "$input",
            props: { placeholder: this.$t('_tm.placeholders.message_16') }
          }
        },
        {
          field: "fieldName",
          title: this.$t('_tm.table.columns.dict.fieldDesc'),
          span: 12,
          itemRender: {
            name: "$input",
            props: { placeholder: this.$t('_tm.placeholders.message_21') }
          }
        },
        {
          field: "fieldType",
          title: this.$t('_tm.table.columns.dict.fieldType'),
          span: 12,
          itemRender: { name: "$input", props: { placeholder: this.$t('_tm.placeholders.message_19') } }
        },
        {
          field: "enableState",
          title: this.$t('_tm.table.columns.dict.enableState'),
          span: 12,
          itemRender: {
            name: "$radio",
            options: [
              { label: this.$t('_tm.common.yes'), value: 1 },
              { label: this.$t('_tm.common.no'), value: 0 }
            ]
          }
        },
        {
          field: "sort",
          title: this.$t('_tm.table.columns.dict.sort'),
          span: 12,
          itemRender: {
            name: "$input",
            props: { type: "number", placeholder: this.$t('_tm.placeholders.message_20') }
          }
        },
        {
          field: "remarks",
          title:  this.$t('_tm.table.columns.dict.remarks'),
          span: 12,
          itemRender: { name: "$input", props: { placeholder: this.$t('_tm.placeholders.message_9') } }
        },
        {
          align: "center",
          span: 24,
          titleAlign: "left",
          itemRender: {
            name: "$buttons",
            children: [
              { props: { type: "submit", content: this.$t('_tm.table.actions.submit'), status: "primary" } },
              { props: { type: "reset", content: this.$t('_tm.table.actions.reset') } }
            ]
          }
        }
      ],
      tableColumn: [
        { type: "seq", width: 60, title: this.$t('_tm.table.columns.seq') },
        {
          field: "dictType",
          title: this.$t('_tm.table.columns.dict.dictType'),
          width: "20%"
        },
        {
          field: "fieldName",
          title: this.$t('_tm.table.columns.dict.fieldDesc'),
          width: "15%"
        },
        {
          field: "fieldType",
          title: this.$t('_tm.table.columns.dict.fieldType'),
          width: 120
        },
        {
          field: "enableState",
          title: this.$t('_tm.table.columns.dict.enableState'),
          width: 120,
          //单项筛选
          filters: [
            { label: this.$t('_tm.common.yes'), value: 1 },
            { label: this.$t('_tm.common.no'), value: 0 }
          ],
          filterMultiple: false,
          //值过滤
          formatter: this.formatState
        },
        {
          field: "sort",
          title: this.$t('_tm.table.columns.dict.sort'),
          width: 120,
          sortable: true
        },
        // {
        //   field: "dictTypeValue",
        //   title: "字典类型值",
        //   width: 120,
        //   showOverflow: true,
        //   extend: true, //是否是扩展属性
        // },
        // {
        //   field: "param",
        //   title: "参数",
        //   width: 120,
        //   showOverflow: true,
        //   extend: true, //是否是扩展属性
        // },
        {
          field: "remarks",
          title: this.$t('_tm.table.columns.remarks'),
          width: 120,
          showOverflow: true
        },
        { title: this.$t('_tm.table.columns.operation'), width: 150, slots: { default: "operate" } }
      ],
      formRules: {
        enableState: [{ required: true, message: this.$t('_tm.rules.message_12') }],
        sort: [{ required: true, message: this.$t('_tm.rules.message_13') }],
        dictType: [{ required: true, message: this.$t('_tm.rules.message_14') }]
      }
    };
  },
  methods: {
    formatState({ cellValue }) {
      return cellValue == 1 ? this.$t('_tm.common.yes') : this.$t('_tm.common.no');
    },
    findList(params) {
      // 模拟后台接口
      this.loading = true;
      getEveryItem(this.tablePage.currentPage, this.tablePage.pageSize, params)
        .then(({ number, pageNum, pageSize, pages, size, total, list }) => {
          this.tableData = list.map(v => {
            return { ...v, ...v.parameters };
          });
          this.tablePage.total = total;
          this.loading = false;
        })
        .catch(e => {
          this.loading = false;
        });
    },
    searchEvent() {
      this.tablePage.currentPage = 1;
      this.refreshEvent();
    },
    handlePageChange({ currentPage, pageSize }) {
      this.tablePage.currentPage = currentPage;
      this.tablePage.pageSize = pageSize;
      this.refreshEvent();
    },
    // 修改
    editRowEvent(row) {
      this.formData = {
        dictType: row.dictType,
        fieldName: row.fieldName,
        fieldType: row.fieldType,
        enableState: row.enableState,
        sort: row.sort,
        remarks: row.remarks
      };
      this.dictType = row.dictType;
      this.editId = row.id;
      this.selectRow = row;
      this.showEdit = true;
    },
    // 新增
    insertEvent() {
      this.formData.sort = this.tableData.length + 1;
      this.formData.dictType = this.dictType;
      this.selectRow = null;
      this.showEdit = true;
    },
    // 扩展字段数据处理
    extendOperate(arrs) {
      const ass = [];
      const arr = [];
      this.tableColumn.map(v => {
        if (v.extend) {
          arr.push(JSON.parse(`{"${v.field}":"${arrs[v.field]}"}`));
        } else {
          ass.push(JSON.parse(`{"${v.field}":"${arrs[v.field]}"}`));
        }
      });
      const fils = ass.filter(v => !v.undefined);
      fils.push({
        parameters: Object.assign.apply(Object, [{}].concat(arr))
      });
      return fils;
    },
    // 删除
    removeRowEvent(row) {
      this.$confirm(this.$t('_tm.messages.tip_11'), this.$t('_tm.dialog.title'), {
        confirmButtonText: this.$t('_tm.dialog.confirm'),
        cancelButtonText:  this.$t('_tm.dialog.cancel'),
        type: "warning"
      })
        .then(() => {
          removeData(row.id)
            .then(res => {
              this.$message({
                message: this.$t('_tm.messages.tip_12'),
                type: "success"
              });
              this.refreshEvent();
            })
            .catch(e => {
              console.log(e);
            });
        })
        .catch(() => {
          return false;
        });
    },
    // 刷新
    refreshEvent() {
      this.findList(`dictType=${this.dictType}`);
    },
    // destroy-on-close属性失效，手动清除数据
    modelClose() {
      this.formData = {
        dictType: "",
        fieldName: "",
        fieldType: "",
        enableState: 1,
        sort: 1,
        remarks: ""
      };
    },
    // 弹框保存
    submitEvent() {
      this.showEdit = false;
      if (this.selectRow) {
        updateData(
          Object.assign.apply(
            Object,
            [{}].concat(this.extendOperate(this.formData))
          ),
          this.editId
        )
          .then(res => {
            this.$message({
              message: this.$t('_tm.messages.tip_15'),
              type: "success"
            });
            this.modelClose();
            this.refreshEvent();
          })
          .catch(e => {
            console.log(e);
          });
      } else {
        addData(
          Object.assign.apply(
            Object,
            [{}].concat(this.extendOperate(this.formData))
          )
        )
          .then(res => {
            this.$message({
              message: this.$t('_tm.messages.tip_16'),
              type: "success"
            });
            this.modelClose();
            this.refreshEvent();
          })
          .catch(e => {
            console.log(e);
          });
      }
    }
  }
};
</script>
