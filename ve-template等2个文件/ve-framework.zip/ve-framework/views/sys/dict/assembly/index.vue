<template>
  <el-dialog
    width="35%"
    :title="action.text"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :visible.sync="action.show"
    @close="close"
  >
    <el-form :label-position="labelPosition" label-width="70px" class="form">
      <el-form-item :label="$t('_tm.common.type')">
        <el-input
          v-model="action.model"
          :disabled="action.disabled ? true : false"
        ></el-input>
      </el-form-item>
      <el-form-item :label="$t('_tm.common.desc')">
        <el-input v-model="action.name"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer">
      <el-button @click="cancel">{{$t('_tm.dialog.cancel')}}</el-button>
      <el-button type="primary" @click="save">{{$t('_tm.dialog.save')}}</el-button>
    </div>
  </el-dialog>
</template>

<script>
export default {
  props: {
    action: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      labelPosition: "right"
    };
  },
  methods: {
    close() {
      this.$emit("cancel");
    },
    cancel() {
      this.$emit("cancel");
    },
    save() {
      this.$emit("save");
    }
  }
};
</script>

<style lang="scss" >
.form {
  margin-bottom: -30px;
}
</style>
