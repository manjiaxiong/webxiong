<!--
 * @Author: your name
 * @Date: 2020-11-16 16:18:13
 * @LastEditTime: 2020-12-09 20:31:21
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ve-framework\views\sys\dict\category.vue
-->
<template>
  <div class="main-content">
    <auto-table
      :name="$t('_tm.dialog.title.dictCategory')"
      scope="dictCategory"
      :methods="methods"
      :controls="controls"
      :table="table"
      :options="options"
    ></auto-table>
  </div>
</template>

<script>
import { addCategory, updateCategory, subURL } from "../../../api/dict";
export default {
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      methods: {
        add: addCategory,
        update: updateCategory
      },
      options: [
        {
          id: "dictType",
          name: this.$t('_tm.table.columns.dict.dictType'),
          placeholder: this.$t('_tm.placeholders.message_16'),
          rules: [
            { required: true, message: this.$t('_tm.rules.message_10'), trigger: "blur" }
          ],
          readonly(type) {
            return type === "edit";
          }
        },
        {
          id: "dictName",
          name: this.$t('_tm.table.columns.dict.dictName'),
          placeholder: this.$t('_tm.placeholders.message_17'),
          rules: [
            { required: true, message: this.$t('_tm.rules.message_11'), trigger: "blur" }
          ]
        }
      ],
      table: {
        url:  subURL + "/dicttype",
        pagination: "urlParams",
        pageIndexKey: "page",
        pageSizeKey: "size",
        operation: {
          width: "90px",
          type: "text",
          size: "mini",
          buttons: [
            {
              name: this.$t('_tm.table.actions.edit'),
              command: "edit",
              icon: true
            }
          ]
        },
        columns: [
          {
            label: this.$t('_tm.table.columns.dict.dictType'),
            prop: "dictType"
          },
          {
            label: this.$t('_tm.table.columns.dict.dictName'),
            prop: "dictName"
          }
        ],
        formOptions: {
          inline: true,
          submitBtnText: this.$t('_tm.table.actions.search'),
          forms: [
            { prop: "dictName", placeholder: this.$t('_tm.placeholders.message_18'), clearable: true }
          ]
        }
      },
      controls: [
        {
          name: this.$t('_tm.table.actions.add'),
          command: "add"
        }
      ]
    };
  },
  deactivated() {
    this.$dict.init();
  }
};
</script>
