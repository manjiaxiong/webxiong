<template>
  <div class="tree-dict">
    <tree-table
      id="id"
      init
      show
      :ability="ability"
      :forms="forms"
      :get-tree-table="getTreeTable"
      :table-data="tableData"
      @handle="handle"
    >
      <div class="search">
        <!-- <span class="colors">字典类型</span> -->
        <el-input
          v-model="model"
          clearable
          :placeholder="$t('_tm.placeholders.message_16')"
          @input="filterKeys"
        ></el-input>
      </div>
      <template #add>
        <el-button
          type="primary"
          size="small"
          icon="el-icon-circle-plus-outline"
          @click="add"
          >{{$t('_tm.table.actions.append')}}</el-button
        >
      </template>
      <template #operation>
        <el-table-column :label="$t('_tm.table.columns.operation')">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
              @click="edit(scope.$index, scope.row)"
              >{{$t('_tm.table.actions.edit')}}</el-button
            >
            <el-button
              size="mini"
              type="text"
              icon="el-icon-delete"
              @click="del(scope.$index, scope.row)"
              >{{$t('_tm.table.actions.delete')}}</el-button
            >
            <el-button
              size="mini"
              type="text"
              icon="el-icon-circle-plus-outline"
              @click="addSon(scope.$index, scope.row)"
              >{{$t('_tm.table.actions.dict.addChild')}}</el-button
            >
            <el-button
              size="mini"
              type="text"
              icon="el-icon-setting"
              @click="set(scope.$index, scope.row)"
              >{{$t('_tm.table.actions.dict.manage')}}</el-button
            >
          </template>
        </el-table-column>
      </template>
    </tree-table>
    <action :action="action" @cancel="cancel" @save="save" />
    <detail :drawer="drawer" :types="types" :groups="groups" @done="done" />
  </div>
</template>

<script>
import index from "./assembly/index";
import detail from "./assembly/detail";
import action from "./assembly/index.vue";
import treeTable from "./assembly/treeTable";
import { getTree, getParentNodes } from "./api";
const copyArray = [];
export default {
  components: { action, detail, treeTable },
  mixins: [index],
  data() {
    return {
      ability: this.$t('_tm.table.actions.search'),
      model: null,
      groups: [],
      forms: [
        {
          prop: "dictType",
          label: this.$t('_tm.common.type')
        },
        {
          prop: "dictName",
          label: this.$t('_tm.common.desc')
        }
      ],
      getTreeTable: getTree(),
      tableData: []
    };
  },
  async mounted() {
    // this.tableData = await getTree();
  },
  methods: {
    // 查询
    async handle() {
      this.tableData = await getTree({ type: this.model });
    },
    async set(i, v) {
      if (v.parentId) {
        const result = await getParentNodes(v.dictType);
        this.groups = result;
      }
      if (v.dictType === " " || v.dictType == null) {
        this.$nextTick(() => {
          this.types = v.id;
        });
      }
      this.drawer = true;
      this.types = v.dictType;
    },
    filterKeys() {
      return;
    }
  }
};
</script>

<style lang="scss" scoped>
.search {
  width: 270px;
  display: flex;
  position: absolute;
  span {
    display: block;
    width: 100px;
    margin-right: 10px;
    line-height: 40px;
  }
}
</style>
