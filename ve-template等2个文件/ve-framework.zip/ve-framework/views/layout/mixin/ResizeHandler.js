import store from "../../../store";

export default {
  watch: {
    // eslint-disable-next-line
    $route(route) {
      if (this.device === "mobile" && this.sidebar.opened) {
        store.dispatch("closeSideBar", {
          withoutAnimation: false
        });
      }
    }
  },
  beforeMount() {
    window.addEventListener("resize", this.resizeHandler);
  },
  mounted() {
    const isMobile = this.isMobile();
    if (isMobile) {
      store.dispatch("toggleDevice", "mobile");
      store.dispatch("closeSideBar", {
        withoutAnimation: true
      });
    }
  },
  methods: {
    isMobile() {
      return false;
    },
    resizeHandler() {
      if (!document.hidden) {
        const isMobile = this.isMobile();
        store.dispatch("toggleDevice", isMobile ? "mobile" : "desktop");

        if (isMobile) {
          store.dispatch("closeSideBar", {
            withoutAnimation: true
          });
        }
      }
    }
  }
};
