<template>
  <div v-if="!item.hidden" class="menu-wrapper">
    <template
      v-if="
        !item.children ||
        item.children.length === 0 ||
        hideChildren(item.children)
      "
    >
      <!-- <app-link :to="resolvePath(item.path)"> -->
      <el-menu-item
        :index="item.id"
        :class="{ 'submenu-title-noDropdown': !isNest }"
        @click="menuHandle(item)"
      >
        <item
          v-if="item.name"
          :icon="item.ico"
          :title="generateTitle(item.name)"
        />
      </el-menu-item>
      <!-- </app-link> -->
    </template>

    <el-submenu v-else ref="submenu" :index="item.id">
      <template slot="title">
        <item
          v-if="item.name"
          :icon="item.ico"
          :title="generateTitle(item.name)"
        />
      </template>

      <template v-for="child in item.children">
        <template v-if="!child.hidden">
          <sidebar-item
            :is-nest="true"
            :item="child"
            :key="child.id"
            :base-path="resolvePath(child.path)"
            class="nest-menu"
          />
        </template>
      </template>
    </el-submenu>
  </div>
</template>

<script>
import path from "path";
import { generateTitle } from "../../../../utils/i18n";
import { isExternal } from "../../../../utils";
import Item from "./Item";
import AppLink from "./Link";
import FixiOSBug from "./FixiOSBug";

export default {
  name: "SidebarItem",
  components: { Item, AppLink },
  mixins: [FixiOSBug],
  props: {
    // route object
    item: {
      type: Object,
      required: true
    },
    isNest: {
      type: Boolean,
      default: false
    },
    basePath: {
      type: String,
      default: ""
    }
  },
  data() {
    return {};
  },
  methods: {
    resolvePath(routePath) {
      routePath = routePath || "";
      if (isExternal(routePath)) {
        return routePath;
      }
      return path.resolve(this.basePath, routePath);
    },
    generateTitle,
    hideChildren(children) {
      return children.every(item => item.hidden);
    },
    menuHandle(item) {
      let { type, path } = item;
      if (type === 2) {
        window.open(path);
      } else if (type === 4) {
        let p = "/" + path;
        this.$router.push(p);
      } else {
        this.$router.push(this.resolvePath(path));
      }
    }
  }
};
</script>
<style lang="scss">
// .el-menu--horizontal > .menu-wrapper {
//   float: left;
// }
</style>
