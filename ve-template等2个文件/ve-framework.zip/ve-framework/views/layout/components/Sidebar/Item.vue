<template>
  <div>
    <icon class="sidebar-icon" :content="icon" :size="14" />
    <span slot="title">{{ title }}</span>
  </div>
</template>

<script>
export default {
  name: "MenuItem",
  props: {
    icon: {
      type: String,
      default: ""
    },
    title: {
      type: String,
      default: ""
    }
  }
};
</script>

<style lang="scss">
.sidebar-icon {
  margin-right: 8px;
}
</style>
