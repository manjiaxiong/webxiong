<template>
  <div class="no-select">
    <div class="top" v-if="mode === 'vertical'">
      <div class="title">{{$t('_tm.navbar.userMenu')}}</div>
      <i
        class="sidebar-toggle"
        :class="[isCollapse ? 'el-icon-s-unfold ' : 'el-icon-s-fold ']"
        @click="toggleSideBar"
      ></i>
    </div>
    <el-menu
      ref="menu"
      class="sidebar-menu"
      :show-timeout="200"
      :default-active="$route.meta.id || $route.path"
      :collapse="isCollapse"
      unique-opened
      :mode="mode"
      @wheel.native="handleScroll"
    >
      <template v-if="asyncRouters.length">
        <sidebar-item
          v-for="route in asyncRouters"
          :key="route.id"
          :item="route"
          :base-path="route.path"
        />
      </template>
    </el-menu>
  </div>
</template>

<script>
import { mapGetters, mapState } from "vuex";
import SidebarItem from "./SidebarItem";

export default {
  components: { SidebarItem },
  props: {
    mode: {
      type: String,
      default: "vertical"
    }
  },
  computed: {
    ...mapGetters(["asyncRouters", "sidebar"]),
    isCollapse() {
      return !this.sidebar.opened;
    }
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch("toggleSideBar");
    },
    // 鼠标滚轮事件（wheelEvent）
    handleScroll(e) {
      if (this.mode === "horizontal") {
        // wheelDelta：获取滚轮滚动方向，向上120，向下-120，但为常量，与滚轮速率无关
        // deltaY：垂直滚动幅度，正值向下滚动。电脑鼠标滚轮垂直行数默认值是3
        // wheelDelta只有部分浏览器支持，deltaY几乎所有浏览器都支持
        const eventDelta = e.wheelDelta || -e.deltaY * 40;
        const $scrollWrapper = this.$refs.menu.$el;
        // 0到scrollLeft为滚动区域隐藏部分
        $scrollWrapper.scrollLeft = $scrollWrapper.scrollLeft - eventDelta / 4;
        e.preventDefault();
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 36px;
  background-color: #cce7fc;

  .title {
    font-size: 12px;
    color: #444;
    margin-left: 10px;
  }

  .sidebar-toggle {
    height: 100%;
    display: flex;
    align-items: center;
    cursor: pointer;
    transition: background 0.3s;
    padding: 0 15px;
    font-size: 18px;
    color: #333;

    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }
}
.sidebar-menu {
  overflow-y: auto;
  height: 100%;
  border-right: none;
  &::-webkit-scrollbar {
    width: 0px;
    height: 0px;
  }
}
</style>
