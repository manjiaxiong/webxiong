<template>
  <section
    class="app-main"
    :style="{ background: mainBgColor }"
    v-if="isRouterAlive"
  >
    <iframe
      v-if="$route.meta.type === 4"
      :src="$route.meta.path"
      width="100%"
      height="100%"
      frameborder="0"
      scrolling="yes"
    >
    </iframe>

    <template v-else>
      <div class="app-main-wrapper" v-show="!cachePaths.includes($route.path)">
        <transition name="fade-transform" mode="out-in">
          <keep-alive :include="cachedViews">
            <router-view :key="key" />
          </keep-alive>
        </transition>
      </div>

      <transition-group name="fade-transform" mode="out-in">
        <component
          v-for="cache in cachePaths"
          :key="cache"
          :is="cache.substring(1).replace(/\//g, '-')"
          v-show="$route.path === cache"
        ></component>
      </transition-group>
    </template>
  </section>
</template>

<script>
import Vue from "vue";
export default {
  name: "AppMain",
  data() {
    return {
      isRouterAlive: true //控制视图是否显示的变量
    };
  },
  computed: {
    cachedViews() {
      return this.$store.state.tagsView.cachedViews;
    },
    cachePaths() {
      var cachePaths = this.$store.state.tagsView.cachePaths;
      cachePaths.forEach(path => {
        var compId = path.substring(1).replace(/\//g, "-");
        if (!Vue.component(compId)) {
          Vue.component(compId, () => import(`@/views${path}`));
        }
      });
      return this.$store.state.tagsView.cachePaths;
    },
    key() {
      return this.$route.fullPath;
    },
    mainBgColor() {
      return this.$store.state.layout.mainBgColor;
    },
    language() {
      return this.$store.state.app.language;
    }
  },
  watch: {
    language() {
      this.isRouterAlive = false; //先关闭，
      this.$nextTick(() => {
        this.isRouterAlive = true; //再打开
      });
    },
    $route: {
      handler(val) {
        // console.log(val);
      },
      immediate: true,
      deep: false
    }
  }
};
</script>

<style lang="scss" scoped>
.app-main {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  overflow-y: auto;
  overflow-x: hidden;
  flex: 1;
  padding: 10px;
  .app-main-wrapper {
    box-sizing: border-box;
    height: 100%;
  }
  > .full-height {
    height: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    flex: 1;

    > .full-height {
      height: 100%;
    }
  }
}
</style>
