<template>
  <div class="navbar">
    <div class="left-menu">
      <slot name="logo">
        <!-- <img class="logo" src="../img/logo.png" alt="" /> -->
      </slot>

      <div class="title">
        <slot name="title">
          {{ systemInfo.name || $config.title }}
        </slot>
      </div>
    </div>

    <slot></slot>

    <div class="right-menu">
      <slot name="right-menu"></slot>
      <div
        class="right-menu-item hover-effect"
        style="color: #fff"
        @click="toggleLang()"
        v-if="$config.i18n.show"
      >
        中文 / En
      </div>
      <screenfull class="right-menu-item hover-effect right-menu-icon" />
      <slot name="screenlock">
        <!-- 锁屏按钮 -->
        <screenlock class="right-menu-item hover-effect right-menu-icon" />
      </slot>

      <div class="right-menu-item hover-effect" @click="showRight">
        <i class="el-icon-setting right-menu-icon"></i>
      </div>
      <el-dropdown
        class="avatar-container right-menu-item hover-effect"
        trigger="click"
      >
        <div class="avatar-wrapper">
          <i class="fa fa-user-circle right-menu-icon"></i>
          <span class="username">{{ nickname }}</span>
          <i class="el-icon-caret-bottom" />
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>
            <div @click="dialogFormVisible = true">
              {{ $t("_tm.navbar.updatePassword") }}
            </div>
          </el-dropdown-item>
          <el-dropdown-item divided>
            <span style="display: block" @click="logout">{{
              $t("_tm.navbar.logOut")
            }}</span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>

    <!-- 修改密码对话框 -->
    <el-dialog
      :title="$t('_tm.navbar.updatePassword')"
      width="550px"
      custom-class="custom-dialog"
      :visible.sync="dialogFormVisible"
      @open="handleDialogOpen"
    >
      <el-row>
        <el-col :span="20" :offset="2">
          <el-form
            :model="ruleForm"
            :rules="rules"
            ref="ruleForm"
            label-width="90px"
          >
            <el-form-item :label="$t('_tm.navbar.oldPass')" prop="oldPass">
              <el-input
                v-model="ruleForm.oldPass"
                type="password"
                auto-complete="off"
                size="medium"
              ></el-input>
            </el-form-item>
            <el-form-item
              :label="$t('_tm.navbar.newPass')"
              required
              prop="newPass"
            >
              <el-input
                v-model="ruleForm.newPass"
                type="password"
                auto-complete="off"
                size="medium"
              ></el-input>
            </el-form-item>
            <el-form-item
              :label="$t('_tm.navbar.confirmPass')"
              required
              prop="newPass2"
              style="margin: 0"
            >
              <el-input
                v-model="ruleForm.newPass2"
                type="password"
                auto-complete="off"
                size="medium"
              ></el-input>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">{{
          $t("_tm.dialog.cancel")
        }}</el-button>
        <el-button type="primary" @click="submitForm('ruleForm')">{{
          $t("_tm.dialog.save")
        }}</el-button>
      </div>
    </el-dialog>
    <main-right ref="mainRight" />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import MainRight from "./Setting";
import Screenfull from "../../../components/Screenfull";
import Screenlock from "../../../components/Screenlock";
import { getToken } from "../../../utils/auth";
import { passwordEdit } from "../../../api/user.js";
import { logout } from "../../../api/login.js";
// import { toggleClass } from "../../../utils";
import md5 from "../../../utils/md5";
import { getConfig } from "../../../config";

export default {
  components: {
    Screenfull,
    Screenlock,
    MainRight
  },
  props: {},
  data() {
    return {
      dialogFormVisible: false,
      ruleForm: {
        oldPass: "",
        newPass: "",
        newPass2: ""
      },
      rules: {
        oldPass: [
          {
            required: true,
            message: this.$t("_tm.rules.message_0"),
            trigger: "blur"
          }
        ],
        newPass: [
          {
            required: true,
            message: this.$t("_tm.rules.message_1"),
            trigger: "blur"
          },
          {
            min: 6,
            message: this.$t("_tm.rules.message_2"),
            trigger: "blur"
          },
          {
            pattern: eval(getConfig('pwdValidate.RegExp')),
            message: getConfig('pwdValidate.message') ,
            trigger: "blur"
          }
        ],
        newPass2: [
          {
            required: true,
            message: this.$t("_tm.rules.message_1"),
            trigger: "blur"
          },
          {
            min: 6,
            message: this.$t("_tm.rules.message_2"),
            trigger: "blur"
          },
          {
            pattern: eval(getConfig('pwdValidate.RegExp')),
            message: getConfig('pwdValidate.message') ,
            trigger: "blur"
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters(["sidebar", "nickname", "systemInfo"])
  },
  methods: {
    toggleLang() {
      let lang = this.$i18n.locale == "en" ? "zh" : "en";
      this.$store.commit("SET_LANGUAGE", lang);
    },
    showRight(flag) {
      this.$refs.mainRight.showRight();
    },

    toggleSideBar() {
      this.$store.dispatch("toggleSideBar");
    },
    handleDialogOpen() {
      //重置表单
      if (this.$refs["ruleForm"]) {
        this.$refs["ruleForm"].resetFields();
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          let { newPass, newPass2, oldPass } = this.ruleForm;
          if (newPass === oldPass) {
            this.$message.error(this.$t("_tm.messages.tip_3"));
            return null;
          }
          if (newPass !== newPass2) {
            this.$message.error(this.$t("_tm.messages.tip_4"));
            return null;
          }
          const compatible = getConfig("api.authority.compatible");
          //请求更改密码接口
          let param = {
            oldPassword: compatible
              ? this.ruleForm.oldPass
              : md5(md5(this.ruleForm.oldPass)), //必填
            newPassword: compatible
              ? this.ruleForm.newPass
              : md5(md5(this.ruleForm.newPass)) //必填
          };

          passwordEdit(param).then(() => {
            //关闭弹出框
            this.dialogFormVisible = false;
            //成功提示
            this.$message({
              message: this.$t("_tm.messages.tip_5"),
              type: "success"
            });
            setTimeout(() => {
              this.logout();
            }, 1000);
          });
        } else {
          return false;
        }
      });
    },
    async logout() {
      logout();
      await this.$store.dispatch("FedLogOut");
    }
  }
};
</script>

<style lang="scss" scoped>
$navbarBg: #409eff;
.navbar {
  height: 100%;
  overflow: hidden;
  background: $navbarBg;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;

  .left-menu {
    height: 100%;
    font-size: 24px;
    color: #fff;
    min-width: 120px;
    display: flex;
    align-items: center;
    margin-right: 20px;
  }

  .right-menu {
    user-select: none;
    height: 100%;
    display: flex;
    justify-content: flex-end;
    min-width: 100px;
    margin-left: 20px;
    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: flex;
      padding: 0 15px;
      align-items: center;
      height: 100%;
      color: #fff;
      vertical-align: text-bottom;
      font-size: 14px;
      .right-menu-icon {
        font-size: 18px;
      }
      &.hover-effect {
        cursor: pointer;
        transition: background 0.3s;
        &:hover {
          background: rgba(0, 0, 0, 0.075);
        }
      }
    }

    .avatar-container {
      .avatar-wrapper {
        display: flex;
        align-items: center;
        color: #fff;
        height: 100%;

        .user-avatar {
          cursor: pointer;
          width: 40px;
          height: 40px;
          border-radius: 10px;
        }

        .username {
          font-size: 14px;
          margin-left: 8px;
        }

        .el-icon-caret-bottom {
          color: #fff;
          font-size: 12px;
          margin-left: 6px;
        }
      }
    }
  }

  // 横向菜单：覆盖默认样式
  ::v-deep .el-menu--horizontal {
    border-bottom: none;
    .menu-wrapper {
      border-bottom: none !important;
      height: 60px;
      .el-menu-item,
      .el-submenu {
        height: 60px;
        .el-submenu__title {
          height: 100%;
          .el-submenu__icon-arrow {
            right: 4px;
          }
        }
      }
    }
  }
}
</style>
