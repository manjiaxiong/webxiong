<template>
  <el-container class="app-wrapper">
    <el-header style="padding: 0; border-bottom: 0">
      <slot name="navbar">
        <navbar>
          <template #logo>
            <slot name="logo"></slot>
          </template>
          <template #title>
            <slot name="title"></slot>
          </template>
          <sidebar
            class="sidebar-container"
            :mode="mode"
            v-if="mode === 'horizontal'"
          />
          <template #right-menu>
            <slot name="right-menu"></slot>
          </template>
          <template #screenlock>
            <slot name="screenlock"></slot>
          </template>
        </navbar>
      </slot>
    </el-header>
    <slot name="main">
      <el-container class="main-content-wrapper">
        <el-aside
          :style="asideStyle"
          :class="classObj"
          v-if="mode === 'vertical'"
        >
          <sidebar class="sidebar-container" :mode="mode" />
        </el-aside>
        <el-main class="body-container">
          <tags-view v-if="multipage" />
          <app-main />
        </el-main>
      </el-container>
      <slot name="footer"></slot>
    </slot>
  </el-container>
</template>

<script>
import { Navbar, Sidebar, AppMain, TagsView } from "./components";
import ResizeMixin from "./mixin/ResizeHandler";

export default {
  name: "Layout",
  components: {
    Navbar,
    Sidebar,
    AppMain,
    TagsView
  },
  mixins: [ResizeMixin],
  props: {
    asideWidth: {
      type: Number,
      default: 200
    }
  },
  computed: {
    mode() {
      return this.$store.state.layout.mode;
    },
    multipage() {
      return this.$store.state.layout.multipage;
    },
    sidebar() {
      return this.$store.state.app.sidebar;
    },
    device() {
      return this.$store.state.app.device;
    },
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === "mobile"
      };
    },
    asideStyle() {
      return "width: " + this.asideWidth + "px;";
    }
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch("closeSideBar", {
        withoutAnimation: false
      });
    }
  },
  mounted() {}
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "../../styles/mixin.scss";

.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;

  .main-content-wrapper {
    flex: 1;
    overflow: hidden;
  }

  &.mobile.openSidebar {
    position: fixed;
    top: 0;
  }
}

.drawer-bg {
  background: #000;
  opacity: 0.3;
  width: 100%;
  top: 0;
  height: 100%;
  position: absolute;
  z-index: 999;
}

.hideSidebar {
  width: 54px !important;
}

aside {
  overflow: hidden;
  height: 100%;
}

.body-container {
  padding: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-sizing: border-box;
}
</style>
