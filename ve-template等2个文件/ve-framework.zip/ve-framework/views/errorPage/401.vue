<template>
  <div class="errPage-container error">
    <!-- <el-button icon="arrow-left" class="pan-back-btn" @click="back"
      >返回</el-button
    >-->
    <div class="img-dv">
      <img :src="src" alt />
      <span>{{$t('_tm.errorPage.401')}}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: "Page401",
  data() {
    return {
      src: require("../../assets/401_images/error-401.png")
    };
  },
  methods: {
    back() {
      if (this.$route.query.noGoBack) {
        this.$router.push({ path: "/dashboard" });
      } else {
        this.$router.go(-1);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.errPage-container {
  width: 100%;
  max-width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  .img-dv {
    width: 600px;
    img {
      width: auto;
      height: auto;
      max-width: 100%;
      max-height: 100%;
      margin: 0 auto;
    }

    span {
      display: block;
      font-size: 28px;
      padding-top: 10px;
      color: #707070;
      text-align: center;
      line-height: 35px;
    }
  }

  .pan-back-btn {
    background: #008489;
    color: #fff;
    border: none !important;
  }
  .pan-gif {
    margin: 0 auto;
    display: block;
  }
  .pan-img {
    display: block;
    margin: 0 auto;
    width: 100%;
  }
  .text-jumbo {
    font-size: 60px;
    font-weight: 700;
    color: #484848;
  }
  .list-unstyled {
    font-size: 14px;
    li {
      padding-bottom: 5px;
    }
    a {
      color: #008489;
      text-decoration: none;
      &:hover {
        text-decoration: underline;
      }
    }
  }
}
</style>
