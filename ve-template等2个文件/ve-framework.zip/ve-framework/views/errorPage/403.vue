<template>
  <Layout>
    <template #main>
      <div class="welcome no-right">
        <div class="img-dv">
          <img :src="src" alt />
          <span>{{$t('_tm.errorPage.403')}}</span>
        </div>
      </div>
    </template>
  </Layout>
</template>
<script>
import Layout from "../layout/Layout";
export default {
  components: { Layout },
  data() {
    return {
      src: require("../../assets/403_images/no-right.png")
    };
  }
};
</script>
<style lang="scss" scoped>
.welcome {
  padding: 20px;
}
.no-right {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.no-right .img-dv {
  width: 400px;
}
.no-right .img-dv img {
  width: auto;
  height: auto;
  max-width: 100%;
  max-height: 100%;
}
.no-right .img-dv span {
  display: block;
  font-size: 28px;
  padding-top: 10px;
  color: #707070;
  text-align: center;
}
</style>
