<template>
  <div class="group-container full-height">
    <grid @fullscreenchange="fullscreenchange" :topbar="topbar" :rows="rows" :columns="columns">
      <template v-slot="{ index }">
        <div class="map-container flex-vertical" :ref="'map' + index" v-if="maps[index]">
          <div class="title-header">
            <div class="title">
              <div class="left">{{ maps[index].regionName }}</div>
              <div class="center">
                <span>总车数: {{ maps[index].totalNum || 0 }}</span>
                <span>空车: {{ maps[index].emptyNum || 0 }}</span>
                <span>重车: {{ maps[index].heavyNum || 0 }}</span>
              </div>
            </div>
            <div class="btnbars">
              <div
                class="btn"
                v-if="params.table && lists[index] && !maps[index].fullscreen"
                @click="table(index)"
              >
                <i class="el-icon-tickets"></i>
              </div>
              <div class="btn" @click="fullscreen(index)">
                <i class="el-icon-full-screen" v-if="!maps[index].fullscreen"></i>
                <i class="iconfont" v-else>&#xe64a;</i>
              </div>
              <div class="btn close" @click="close(index)">
                <i class="el-icon-close"></i>
              </div>
            </div>
          </div>
          <v-map
            @render="(data, list) => render(data, list, index)"
            class="auto-fill"
            :items="[maps[index]]"
            :params="params"
          ></v-map>
        </div>
        <div v-else class="plus" @click="click(index)">
          <i class="iconfont">&#xe633;</i>
        </div>
      </template>
    </grid>
    <v-dialog :scope="scope" :dialogMaps="dialogMaps"></v-dialog>
  </div>
</template>

<script>
import screenfull from "screenfull";
import Grid from "../../components/Grid";
import Map from "../../widget/Map/regionMonitor";
import tree from "../../dialog/monitor/regionTree";
// 兼容screenfull 4.x
const enabled = screenfull.isEnabled || screenfull.enabled;
export default {
  components: {
    Grid,
    "v-map": Map
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    topbar() {
      return typeof this.params.topbar === "boolean"
        ? this.params.topbar
        : true;
    },
    rows() {
      return this.params.rows || 2;
    },
    columns() {
      return this.params.columns || 2;
    },
    scope() {
      return this.params.out ? "regionOutGrid" : "regionGrid"
    }
  },
  data() {
    return {
      list: [],
      maps: {},
      lists: {},
      dialogMaps: {
        regionTree: {
          title: "选择区域",
          component: tree,
          width: "400px",
          methods: this.renderMap
        },
        carTable: {
          title: this.params.out ? "区域外车辆" : "区域车辆",
          component: this.params.table,
          width: "960px"
        }
      }
    };
  },
  methods: {
    click(index) {
      this.$dialog.open(this.scope, "regionTree", {
        index,
        cars: this.list
      });
    },
    render(data, list, index) {
      if (data) {
        Object.keys(data).forEach(v => {
          this.$set(this.maps[index], v, data[v]);
        });
      }
      if (list) {
        this.lists[index] = list;
      }
    },
    close(index) {
      if (this.maps[index].fullscreen) {
        this.fullscreen(index);
      }
      const { id } = this.maps[index];
      if (id) {
        this.list.remove(id);
      }
      this.$delete(this.maps, index);
      if (this.lists[index]) {
        delete this.lists[index];
      }
    },
    renderMap(id, data) {
      // console.log(id, data);
      if (Array.isArray(data)) {
        data = data[0];
      }
      this.$set(this.maps, id, data);
    },
    table(index) {
      this.$dialog.open(this.scope, "carTable", {
        index,
        data: this.lists[index]
      });
    },
    fullscreen(index) {
      let $ref = this.$refs["map" + index];
      let $el = $ref;
      if ($ref && $ref.length) {
        $el = $ref[0];
      }
      if ($el && enabled) {
        const fullscreen = this.maps[index].fullscreen;
        this.$set(this.maps[index], "fullscreen", !fullscreen);
        screenfull.toggle($el);
      }
    },
    fullscreenchange() {
      Object.keys(this.maps).forEach(k => {
        if (this.maps[k].fullscreen) {
          this.$set(this.maps[k], "fullscreen", false);
        }
      });
    },
    onRefreshData() {
      this.$bus.$emit("getRegionTreeData");
    }
  },
  destroyed() {
    this.list = [];
  }
};
</script>

<style lang="scss" scoped>
.group-container {
  user-select: none;
  padding: 6px;
  padding-top: 3px;
}
</style>
