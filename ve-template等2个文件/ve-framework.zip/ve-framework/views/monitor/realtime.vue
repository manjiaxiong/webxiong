<template>
  <div class="monitor-container">
    <slot name="tree">
      <collapse class="slideMenu" :style="treeStyle" @resize="resize">
        <div class="search-tree no-select">
          <search
            v-if="tree && params.search !== false"
            ref="search"
            :tree="tree"
            :mode="
              params.search
                ? params.search.mode || defaultSearchMode
                : defaultSearchMode
            "
            :params="searchParams"
            @labelChange="labelChange"
            remote
          />
          <tree ref="tree" :params="treeParams" />
        </div>
      </collapse>
    </slot>
    <div class="map-container auto-fill">
      <div class="absolute-wrapper flex-vertical">
        <div class="auto-fill flex" style="overflow: hidden;">
          <slot name="map">
            <v-map ref="map" class="auto-fill" :params="params.map || {}">
              <template #tools>
                <slot name="tools"></slot>
              </template>
              <template #controls>
                <slot name="controls"></slot>
              </template>
              <template #overlays>
                <slot name="overlays"></slot>
              </template>
            </v-map>
          </slot>
          <slot name="video"></slot>
        </div>
        <slot name="table"></slot>
      </div>
    </div>

    <v-dialog v-if="params.dialogMaps" scope="monitor" :dialogMaps="params.dialogMaps" />
  </div>
</template>

<script>
import Search from "../../widget/Search";
import Tree from "../../components/Tree/car";
import Map from "../../widget/Map/monitor";
export default {
  name: "monitor",
  components: {
    Search,
    Tree,
    "v-map": Map
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    treeStyle() {
      if (this.treeParams.width) {
        return "width: " + this.treeParams.width + "px";
      }
      return "";
    },
    searchParams() {
      return Object.assign(
        {},
        this.defaultSearchParams,
        this.params.search || {}
      );
    },
    treeParams() {
      return {
        labels: this.searchParams.labels,
        ...this.params.tree
      };
    }
  },
  data() {
    return {
      tree: null,
      defaultSearchMode: ["settings", "refresh", "menu"],
      defaultSearchParams: {
        labels: [
          {
            group: "other",
            label: "在线统计",
            key: "onoff",
            checked: true
          },
          {
            group: "car",
            label: "驾驶员",
            key: "driver",
            checked: false
          },
          {
            group: "car",
            label: "车辆状态",
            key: "status",
            checked: false
          }
        ],
        filters: [
          {
            label: "车辆搜索选项",
            key: "car",
            radio: "vehicleNo", // 是否开启radio单选模式, 默认选中车牌号码
            // checked: true,
            children: [
              {
                label: "车牌号码",
                key: "vehicleNo"
              },
              {
                label: "终端编号",
                key: "terminalNo"
                // checked: false
              }
            ]
          },
          {
            label: "分类搜索选项",
            key: "other",
            children: [
              {
                label: "企业名称",
                key: "companyName",
                checked: true,
                disabled: true
              }
            ]
          }
        ]
      }
    };
  },
  methods: {
    labelChange() {
      // 宽度自适应
      if (this.params.tree && this.params.tree.width) {
        this.params.tree.width = 0;
      }
      if (this.tree && this.tree.labelChange) {
        this.tree.labelChange();
      }
    },
    resize() {
      const ref = this.$refs.search;
      if (ref && ref.resize) {
        ref.resize();
      }
    },
    open(type, data) {
      this.$dialog.open("monitor", type, data);
    },
    getMap() {
      if (this.$refs.map) {
        return this.$refs.map.getMap();
      }
      return null;
    }
  },
  mounted() {
    this.tree = this.$refs.tree;
  }
};
</script>

<style lang="scss" scoped>
.monitor-container {
  display: flex;
  height: 100%;
}
.search-tree {
  user-select: none;
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100%;
}
.map-container {
  position: relative;
  .absolute-wrapper {
    overflow: hidden;
    position: absolute;
    width: 100%;
    height: 100%;
  }
}
</style>
