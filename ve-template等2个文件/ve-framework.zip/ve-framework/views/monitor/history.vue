<template>
  <div class="history-container full-height">
    <div class="search-bar">
      <v-search-form
        ref="SearchForm"
        :autoSearch="false"
        :loading="loading"
        :formOptions="formOptions"
        @onSearch="onSearch"
      ></v-search-form>
    </div>
    <div class="map-bar">
      <!-- <v-collapse class="slideMenu" v-if="show">
        <tree :checkbox="false" @node-click="nodeClick" />
      </v-collapse>-->
      <div class="absolute-wrapper map-section auto-fill flex-vertical">
        <v-map ref="map" class="auto-fill" :params="params">
          <bm-polyline
            v-if="positions.length"
            :path="positions"
            stroke-color="#18a45b"
            :stroke-opacity="0.7"
            :stroke-weight="4"
          ></bm-polyline>
          <!-- <bm-distance-tool :offset="{ width: 10, height: 10 }"></bm-distance-tool> -->
          <v-lushu
            v-if="positions.length"
            ref="lushu"
            @stop="pause"
            @tick="tick"
            :autoView="true"
            :rotation="true"
            :speed="speed"
            :path="positions"
            :icon="icon"
            :play="playing"
          ></v-lushu>
          <bm-marker v-if="marker" :position="marker"></bm-marker>
        </v-map>
        <div class="play-bar">
          <div class="item progress">
            <el-slider
              class="v-slider"
              @change="change"
              :disabled="!playing"
              :max="count"
              v-model="progress"
            ></el-slider>
          </div>
          <div class="item">
            <el-select class="v-select" v-model="speed" size="mini">
              <el-option
                :key="key"
                v-for="(item, key) in speedOptions"
                :label="item.name"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <div class="item">
            <el-button
              type="primary"
              size="mini"
              icon="el-icon-video-play"
              :disabled="positions.length === 0"
              v-if="!playing"
              @click="play"
            >播放</el-button>
            <el-button type="danger" size="mini" icon="el-icon-video-pause" v-else @click="pause">暂停</el-button>
          </div>
        </div>
        <component
          v-if="params.table"
          :is="params.table"
          :trackList="positions"
          :params="params2"
          :platform="params.platform || $project || ''"
          :play="playing"
          :index="index"
          @update="updateProgress"
        />
      </div>
    </div>
    <v-dialog scope="history" :dialogMaps="params.dialogMaps" />
  </div>
</template>

<script>
import Map from "../../widget/Map/history";
// import SimpleTree from "ve-framework/components/Tree/simple";
import { BmlLushu } from "../../components/BaiduMap";
import { getPositionHistory } from "../../api/history";
import { getBusList } from "../../api/monitor";
import { fixPosition } from "../../utils/map";
import { getCarIconBase64 } from "../../utils";

export default {
  name: "monitor-history",
  eventBus: ["showMarker"],
  components: {
    "v-map": Map,
    "v-lushu": BmlLushu
    // tree: SimpleTree,
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    query() {
      return this.$route.query;
    },
    qcNo() {
      return this.query.carNo;
    },
    icon() {
      return this.params.icon || this.defaultIcon;
    },
    getPositionHistory() {
      return this.params.fetchPosition || getPositionHistory;
    },
    getBusList() {
      return this.params.fetchCar || getBusList;
    }
  },
  data() {
    const { startTime, endTime } = this.$route.query;
    return {
      marker: null,
      params2: null,
      progress: 0,
      index: 0, //小车走到了第几个
      speed: 200,
      playing: false,
      positions: [],
      // sCarNo: "",
      loading: false,
      selectLoading: false,
      defaultIcon: {
        url: getCarIconBase64(1),
        size: { width: 36, height: 20 }
      },
      count: 0,
      speedOptions: [
        {
          name: "慢速",
          value: 200
        },
        {
          name: "普通",
          value: 500
        },
        {
          name: "快速",
          value: 1000
        }
        // {
        //   name: "急速",
        //   value: 8000
        // }
      ],
      busOptions: [],
      formOptions: {
        inline: true,
        submitBtnText: "查询",
        width: 80,
        size: "small",
        forms: [
          {
            prop: "carNo",
            label: "",
            placeholder: "请输入车牌号",
            remote: true,
            clearable: true,
            itemType: "select",
            labelKey: "name",
            valueKey: "id",
            filterable: true,
            remoteMethod: this.remoteMethod,
            clear: this.handleClear,
            options: () => this.busOptions,
            default: () => this.qcNo
          },
          {
            prop: ["startTime", "endTime"],
            label: "",
            itemType: "datetimerange2",
            default: () =>
              this.query.startTime && this.query.endTime
                ? [this.query.startTime, this.query.endTime]
                : null
            // rules: [{ required: true, message: "请选择时间范围" }],
            // dayRange: 1
          }
        ]
      }
    };
  },
  methods: {
    showMarker(data) {
      if (data.lat && data.lng) {
        const point = { lat: data.lat, lng: data.lng };
        this.marker = point;
        this.$refs.map.setCenter(point);
      }
    },
    remoteMethod(query) {
      if (query !== "") {
        this.selectLoading = true;
        // 请求 “车牌号搜索” 接口
        let params = {
          key: query
        };
        this.getBusList(params)
          .then(res => {
            this.selectLoading = false;
            if (res && Array.isArray(res)) {
              this.busOptions = res;
            } else {
              this.busOptions = [];
            }
          })
          .catch(() => {
            this.selectLoading = false;
            this.busOptions = [];
          });
      } else {
        this.busOptions = [];
      }
    },
    handleClear() {
      this.busOptions = [];
    },
    formatTime(time) {
      return typeof time === "string" ? time.replace(/[-:\s]/g, "") : "";
    },
    onSearch(params) {
      this.reset();
      this.delay(100).then(() => {
        const { startTime, endTime, carNo } = params;
        if (!carNo) {
          return this.$message.error("请输入车牌号");
        }
        if (startTime && endTime) {
          if (
            new Date(endTime).getTime() - new Date(startTime).getTime() >
            86400000
          ) {
            return this.$message.error("时间范围不超过一天");
          }
          let vehicleNo = carNo;
          let params = {
            vehicleNo,
            startTime: this.formatTime(startTime),
            endTime: this.formatTime(endTime)
          };
          this.loading = true;
          this.params2 = {
            vehicleNo,
            // disposeState: "0",
            beginDate: startTime,
            endDate: endTime
          };

          // console.log(params);
          this.getPositionHistory(params)
            .then(data => {
              if (data && data.length) {
                data = data.filter(
                  v => Math.trunc(v.lat) !== 0 && Math.trunc(v.lng) !== 0
                );
                this.count = data.length - 1;
                this.positions = data.map(v => fixPosition(v));
              } else {
                this.positions = [];
                this.$message.warning("没有找到历史轨迹");
              }
              this.loading = false;
            })
            .catch(() => {
              this.loading = false;
            });
          // console.log(timescope);
        } else {
          this.$message.error("请输入完整的时间范围");
        }
      });
    },
    updateProgress(index) {
      if (!this.playing) {
        return false;
      }
      if (index <= this.index) {
        this.index = index;
        this.progress = index;
        this.$refs.lushu.setProgress(index);
      } else {
        // console.log("exceed", index);
      }
    },
    reset() {
      this.playing = false;
      this.index = 0;
      // this.positions = [];
      this.progress = 0;
      this.marker = null;
    },
    tick(index) {
      this.index = index;
      this.progress = index;
    },
    play() {
      !this.playing &&
        this.delay(500).then(() => {
          this.playing = true;
        });
    },
    pause() {
      this.playing &&
        this.delay(500).then(() => {
          this.playing = false;
        });
    },
    change(v) {
      if (v === this.positions.length - 1) {
        this.progress = this.index;
        return false;
      }
      this.$refs.lushu.setProgress(v);
    }
  },
  deactivated() {
    this.playing = false;
  }
};
</script>

<style lang="scss">
.history-container {
  display: flex;
  flex-direction: column;
  .map-bar {
    flex: 1;
    display: flex;
    position: relative;
    .absolute-wrapper {
      overflow: hidden;
      position: absolute;
      width: 100%;
      height: 100%;
    }
    .slideMenu {
      .content-container {
        .search-form {
          margin: 10px;
        }
      }
    }
    .map-section {
      .play-bar {
        display: flex;
        height: 50px;
        margin-left: 15px;
        margin-right: 15px;
        align-items: center;
        .item {
          margin-left: 15px;
          &:first-child {
            margin-left: 0;
          }
          &.progress {
            flex: 1;
          }
        }
      }
    }
  }
  .search-bar {
    border-bottom: 1px solid #ddd;
    height: 50px;
    padding-left: 10px;
    .v-search-form {
      margin-top: 6px;
    }
  }
}
</style>
