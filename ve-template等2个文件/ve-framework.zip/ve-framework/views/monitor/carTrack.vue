<template>
  <div class="group-container full-height">
    <grid @fullscreenchange="fullscreenchange">
      <template v-slot="{ index }">
        <div class="map-container flex-vertical" :ref="'map' + index" v-if="maps[index]">
          <div class="title-header">
            <div class="title">{{ maps[index].vehicleNo }}</div>
            <div class="btnbars">
              <div class="btn" @click="fullscreen(index)">
                <i class="el-icon-full-screen" v-if="!maps[index].fullscreen"></i>
                <i class="iconfont" v-else>&#xe64a;</i>
              </div>
              <div class="btn close" @click="close(index)">
                <i class="el-icon-close"></i>
              </div>
            </div>
          </div>
          <v-map class="auto-fill" :items="[maps[index]]" :list="list" :params="params"></v-map>
        </div>
        <div v-else class="plus" @click="click(index)">
          <i class="iconfont">&#xe633;</i>
        </div>
      </template>
    </grid>
    <v-dialog scope="group" :dialogMaps="dialogMaps"></v-dialog>
  </div>
</template>

<script>
import screenfull from "screenfull";
import Grid from "../../components/Grid";
import Map from "../../widget/Map/carTrack";
import carTree from "../../dialog/monitor/carTree";
// 兼容screenfull 4.x
const enabled = screenfull.isEnabled || screenfull.enabled;
export default {
  components: {
    Grid,
    "v-map": Map
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      list: [],
      maps: {},
      dialogMaps: {
        carTree: {
          title: "选择车辆",
          component: carTree,
          width: "400px",
          methods: this.renderMap
        }
      }
    };
  },
  methods: {
    click(index) {
      this.$dialog.open("group", "carTree", {
        index,
        cars: this.list
      });
    },
    close(index) {
      if (this.maps[index].fullscreen) {
        this.fullscreen(index);
      }
      const { vehicleNo } = this.maps[index];
      if (vehicleNo) {
        this.list.remove(vehicleNo);
      }
      this.$delete(this.maps, index);
    },
    renderMap(id, data) {
      // console.log(id, data);
      if (Array.isArray(data)) {
        data = data[0];
      }
      this.$set(this.maps, id, data);
    },
    fullscreen(index) {
      let $ref = this.$refs["map" + index];
      let $el = $ref;
      if ($ref && $ref.length) {
        $el = $ref[0];
      }
      if ($el && enabled) {
        const fullscreen = this.maps[index].fullscreen;
        this.$set(this.maps[index], "fullscreen", !fullscreen);
        screenfull.toggle($el);
      }
    },
    fullscreenchange() {
      Object.keys(this.maps).forEach(k => {
        if (this.maps[k].fullscreen) {
          this.$set(this.maps[k], "fullscreen", false);
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.group-container {
  user-select: none;
  padding: 6px;
  padding-top: 3px;
}
</style>
