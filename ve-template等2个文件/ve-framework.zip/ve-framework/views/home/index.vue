<template>
  <div>
    <slot></slot>
  </div>
</template>

<script>
import { getToken } from "../../utils/auth";
export default {
  methods: {
    toPage(data) {
      let { id, name, type, path } = data;
      if (id && name) {
        this.$store.commit("SET_SYSTEM_INFO", { id, name });
      }
      // 如果是外链
      if (type === 2) {
        if (path) {
          const token = getToken();
          if (id && name && token) {
            const auth = encodeURIComponent(
              JSON.stringify({
                id,
                name,
                token
              })
            );
            // 是否新开标签页
            const isNewOpen = path.indexOf("@") === 0;
            if (isNewOpen) {
              path = path.substring(1);
            }
            // 是否相对路径
            if (path.indexOf("/") === 0) {
              path = location.origin + path;
            }
            const production = process.env.NODE_ENV === "production";
            let url = (production ? path : location.origin) + "?auth=" + auth;
            if (!production) {
              console.log(url);
              return this.$message.warning($t('_tm.this.messages.tip_0'));
            }
            if (url.indexOf("http") === 0) {
              // 跳转新窗口
              if (isNewOpen) {
                window.open(url);
              } else {
                location.href = url;
              }
            } else {
              this.$message.warning($t('_tm.this.messages.tip_1'));
            }
          }
        } else {
          this.$message.warning($t('_tm.this.messages.tip_2'));
        }
      } else {
        localStorage.setItem("systemId", id);
        this.$router.push({
          path: "/"
        });
      }
    }
  }
};
</script>
