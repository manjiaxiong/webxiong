<template>
  <i :class="className" :style="iconStyle" v-html="text" @click="clickHandle"></i>
</template>

<script>
export default {
  name: "icon",
  props: {
    content: {
      type: String,
      default: ""
    },
    size: {
      type: Number,
      default: 18
    },
    color: {
      type: String,
      default: "#fff"
    }
  },
  data() {
    return {
      text: ""
    };
  },
  computed: {
    className() {
      if (this.content.indexOf("fa-") > -1) {
        return this.content.indexOf("fa ") === 0
          ? this.content
          : ["fa", this.content];
      } else if (this.content.indexOf("el-icon-") > -1) {
        return this.content;
      } else if (this.content.indexOf("#") > -1) {
        this.text = this.content;
        return "iconfont";
      } else {
        this.text = this.content;
        return "";
      }
    },
    iconStyle() {
      return (
        "font-size: " +
        this.size +
        "px; color: " +
        this.color +
        "; font-style: normal;"
      );
    }
  },
  methods: {
    clickHandle() {
      this.$emit("click");
    }
  }
};
</script>
