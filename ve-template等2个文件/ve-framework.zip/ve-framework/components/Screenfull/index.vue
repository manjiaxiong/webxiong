<template>
  <i class="el-icon-full-screen" @click="click"></i>
</template>

<script>
import screenfull from "screenfull";
const enabled = screenfull.isEnabled;
export default {
  name: "Screenfull",
  data() {
    return {
      isFullscreen: false
    };
  },
  methods: {
    click() {
      if (!enabled) {
        this.$message({
          message: "you browser can not work",
          type: "warning"
        });
        return false;
      }
      screenfull.toggle();
    },
    change() {
      this.isFullscreen = screenfull.isFullscreen;
    }
  },
  mounted() {
    if (enabled) {
      screenfull.on("change", this.change);
    }
  },
  destroyed() {
    if (enabled) {
      screenfull.off("change", this.change);
    }
  }
};
</script>
