<template>
  <div class="el-select" v-popover:popover>
    <el-input class="v-select-input" v-model="data" :placeholder="placeholder" readonly clearable>
      <template slot="suffix">
        <i :class="['el-select__caret', 'el-input__icon', 'el-icon-' + iconClass]"></i>
      </template>
    </el-input>

    <el-popover
      ref="popover"
      v-model="visible"
      popper-class="select-popover"
      placement="bottom-start"
      width="380"
      trigger="click"
      :visible-arrow="true"
      @show="show"
      @hide="hide"
    >
      <slot></slot>
    </el-popover>
  </div>
</template>

<script>

export default {
  props: {
    value: {
      type: String,
      default: ""
    },
    placeholder: {
      type: String,
      default: "请选择"
    }
  },
  data() {
    return {
      data: "",
      visible: false
    };
  },
  watch: {
    value(v) {
      this.data = v;
    }
  },
  computed: {
    iconClass() {
      return this.visible ? "arrow-up is-reverse" : "arrow-up";
    }
  },
  methods: {
    show() {
      this.visible = true;
    },
    hide() {
      this.visible = false;
    }
  }
};
</script>

<style lang="scss">
.v-select-input {
  .el-input__inner {
    cursor: pointer;
  }
}
.select-popover {
  height: 320px;
  overflow: auto;
}
</style>
