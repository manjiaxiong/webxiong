import vcharts from "v-charts";
import "v-charts/lib/style.min.css";
export default vcharts;
