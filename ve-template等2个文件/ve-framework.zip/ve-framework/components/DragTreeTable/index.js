import DragTreeTable from './dragTreeTable.vue'
DragTreeTable.install = Vue => Vue.component(DragTreeTable.name, DragTreeTable);

export default DragTreeTable