<template>
  <el-dialog
    class="v-dialog"
    :custom-class="className"
    :title="title"
    :visible.sync="visible"
    :width="width2 || width"
    :close-on-click-modal="mclose"
    :append-to-body="appendToBody"
    :fullscreen="isFullscreen"
    @closed="closed"
    @close="onClose"
    @opened="opened"
    @open="dopen"
  >
    <template v-if="titleComponent" #title>
      <div ref="title" :is="titleComponent"></div>
    </template>

    <div
      v-if="component"
      ref="dialog"
      :is="component"
      :params="params"
      @close="close"
      @title="setTitle"
      @width="setWidth"
    ></div>
    <template v-else-if="slotName">
      <slot :name="slotName" :dialog="dialogParams"></slot>
    </template>

    <template v-if="footer && footer.buttons && footer.buttons.length" #footer>
      <template v-for="(item, key) in footer.buttons">
        <el-button
          :key="key"
          :loading="!!item.loading"
          :type="item.type || footer.type || 'primary'"
          :size="item.size || footer.size || 'medium'"
          @click="item.click ? item.click(dialogParams, item) : () => null"
          >{{ item.name }}</el-button
        >
      </template>
    </template>
  </el-dialog>
</template>

<script>
export default {
  name: "v-dialog",
  props: {
    dialogMaps: {
      type: Object,
      default: () => ({})
    },
    scope: {
      type: String,
      default: ""
    },
    width: {
      type: String,
      width: "50%"
    },
    modalClose: {
      type: Boolean,
      default: true
    },
    appendToBody: {
      type: Boolean,
      default: false
    },
    fullscreen: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isfullscreen: false,
      footer: null,
      component: null,
      titleComponent: null,
      slotName: null,
      copen: null,
      copened: null,
      cclosed: null,
      params: null,
      visible: false,
      modalClose2: null,
      title: "",
      width2: "",
      scopeCache: "",
      className: ""
    };
  },
  computed: {
    scope2() {
      return this.scope || this.$route.name || this.$route.path;
    },
    eventOpen() {
      return this.scope2 + "DialogOpen";
    },
    mclose() {
      return this.modalClose2 !== null ? this.modalClose2 : this.modalClose;
    },
    isFullscreen() {
      return this.isfullscreen || this.fullscreen;
    },
    dialogParams() {
      return {
        close: this.close,
        params: this.params,
        setTitle: this.setTitle
      };
    }
  },
  methods: {
    open(type, params) {
      const dialog = this.dialogMaps[type];
      if (dialog) {
        const {
          title,
          component,
          titleComponent,
          slotName,
          footer,
          closed,
          opened,
          open,
          width,
          modalClose,
          grid,
          fullscreen,
          methods,
          className
        } = dialog;
        if (className) {
          this.className = className;
        }
        if (title) {
          if (typeof title === "string") {
            this.title = title;
          } else if (typeof title === "function") {
            const titleResult = title(params);
            if (typeof titleResult === "string") {
              this.title = titleResult;
            }
          }
        }
        if (component) {
          this.component = component;
          this.slotName = null;
        }
        this.titleComponent = titleComponent;
        if (slotName) {
          this.component = null;
          this.slotName = slotName;
          if (closed) {
            this.cclosed = closed;
          }
          if (opened) {
            this.copened = opened;
          }
          if (open) {
            this.copen = open;
          }
        }
        if (footer) {
          this.footer = footer;
        }
        if (width) {
          this.width2 = width;
        }
        this.isfullscreen = fullscreen || false;
        this.modalClose2 =
          typeof modalClose !== "undefined" ? modalClose : null;
        if (params) {
          if (grid > 1) {
            params.grid = grid;
          }
          if (typeof methods === "function") {
            params.methods = methods;
          }
          this.params = params;
          if (params.width) {
            this.width2 = params.width;
          }
          if (params.title) {
            this.title = params.title;
          }

          if (typeof params.modalClose !== "undefined") {
            this.modalClose2 = params.modalClose;
          }

          if (params.vehicleNo && typeof title === "string") {
            this.title = this.title + " [" + params.vehicleNo + "]";
          }
        } else {
          this.params = null;
        }
        this.visible = true;
      } else {
        console.error("未找到弹窗类型", type);
      }
    },
    opened() {
      const dialog = this.$refs.dialog;
      if (dialog && typeof dialog.opened === "function") {
        dialog.opened();
      } else if (typeof this.copened === "function") {
        this.copened(this.dialogParams);
      }
    },
    dopen() {
      this.$nextTick(() => {
        const dialog = this.$refs.dialog;
        if (dialog && typeof dialog.open === "function") {
          dialog.open();
        } else if (typeof this.copen === "function") {
          this.copen(this.dialogParams);
        }
      });
    },
    closed() {
      this.width2 = "";
      this.footer = null;
      const dialog = this.$refs.dialog;
      if (dialog && typeof dialog.closed === "function") {
        dialog.closed();
      } else if (typeof this.cclosed === "function") {
        this.cclosed();
      }
    },
    onClose() {
      const dialog = this.$refs.dialog;
      if (dialog && typeof dialog.close === "function") {
        dialog.close();
      }
    },
    close() {
      this.visible = false;
    },
    setTitle(title) {
      if (title) {
        this.title = title;
      }
    },
    setWidth(width) {
      if (width) {
        this.width2 = typeof width === "string" ? width : width + "px";
      }
    }
  },
  created() {
    this.scopeCache = this.eventOpen;
    this.$bus.$on(this.eventOpen, this.open);
  },
  deactivated() {
    this.close();
  },
  destroyed() {
    this.close();
    this.scopeCache && this.$bus.$off(this.scopeCache);
  }
};
</script>

<style lang="scss" scoped>
.el-dialog__footer {
  .el-button:first-child {
    margin-right: 5px;
  }
}
</style>
