<template>
  <div class="car-tree-wrapper" v-loading="isLoading">
    <el-tree
      empty-text
      ref="tree"
      :class="['car-tree', toolbar ? 'complex' : '']"
      :data="data"
      :show-checkbox="getParams('checkbox', true)"
      :node-key="getParams('nodeKey', 'id', 'string')"
      :default-expand-all="getParams('expandAll', false)"
      highlight-current
      :accordion="getParams('accordion', false)"
      @check="check"
      @node-click="nodeClick"
      :filter-node-method="filterNode"
      :props="defaultProps"
      @contextmenu.prevent.native="() => false"
    >
      <template v-slot="{ node, data }">
        <span class="custom-tree-node">
          <img
            v-if="isLast(data) && toolbar && params.icon !== false"
            :src="getTreeIcon(data[defaultKey])"
            alt
          />
          <span class="label">{{ node.label }}</span>
          <el-dropdown
            v-if="
              isLast(data) &&
                toolbar &&
                params.dropdown &&
                params.dropdown.options &&
                params.dropdown.options.length
            "
            class="plus"
            trigger="click"
            placement="bottom-start"
            @command="cmd => handleCommand(cmd, data)"
          >
            <span class="el-dropdown-link">
              <i class="el-icon-circle-plus-outline"></i>
            </span>
            <el-dropdown-menu class="tree-dropdown set-height" slot="dropdown">
              <el-dropdown-item
                :key="key"
                v-for="(item, key) in params.dropdown.options"
                :command="item.command"
              >{{ item.name }}</el-dropdown-item>
              <!-- <el-dropdown-item command="video">实时视频</el-dropdown-item> -->
              <!-- <el-dropdown-item command="warning">故障信息</el-dropdown-item> -->
              <!-- <el-dropdown-item command="track">车辆跟踪</el-dropdown-item> -->
              <!-- <el-dropdown-item command="capture">照片抓拍</el-dropdown-item>
              <el-dropdown-item command="yybb">消息下发</el-dropdown-item>-->
              <!-- <el-dropdown-item command="search">照片查询</el-dropdown-item> -->
              <!-- <el-dropdown-item command="params">参数查询</el-dropdown-item>
              <el-dropdown-item command="call">电话回拨</el-dropdown-item>
              <el-dropdown-item command="contacts">设置电话本</el-dropdown-item>-->
              <!-- <el-dropdown-item>故障查询</el-dropdown-item> -->
            </el-dropdown-menu>
          </el-dropdown>
        </span>
      </template>
    </el-tree>
  </div>
</template>

<script>
import { getCarTreeList } from "../../api/monitor";
import { getCarIconBase64, getCarStatus } from "../../utils";
import _ from "lodash/array";

const typeDefaultMap = {
  string: "-",
  number: 0
};
const getTypeValue = type => {
  return typeof typeDefaultMap[type] !== "undefined"
    ? typeDefaultMap[type]
    : "";
};
export default {
  // 全局事件注册
  eventBus: ["setCheckedKey", "updateCarData"],
  props: {
    toolbar: {
      type: Boolean,
      default: true
    },
    info: {
      type: Boolean,
      default: true
    },
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    showLabels() {
      return this.params.labels || [];
    },
    getTreeIcon() {
      return typeof this.params.icon === "function"
        ? this.params.icon
        : this.getCarIcon;
    }
  },
  data() {
    return {
      isLoading: true,
      carTreeData: [],
      checkedNodes: [],
      data: null,
      defaultProps: {
        children: "children",
        label: "label"
      },
      caseSensitive: false,
      defaultKey: "properties",
      selectedFilter: {},
      labels: {
        onoff: [
          {
            key: "online",
            name: "在",
            type: "number"
          },
          {
            key: "offline",
            name: "离",
            type: "number"
          },
          {
            key: "total",
            name: "总",
            type: "number"
          }
        ],
        driver: [
          {
            key: "driverName",
            name: "驾驶员",
            type: "string"
          }
        ],
        status: [
          {
            key: "status",
            name(v) {
              return getCarStatus(v);
            }
          }
        ]
      }
    };
  },
  watch: {
    carTreeData(v, ov) {
      if (ov.length === 0) {
        this.render(Object.clone(v));
        if (this.params.checkAll) {
          this.delay(200).then(() => {
            v.forEach(item => {
              const node = this.getNode(item.id);
              if (node) {
                this.setCheckedKey(node.key, true, true);
                this.$nextTick(() => {
                  this.check(node.data);
                });
              }
            });
          });
        }
      } else {
        this.updateDiff(v, ov);
      }
    }
  },
  methods: {
    isLast({ lastStage, last }) {
      return lastStage || last;
    },
    getParams(key, defaultValue, type = "boolean") {
      return typeof this.params[key] === type ? this.params[key] : defaultValue;
    },
    loading(flag = true) {
      this.isLoading = flag;
    },
    refresh() {
      return getCarTreeList().then(data => {
        this.carTreeData = data;
        this.loading(false);
      });
    },
    // 默认获取树形菜单图标
    getCarIcon({ status }) {
      return getCarIconBase64(status, "small");
    },
    updateDiff(v, ov) {
      const result = this.getDiff(ov, this.getMapList(v));
      if (result.length) {
        result.forEach(v => {
          // 兼容新版本微服务 字段
          if (this.isLast(v)) {
            if (typeof v.properties.driverName === "undefined") {
              v.properties.driverName = "";
            }
            this.updateCarData(v.id, v.properties);
          } else {
            this.updateParentData(v.id, { ...v.properties, name: v.name });
          }
        });
      }
      // console.timeEnd();
    },
    formatLabel(v) {
      return (
        v.name +
        this.formatName(v[this.defaultKey], this.isLast(v) ? "car" : "other")
      );
    },
    map(list, name) {
      list.forEach(v => {
        v.label = this.formatLabel(v);
        if (name) {
          v.filter = v.name + "#" + name;
        } else {
          v.filter = v.name;
        }
        if (v.children && v.children.length) {
          this.map(v.children, v.filter);
        }
      });
    },
    getDiff(list, list2) {
      let result = [];
      list.forEachTree(
        v => {
          if (list2[v.id]) {
            const { children, pid, level, ...rest } = v;
            if (JSON.stringify(rest) !== JSON.stringify(list2[v.id])) {
              result.push(list2[v.id]);
            }
          }
        },
        { parent: true }
      );
      return result;
    },
    getMapList(list) {
      let result = {};
      list.forEachTree(
        v => {
          const { children, pid, level, ...rest } = v;
          if (v.id) {
            result[v.id] = rest;
          }
        },
        { parent: true }
      );
      return result;
    },
    render(data) {
      this.map(data);
      // console.log(data);
      this.data = data;
    },
    labelChange() {
      this.render(this.data);
    },
    handleCommand(command, data) {
      const { dropdown } = this.params;
      if (dropdown && typeof dropdown.confirm === "function") {
        dropdown.confirm(command, data);
      }
    },
    formatName(info, group) {
      let texts = [];
      let text = "";
      this.info &&
        this.showLabels.forEach(v => {
          if (v.group === group) {
            if (v.checked) {
              if (typeof v.formatter === "function") {
                text = v.formatter(info);
              } else if (v.key && this.labels[v.key]) {
                this.labels[v.key].forEach(v => {
                  if (typeof v.name === "function") {
                    texts.push(v.name(info[v.key]));
                  } else {
                    texts.push(
                      v.name + ":" + (info[v.key] || getTypeValue(v.type))
                    );
                  }
                });
              }
            }
          }
        });
      if (texts.length) {
        return " [" + texts.join(" ") + "]";
      } else if (text) {
        return " " + text;
      }
      return "";
    },
    filter(v) {
      this.$refs.tree.filter(v);
    },
    getCheckedKeys(b) {
      return this.$refs.tree.getCheckedKeys(b || false);
    },
    getCheckedNodes(a = false, b = false) {
      return this.$refs.tree.getCheckedNodes(a, b);
    },
    getNode(data) {
      return this.$refs.tree.getNode(data);
    },
    setCheckedKeys(a, b) {
      this.$refs.tree.setCheckedKeys(a, b);
    },
    setCurrentKey(a) {
      this.$refs.tree.setCurrentKey(a);
    },
    getCurrentKey() {
      return this.$refs.tree.getCurrentKey();
    },
    getAllNodeData() {
      if (this.$refs.tree) {
        return this.$refs.tree.store._getAllNodes();
      }
      return null;
    },
    getTreeData() {
      return this.data;
    },
    setFilter(data) {
      this.selectedFilter = data;
    },
    filterNode(value, data) {
      if (!value) return true;
      if (!this.caseSensitive) {
        value = value.toLowerCase();
        data.filter = data.filter.toLowerCase();
      }
      const { group, fields } = this.selectedFilter;
      if (group === "car") {
        return (
          data[this.defaultKey] &&
          fields.some(v => {
            let name =
              v === "vehicleNo" ? data.name : data[this.defaultKey][v] || "";
            if (!this.caseSensitive) {
              name = name.toLowerCase();
            }
            return name.indexOf(value) !== -1;
          })
        );
      }
      return data.filter && data.filter.indexOf(value) !== -1;
    },
    nodeClick(data, node) {
      if (!this.toolbar) {
        return false;
      }
      if (this.isLast(data) && data[this.defaultKey]) {
        if (node.checked) {
          this.$bus.$emit("onCarClick", data);
        } else {
          this.setCheckedKey(data, true);
          this.$nextTick(() => {
            this.check(data);
          });
        }
      }
    },
    check(data, status) {
      const { select } = this.$listeners;
      if (select) {
        select(data, status);
        return false;
      }
      const checkedNodes = this.getCheckedKeys(true);
      const cacheNodes = this.checkedNodes;
      const node = this.getNode(data.id);
      const isCar = this.isLast(data);
      const checked = node.checked;
      const diff =
        cacheNodes.length > checkedNodes.length
          ? _.difference(cacheNodes, checkedNodes)
          : _.difference(checkedNodes, cacheNodes);
      // console.log(diff.length, node.checked, isCar);
      if (node) {
        this.$bus.$emit("CarChecked", {
          isCar,
          checked,
          relationCars: isCar ? [data.id] : diff
        });
      }
      this.checkedNodes = Object.freeze(checkedNodes);
    },
    setCheckedKey(key, checked = true, flag = false) {
      this.$refs.tree.setChecked(key, checked, flag);
    },
    getNodeData(key) {
      if (key) {
        const node = this.$refs.tree.getNode(key);
        if (node) {
          let { data } = node;
          if (data && data.properties) {
            return { data, node };
          }
        }
      }
      return {};
    },
    scrollIntoView(id) {
      const $el = this.$refs.tree.$el;
      if ($el) {
        const $nodes = $el.querySelectorAll(".el-tree-node");
        if ($nodes) {
          const len = $nodes.length;
          if (len > 0 && id > 0) {
            let $item = null;
            for (let i = 0; i < len; i++) {
              if (
                $nodes[i].__vue__ &&
                $nodes[i].__vue__.$options.propsData &&
                $nodes[i].__vue__.$options.propsData.node.id === id
              ) {
                if ($nodes[i].__vue__.$el) {
                  $item = $nodes[i].__vue__.$el;
                }
                break;
              }
            }
            if ($item) {
              this.delay(100).then(() => {
                $item.scrollIntoView({
                  // behavior: "smooth"
                });
                this.loading(false);
              });
            }
          }
        }
      }
    },
    updateParentData(key, item = {}) {
      let { data } = this.getNodeData(key);
      if (data) {
        const { online, offline, total, name } = item;
        if (typeof name !== "undefined" && data.name !== name) {
          data.name = name;
          // console.log("更新父节点名称", name);
        }
        if (
          typeof online !== "undefined" &&
          data.properties.online !== online
        ) {
          data.properties.online = online;
          // console.log("更新" + data.name + "在线数量", online);
        }
        if (
          typeof offline !== "undefined" &&
          data.properties.offline !== offline
        ) {
          data.properties.offline = offline;
          // console.log("更新" + data.name + "离线数量", offline);
        }
        if (typeof total !== "undefined" && data.properties.total !== total) {
          data.properties.total = total;
          // console.log("更新" + data.name + "总数量", total);
        }
        data.label = this.formatLabel(data);
      }
    },
    updateCarData(key, item = {}) {
      let { data, node } = this.getNodeData(key);
      if (data) {
        const { status, driverName } = item;
        if (
          typeof status !== "undefined" &&
          data.properties.status !== status
        ) {
          data.properties.status = status;
          // console.log("status 修改", key, status);
          const parent = node.parent.data;
          if (parent) {
            const { properties } = parent;
            if (properties) {
              const { online, offline, total } = properties;
              if (status === 0) {
                if (online > 0) {
                  parent.properties.online = online - 1;
                  parent.properties.offline = total - online + 1;
                  parent.label = this.formatLabel(parent);
                }
              } else if (data.properties.status === 0) {
                if (offline > 0) {
                  parent.properties.offline = offline - 1;
                  parent.properties.online = total - offline + 1;
                  parent.label = this.formatLabel(parent);
                }
              }
            }
          }
        }
        if (
          typeof driverName !== "undefined" &&
          data.properties.driverName !== driverName
        ) {
          data.properties.driverName = driverName;
          // console.log("driverName 修改", key, driverName);
        }
        data.label = this.formatLabel(data);
      }
    }
  },
  created() {
    this.refresh();
  }
};
</script>

<style lang="scss">
.tree-dropdown {
  border-color: #ddd;

  &.region {
    padding: 1px 0;

    .popper__arrow {
      border-bottom-color: #d6d6d6;
    }
  }

  &.set-height {
    padding: 2px 0;
    overflow: auto;
  }

  .el-dropdown-menu__item {
    border-top: 1px solid #ddd;
    &:first-child {
      border-top: none;
    }
  }
}
.car-tree-wrapper {
  flex: 1;
  user-select: none;
  position: relative;
  overflow: hidden;
}
.car-tree {
  height: 100%;
  overflow: auto;
  padding-right: 6px;
  .el-checkbox {
    margin-right: 6px;
  }
  .custom-tree-node {
    display: flex;
    align-items: center;
    > img {
      padding-right: 4px;
    }
    .label {
      font-size: 14px;
    }

    .plus {
      visibility: hidden;
      position: relative;
      left: 8px;
      top: 1px;

      &:hover {
        color: #888;
      }
    }
  }
  &.complex {
    .el-tree-node {
      .el-tree-node__content {
        // 隐藏公司全选
        // .el-checkbox {
        //   display: none;
        // }
        .is-leaf + .el-checkbox {
          display: block;
        }
        &:hover {
          .plus {
            visibility: visible;
          }
        }
      }
    }
  }
}
</style>
