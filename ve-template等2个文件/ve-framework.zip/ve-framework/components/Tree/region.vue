<template>
  <el-tree
    ref="tree"
    class="region-tree no-select"
    :data="data"
    :show-checkbox="false"
    node-key="id"
    :default-expand-all="true"
    highlight-current
    @node-click="nodeClick"
    :filter-node-method="filterNode"
    :props="defaultProps"
    @contextmenu.prevent.native="() => false"
  >
    <template #default="{ node, data }">
      <div class="custom-tree-node">
        <span>
          <i
            class="iconfont icon"
            v-if="options.icon && data.regionType"
            v-html="getIcon(data.regionType)"
          ></i>
          <span class="label">{{ node.label }}</span>
        </span>

        <span class="toolbar" v-if="toolbar">
          <span
            v-if="!data.children"
            class="delete-region"
            @click.stop="remove(data)"
          >
            <i class="el-icon-delete"></i>
          </span>
          <el-dropdown
            v-if="options.dropdown && !data.regionType"
            class="plus"
            trigger="click"
            placement="bottom-end"
            @command="
              command => {
                handleCommand(command, data);
              }
            "
            @click.native.stop="() => null"
          >
            <span class="el-dropdown-link">
              <i class="el-icon-circle-plus-outline"></i>
            </span>
            <el-dropdown-menu
              class="tree-dropdown region no-select"
              slot="dropdown"
            >
              <el-dropdown-item command="rename">重命名</el-dropdown-item>
              <el-dropdown-item command="0">新增子分类</el-dropdown-item>
              <el-dropdown-item command="1" :disabled="addRegionDisabled"
                >新增子区域</el-dropdown-item
              >
            </el-dropdown-menu>
          </el-dropdown>
        </span>
      </div>
    </template>
  </el-tree>
</template>

<script>
import { deleteRegion, getRegion, getRegionTreeList } from "../../api/fence";
import { formatPoints } from "../../utils/map";
import { filterNode } from "../../utils/filter";
export default {
  eventBus: [{ getRegionTreeData: "refresh" }],
  props: {
    toolbar: {
      type: Boolean,
      default: true
    },
    exclude: {
      type: Array,
      default: () => []
    },
    addRegionDisabled: {
      type: Boolean,
      default: false
    },
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    options() {
      return Object.merge(
        {
          dropdown: true,
          icon: true,
          scope: "region",
          methods: {
            remove: deleteRegion,
            getDetail: getRegion,
            getAll: getRegionTreeList
          }
        },
        this.params
      );
    }
  },
  data() {
    return {
      data: null,
      currentKey: null,
      defaultProps: {
        children: "children",
        label: "regionName"
      },
      icons: {
        0: "&#xe896;",
        1: "&#xe60f;",
        2: "&#xe790;",
        3: "&#xe6f8;"
      },
      caseSensitive: false,
      regionList: []
    };
  },
  watch: {
    regionList(v) {
      const data = Object.clone(v);
      this.render(data);
    },
    addRegionDisabled(v) {
      if (!v) {
        this.currentKey = null;
      }
    }
  },
  methods: {
    getIcon(type) {
      return this.icons[type];
    },
    map(list, name) {
      const key = this.defaultProps["label"];
      list.forEach(v => {
        if (name) {
          v.filter = v[key] + "#" + name;
        } else {
          v.filter = v[key];
        }
        if (v.children && v.children.length) {
          this.map(v.children, v.filter);
        }
      });
    },
    handleCommand(command, data) {
      if (command == 0) {
        this.$dialog.open(this.options.scope, "category", {
          title: "新增子分类",
          pid: data.id
        });
      } else if (command == 1) {
        this.$bus.$emit("drawRegion", data.id);
      } else if (command === "rename") {
        this.$dialog.open(this.options.scope, "category", {
          title: "编辑分类",
          id: data.id,
          regionName: data.regionName
        });
      }
    },
    remove(data) {
      const id = data.id;
      if (id > 0) {
        this.$confirm("此操作将永久删除该数据, 是否继续?", "提示", {
          type: "warning"
        })
          .then(() => {
            this.$bus.$emit("stopEditRegion");
            this.options.methods.remove(id).then(data => {
              if (data) {
                this.refresh();
                this.$message({
                  type: "success",
                  message: "删除成功!"
                });
              } else {
                this.$message.error("区域存在关联，不能删除");
              }
            });
          })
          .catch(() => {});
      }
    },
    filter(v) {
      this.$refs.tree.filter(v);
    },
    render(data) {
      if (data && Array.isArray(data)) {
        this.map(data);
        this.data = data;
      }
    },
    filterNode(value, data) {
      return filterNode(value, data, this.caseSensitive, this.exclude);
    },
    setCurrentKey(key) {
      this.$refs.tree.setCurrentKey(key);
    },
    getCurrentNode() {
      return this.$refs.tree.getCurrentNode();
    },
    getNode(key) {
      return this.$refs.tree.getNode(key);
    },
    refresh(fetch) {
      let { getAll } = this.options.methods;
      if (typeof fetch === "function") {
        getAll = fetch;
      }
      if (Array.isArray(getAll)) {
        this.regionList = getAll;
      } else if (typeof getAll === "function") {
        getAll().then(data => {
          if (data && data.list) {
            this.regionList = data.list;
          } else {
            this.regionList = data;
          }
        });
      }
    },
    nodeClick(data, node) {
      if (!data.children && data.regionType) {
        const { select, nodeSelect } = this.$listeners;
        if (select) {
          this.$emit("select", data);
          return false;
        }
        if (this.currentKey === data.id) {
          return false;
        }
        this.currentKey = data.id;
        this.options.methods.getDetail(data.id).then(result => {
          if (result) {
            if (nodeSelect) {
              this.$emit("nodeSelect", result);
            } else {
              this.$bus.$emit("editRegion", result, data);
            }
          }
        });
      }
    }
  },
  created() {
    this.refresh();
  }
};
</script>

<style lang="scss">
.region-tree {
  flex: 1;
  overflow: auto;
  .custom-tree-node {
    flex: 1;
    padding-right: 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .label {
      font-size: 14px;
    }

    .icon {
      position: relative;
      top: 1px;
      padding-right: 4px;
      font-size: 16px;
      color: #409eff;
    }

    .toolbar {
      display: flex;
    }

    .plus {
      padding-left: 12px;
      color: #606266;
      &:hover {
        color: #303133;
      }
    }

    i {
      font-size: 15px;
    }
  }

  .el-tree-node__content {
    .delete-region {
      // visibility: hidden;
      i {
        color: #f56c6c;
      }
      &:hover {
        i {
          color: darken(#f56c6c, 20%);
        }
      }
    }
    // &:hover {
    //   .delete-region {
    //     visibility: visible;
    //   }
    // }
  }
}
</style>
