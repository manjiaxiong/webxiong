<template>
  <div class="simple-tree flex-vertical">
    <div class="search-form">
      <el-select
        v-if="remote"
        v-model="carNo"
        clearable
        filterable
        remote
        :remote-method="remoteMethod"
        :loading="selectLoading"
        :placeholder="placeholder"
        @clear="handleClear"
        @change="handleBusChange"
      >
        <el-option
          v-for="(item, index) in busOptions"
          :key="index"
          :label="item.name"
          :value="item.id"
        >
          <template v-if="item.tips">
            <span>{{ item.searchName || item.name }}</span>
            <span style="float: right; color: #aaa; font-size: 12px">
              {{
              item.tips
              }}
            </span>
          </template>
        </el-option>
      </el-select>
      <el-input
        v-else
        size="small"
        prefix-icon="el-icon-search"
        clearable
        v-model="carNo"
        :placeholder="placeholder"
        @input="change"
      ></el-input>
    </div>
    <div v-if="checkAll" class="checkAll">
      <el-link :underline="false" type="primary" @click="check(1)">全选</el-link>
      <el-link :underline="false" type="danger" @click="check(0)">全不选</el-link>
    </div>
    <!-- :default-checked-keys="checkedKeys" -->
    <el-tree
      ref="tree"
      class="car-tree auto-fill"
      :data="data"
      :show-checkbox="checkbox"
      node-key="id"
      :default-expand-all="false"
      :filter-node-method="filterNode"
      :default-checked-keys="checkedKeys"
      @node-click="nodeClick"
      @check="handleCheckChange"
      :props="defaultProps"
      @contextmenu.prevent.native="() => false"
    ></el-tree>
  </div>
</template>

<script>
import { filterNode } from "../../utils/filter";
import { getCarTreeList, getBusList } from "../../api/monitor";
export default {
  props: {
    checkedKeys: {
      type: Array,
      default: () => []
    },
    defaultData: {
      type: Array,
      default: () => null
    },
    checkbox: {
      type: Boolean,
      default: true
    },
    exclude: {
      type: Array,
      default: () => []
    },
    type: {
      type: Number,
      default: 1
    },
    onlyOnline: {
      type: Boolean,
      default: false
    },
    localSearch: {
      type: Boolean,
      default: false
    },
    checkAll: {
      type: Boolean,
      default: false
    },
    dataFormatter: {
      type: Function,
      default: null
    },
    placeholder: {
      type: String,
      default: "请输入车牌号"
    }
  },
  data() {
    return {
      remote: true,
      selectLoading: false,
      busOptions: [], // 搜索后选项
      localOptions: [], // 本地搜索总候选词
      data: [],
      carNo: "",
      caseSensitive: false,
      defaultProps: {
        children: "children",
        label: "name"
      }
    };
  },
  watch: {
    exclude(data) {
      this.localOptions = [];
      this.data.forEachTree(v => {
        const node = this.$refs.tree.getNode(v.id);
        if (node) {
          if (v.level === 0 || v.level > 9999) {
            // 修正真实层级
            v.level = node.parent.data.level + 1;
          }
          const include = data.includes(v.level > 3 ? v.id : v.name);
          if (!include && (this.onlyOnline || this.localSearch)) {
            this.localOptions.push(v);
          }
          node.visible = !include;
          // 如果层级超过两级自动判断是否隐藏节点
          if (v.level > 2) {
            let tnode = null;
            for (let i = 0; i < v.level - 2; i++) {
              const cnode = tnode ? tnode.parent : node.parent;
              if (cnode) {
                tnode = cnode;
                if (include) {
                  if (cnode.childNodes.every(v => !v.visible)) {
                    cnode.visible = false;
                  }
                } else {
                  cnode.visible = true;
                }
              }
            }
          }
        }
      });
    },
    checkedKeys(v) {
      this.$refs.tree.setCheckedKeys(v);
    }
  },
  methods: {
    check(type) {
      this.$refs.tree.setCheckedKeys(
        type === 1 ? this.data.map(v => v.id) : []
      );
    },
    remoteMethod(query) {
      if (query !== "") {
        // 本地搜索
        if (this.onlyOnline || this.localSearch) {
          this.busOptions = this.localOptions
            .filter(item => {
              return item.id.toLowerCase().indexOf(query.toLowerCase()) > -1;
            })
            .slice(0, 20)
            .map(v => {
              const node = this.$refs.tree.getNode(v.id);
              if (node) {
                if (v.level === 0) {
                  // 修正真实层级
                  v.level = node.parent.data.level + 1;
                }
                if (v.level > 3 && this.isLast(v)) {
                  v.searchName = v.id;
                }
                const parent =
                  node.parent.level === 1 ? node.parent : node.parent.parent;
                v.tips = parent.data.name;
              }
              return v;
            });
        } else {
          // 请求 “车牌号搜索” 接口
          this.selectLoading = true;
          let params = {
            key: query
            // type: this.type
          };
          getBusList(params).then(res => {
            this.selectLoading = false;
            this.busOptions = res.filter(v => !this.exclude.includes(v.name));
          });
        }
      } else {
        this.busOptions = [];
      }
    },
    handleBusChange(value) {
      const $tree = this.$refs.tree;
      if ($tree) {
        this.clearSearch(); // 修复手动取消，再次搜索不选中的bug
        $tree.setChecked(value, true);
        const { data } = $tree.getNode(value);
        let checkedNodes = $tree.getCheckedNodes();
        if (data) {
          this.$emit("node-click", value, data);
          this.$emit("check", data, { checkedNodes });
        }
      }
    },
    handleClear() {
      this.busOptions = [];
    },
    clearSearch() {
      this.carNo = "";
      this.handleClear();
    },
    isLast({ lastStage, last }) {
      return lastStage || last;
    },
    nodeClick(data) {
      if (this.isLast(data)) {
        this.$emit("node-click", data.id, data);
      }
    },
    handleCheckChange(a, b) {
      this.checkbox && this.$emit("check", a, b);
    },
    getCheckedKeys(b = false) {
      return this.$refs.tree.getCheckedKeys(b);
    },
    getCheckedNodes(a = false, b = false) {
      return this.$refs.tree.getCheckedNodes(a, b);
    },
    setCurrentKey(key, bool = false) {
      this.$refs.tree.setChecked(key, bool);
    },
    filterNode(value, data) {
      return filterNode(value, data, this.caseSensitive, this.exclude);
    },
    change(v) {
      this.$refs.tree.filter(v || this.carNo);
    },
    initData(data) {
      if (this.onlyOnline) {
        data = data.filterTree(v => v.properties && v.properties.online);
      }
      this.data = this.dataFormatter ? this.dataFormatter(data) : data;
      if (this.onlyOnline || this.localSearch) {
        this.data.forEachTree(v => {
          this.localOptions.push(v);
        });
      }
    }
  },
  created() {
    if (this.defaultData) {
      this.initData(this.defaultData);
    } else {
      getCarTreeList().then(data => {
        this.initData(data);
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.simple-tree {
  height: 100%;
  user-select: none;
  .checkAll {
    margin-bottom: 12px;
    margin-left: 10px;
    display: flex;
    justify-content: space-between;
  }
  .search-form {
    margin-bottom: 12px;
  }

  ::v-deep .car-tree {
    overflow-y: auto;

    .el-checkbox {
      margin-right: 6px;
    }
  }

  .el-form-item {
    margin-bottom: 15px;
  }
}
</style>
