<template>
  <search-form
    v-if="formOptions.forms"
    class="v-search-form"
    ref="searchForm"
    :forms="formOptions.forms"
    :size="formOptions.size"
    :fuzzy="formOptions.fuzzy"
    :inline="formOptions.inline"
    :label-width="formOptions.labelWidth"
    :item-width="formOptions.itemWidth"
    :submit-handler="searchHandler"
    :submit-loading="loading"
    :showSearchBtn="formOptions.showSearchBtn"
    :showResetBtn="formOptions.showResetBtn"
    :submitBtnText="formOptions.submitBtnText"
    :resetBtnText="formOptions.resetBtnText"
  >
    <template
      v-for="form in formOptions.forms.filter(it=>it.itemType === 'slot')"
      v-slot:[form.slotName]="{params}"
    >
      <slot :name="form.slotName" :params="params"></slot>
    </template>
    <template #buttons>
      <slot name="buttons"></slot>
    </template>
    <template #buttons-right>
      <slot name="buttons-right"></slot>
    </template>
  </search-form>
</template>

<script>
import SearchForm from "../TmTable/search";
export default {
  name: "v-search-form",
  components: {
    SearchForm
  },
  props: {
    loading: {
      type: Boolean,
      default: false
    },
    autoSearch: {
      type: Boolean,
      default: true
    },
    formOptions: {
      type: Object,
      default: () => ({})
    }
  },
  methods: {
    updateLoading(flag = true) {
      this.$emit("update:loading", flag);
    },
    searchHandler(params) {
      // this.updateLoading(true);
      this.$emit("onSearch", params);
    },
    search() {
      this.$refs.searchForm.searchHandler();
    },
    closePicker() {
      this.$refs.searchForm.closePicker();
    },
    setFormValue(key, value) {
      this.$refs.searchForm.setFormValue(key, value);
    }
  },
  mounted() {
    if (this.autoSearch) {
      this.search();
    }
  }
};
</script>

<style lang="scss" scoped>
.v-search-form {
  user-select: none;
  ::v-deep .el-form-item {
    margin-bottom: 20px;
  }
}
</style>
