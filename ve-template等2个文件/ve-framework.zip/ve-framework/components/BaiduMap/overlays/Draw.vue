<script>
import commonMixin from "../base/mixins/common.js";
export default {
  mixins: [commonMixin("overlay")],
  render() {},
  data() {
    return {
      init: false,
      drawManager: null,
      marker: null,
      markerMenu: null
    };
  },
  methods: {
    load() {
      const { BMap, map } = this;
      if (!this.init) {
        this.init = true;
        const { BMapLib } = require("../lib/draw");
        const styleOptions = {
          strokeColor: "blue", //边线颜色。
          fillColor: "blue", //填充颜色。当参数为空时，圆形将没有填充效果。
          strokeWeight: 2, //边线的宽度，以像素为单位。
          strokeOpacity: 0.4, //边线透明度，取值范围0 - 1。
          fillOpacity: 0.1, //填充的透明度，取值范围0 - 1。
          strokeStyle: "solid" //边线的样式，solid或dashed。
        };
        //实例化鼠标绘制工具
        this.drawManager = new BMapLib.DrawingManager(map, {
          isOpen: false, //是否开启绘制模式
          enableDrawingTool: true, //是否显示工具栏
          drawingMode: "circle",
          drawingToolOptions: {
            anchor: BMAP_ANCHOR_TOP_RIGHT, //位置
            offset: new this.BMap.Size(200, 10), //偏离值
            drawingModes: [
              "circle",
              // "polyline",
              "rectangle",
              "polygon"
            ]
          },
          circleOptions: styleOptions, //圆的样式
          polylineOptions: styleOptions, //线的样式
          polygonOptions: styleOptions, //多边形的样式
          rectangleOptions: styleOptions //矩形的样式
        });
        //添加鼠标绘制工具监听事件，用于获取绘制结果
        this.drawManager.addEventListener("overlaycomplete", this.drawEnd);
        this.$emit("render", this.drawManager);
      }
    },
    drawEnd(e, data) {
      this.$emit("drawEnd", e, data);
    },
    addContextMenu(list, overlay) {
      if (!(list.length && overlay)) {
        return false;
      }
      const BMap = this.BMap;
      const markerMenu = new BMap.ContextMenu();
      this.marker = overlay;
      list.forEach(v => {
        v.name &&
          v.callback &&
          markerMenu.addItem(new BMap.MenuItem(v.name, v.callback));
      });
      overlay.addContextMenu(markerMenu);
      this.markerMenu = markerMenu;
      return markerMenu;
    },
    removeContextMenu() {
      if (this.marker && this.markerMenu) {
        this.marker.removeContextMenu(this.markerMenu);
        this.marker = null;
        this.markerMenu = null;
      }
    }
  },
  destroyed() {
    this.drawManager = null;
  }
};
</script>

<style lang="scss">
.BMap_contextMenu {
  > div {
    padding: 8px 10px !important;
    border-top: 1px solid #ddd;

    &:first-child {
      border-top: none;
    }
  }
}

.BMapLib_Drawing_panel {
  height: 47px;
  border: 1px solid #666;
  border-radius: 5px;
  overflow: hidden;
  box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
  float: left;
}

.BMapLib_Drawing .BMapLib_box {
  border-right: 1px solid #d2d2d2;
  float: left;
  height: 100%;
  width: 64px;
  height: 100%;
  background-image: url(http://api.map.baidu.com/library/DrawingManager/1.4/src/bg_drawing_tool.png);
  cursor: pointer;
}

.BMapLib_Drawing .BMapLib_last {
  border-right: none;
}

/*拖动地图图标*/
.BMapLib_Drawing .BMapLib_hander {
  background-position: 0 0;
}

.BMapLib_Drawing .BMapLib_hander_hover {
  background-position: 0 -52px;
}

/*画点图标*/
.BMapLib_Drawing .BMapLib_marker {
  background-position: -65px 0;
}

.BMapLib_Drawing .BMapLib_marker_hover {
  background-position: -65px -52px;
}

/*画圆图标*/
.BMapLib_Drawing .BMapLib_circle {
  background-position: -130px 0;
}

.BMapLib_Drawing .BMapLib_circle_hover {
  background-position: -130px -52px;
}

/*画线图标*/
.BMapLib_Drawing .BMapLib_polyline {
  background-position: -195px 0;
}

.BMapLib_Drawing .BMapLib_polyline_hover {
  background-position: -195px -52px;
}

/*画多边形图标*/
.BMapLib_Drawing .BMapLib_polygon {
  background-position: -260px 0;
}

.BMapLib_Drawing .BMapLib_polygon_hover {
  background-position: -260px -52px;
}

/*画矩形图标*/
.BMapLib_Drawing .BMapLib_rectangle {
  background-position: -325px 0;
}

.BMapLib_Drawing .BMapLib_rectangle_hover {
  background-position: -325px -52px;
}
</style>
