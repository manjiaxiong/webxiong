<template>
  <div>
    <slot></slot>
  </div>
</template>

<script>
import commonMixin from "../base/mixins/common.js";
import bindEvents from "../base/bindEvent.js";
import { createLabel, createIcon, createPoint } from "../base/factory.js";

/**
 * 将球面坐标转换为平面坐标
 * @param initPos
 * @param targetPos
 * @param currentCount
 * @param count
 * @returns {*}
 */
function linear(initPos, targetPos, currentCount, count) {
  var b = initPos,
    c = targetPos - initPos,
    t = currentCount,
    d = count;
  return (c * t) / d + b;
}

/**
 * 设置方向
 * gaoxingzhu
 * @param curPos 起点坐标
 * @param targetPos 终点坐标
 * @param marker Marker对象
 **/
function setRotation(curPos, targetPos, marker) {
  var deg = 0;
  curPos = map.pointToPixel(curPos);
  targetPos = map.pointToPixel(targetPos);
  if (targetPos.x != curPos.x) {
    var tan = (targetPos.y - curPos.y) / (targetPos.x - curPos.x),
      atan = Math.atan(tan);
    deg = (atan * 360) / (2 * Math.PI);
    if (targetPos.x < curPos.x) {
      deg = -deg + 90 + 90;
    } else {
      deg = -deg;
    }
    marker.setRotation(-deg);
  } else {
    var disy = targetPos.y - curPos.y;
    var bias = 0;
    if (disy > 0) {
      bias = -1;
    } else {
      bias = 1;
    }
    marker.setRotation(-bias * 90);
  }
  return;
}

export default {
  name: "bm-marker",
  mixins: [commonMixin("overlay")],
  props: {
    position: {},
    offset: {},
    icon: {},
    massClear: {
      type: Boolean,
      default: true
    },
    dragging: {
      type: Boolean,
      default: false
    },
    clicking: {
      type: Boolean,
      default: true
    },
    raiseOnDrag: {
      type: Boolean,
      default: false
    },
    draggingCursor: {
      type: String
    },
    rotation: {
      type: Number
    },
    shadow: {
      type: Object
    },
    title: {
      type: String
    },
    label: {
      type: Object
    },
    animation: {
      type: String
    },
    smoothMove: {
      type: Boolean,
      default: true
    },
    top: {
      type: Boolean,
      default: false
    },
    zIndex: {
      type: Number,
      default: 0
    }
  },
  watch: {
    "position.lng"(val, oldVal) {
      if (this.smoothMove) {
        return false;
      }
      const { BMap, originInstance, position, renderByParent, $parent } = this;
      if (val !== oldVal && val >= -180 && val <= 180) {
        originInstance.setPosition(
          createPoint(BMap, { lng: val, lat: position.lat })
        );
      }
      renderByParent && $parent.reload();
    },
    "position.lat"(val, oldVal) {
      if (this.smoothMove) {
        return false;
      }
      const { BMap, originInstance, position, renderByParent, $parent } = this;
      if (val !== oldVal && val >= -74 && val <= 74) {
        originInstance.setPosition(
          createPoint(BMap, { lng: position.lng, lat: val })
        );
      }
      renderByParent && $parent.reload();
    },
    position(val, oldVal) {
      if (
        this.smoothMove &&
        val.lng.toString() !== oldVal.lng.toString() &&
        val.lat.toString() !== oldVal.lat.toString()
      ) {
        this.moveCar(oldVal, val, 40, this.originInstance, 10);
      }
    },
    "offset.width"(val, oldVal) {
      const { BMap, originInstance } = this;
      if (val !== oldVal) {
        originInstance.setOffset(new BMap.Size(val, this.offset.height));
      }
    },
    "offset.height"(val, oldVal) {
      const { BMap, originInstance } = this;
      if (val !== oldVal) {
        originInstance.setOffset(new BMap.Size(this.offset.width, val));
      }
    },
    icon: {
      deep: true,
      handler(val) {
        const { BMap, originInstance, rotation } = this;
        originInstance && originInstance.setIcon(createIcon(BMap, val));
        rotation && originInstance && originInstance.setRotation(rotation);
      }
    },
    massClear(val) {
      val
        ? this.originInstance.enableMassClear()
        : this.originInstance.disableMassClear();
    },
    dragging(val) {
      val
        ? this.originInstance.enableDragging()
        : this.originInstance.disableDragging();
    },
    clicking() {
      this.reload();
    },
    raiseOnDrag() {
      this.reload();
    },
    draggingCursor(val) {
      this.originInstance.setDraggingCursor(val);
    },
    rotation(val) {
      this.originInstance.setRotation(val);
    },
    shadow(val) {
      this.originInstance.setShadow(val);
    },
    title(val) {
      this.originInstance.setTitle(val);
    },
    label(val) {
      this.reload();
    },
    animation(val) {
      this.originInstance.setAnimation(global[val]);
    },
    top(val) {
      this.originInstance.setTop(val);
    },
    zIndex(val) {
      this.originInstance.setZIndex(val);
    }
  },
  methods: {
    moveCar(prvePoint, newPoint, timer, marker, count) {
      var _prvePoint = new this.BMap.Pixel(0, 0); //Pixel表示地图上的一个点，单位为像素
      var _newPoint = new this.BMap.Pixel(0, 0);
      var currentCount = 0; //当前帧数
      var projection = new this.BMap.MercatorProjection();
      var _prvePoint = projection.lngLatToPoint(prvePoint);
      var _newPoint = projection.lngLatToPoint(newPoint);
      var intervalFlag = setInterval(function() {
        if (currentCount >= count) {
          clearInterval(intervalFlag);
        } else {
          currentCount++; //计数
          var x = linear(_prvePoint.x, _newPoint.x, currentCount, count);
          var y = linear(_prvePoint.y, _newPoint.y, currentCount, count);
          var pos = projection.pointToLngLat(new BMap.Pixel(x, y));
          marker.setPosition(pos);
          // setRotation(prvePoint, newPoint, marker);
        }
      }, timer);
    },
    load() {
      const {
        BMap,
        map,
        position,
        offset,
        icon,
        massClear,
        dragging,
        clicking,
        raiseOnDrag,
        draggingCursor,
        rotation,
        shadow,
        title,
        label,
        animation,
        top,
        renderByParent,
        $parent,
        zIndex
      } = this;
      const overlay = new BMap.Marker(
        new BMap.Point(position.lng, position.lat),
        {
          offset,
          icon: icon && createIcon(BMap, icon),
          enableMassClear: massClear,
          enableDragging: dragging,
          enableClicking: clicking,
          raiseOnDrag,
          draggingCursor,
          rotation,
          shadow,
          title
        }
      );
      this.originInstance = overlay;
      label && overlay && overlay.setLabel(createLabel(BMap, label));
      overlay.setTop(top);
      overlay.setZIndex(zIndex);
      // bindEvents.call(this, overlay);
      // console.log(renderByParent);
      if (this.$listeners.click) {
        overlay.addEventListener("click", this.$listeners.click);
      }
      if (renderByParent) {
        $parent.reload();
        // $parent.addOverlay(this.originInstance);
      } else {
        map.addOverlay(overlay);
      }
      overlay.setAnimation(global[animation]);
    }
  }
};
</script>
