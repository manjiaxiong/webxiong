<template>
  <bm-overlay ref="customOverlay" class="cluster" pane="labelPane" @draw="draw">
    <div class="wrapper" @click="handleClick">
      <icon :class="iconColor" content="&#xe61c;" />
      <span>{{ count }}</span>
    </div>
  </bm-overlay>
</template>

<script>
export default {
  props: ["count", "cluster"],
  computed: {
    iconColor() {
      return "color" + this.count.toString().length;
    }
  },
  methods: {
    handleClick() {
      const { map } = this.$parent;
      if (map) {
        map.setViewport(this.cluster.getBounds());
        // this.delay(200).then(() => {
        //   this.$emit("click", this.cluster.getMarkers());
        // });
      }
    },
    draw({ el, BMap, map }) {
      const pixel = map.pointToOverlayPixel(this.cluster.getCenter());
      el.style.left = pixel.x + "px";
      el.style.top = pixel.y + "px";
    }
  }
};
</script>

<style lang="scss" scoped>
.cluster {
  position: absolute;
  .wrapper {
    position: relative;
    i {
      color: #1899f4;
      font-size: 48px;

      &.color1 {
        font-size: 42px!important;
        color: #05d14e!important;
      }

      &.color2 {
        font-size: 48px!important;
        color: #1899f4!important;
      }

      &.color3 {
        font-size: 54px!important;
        color: #fd7d00!important;
      }

      &.color4 {
        font-size: 60px!important;
        color: #f56c6c!important;
      }
    }
    span {
      color: #fff;
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      width: 100%;
      text-align: center;
      z-index: 99;
      font-size: 14px;
    }
  }
}
</style>
