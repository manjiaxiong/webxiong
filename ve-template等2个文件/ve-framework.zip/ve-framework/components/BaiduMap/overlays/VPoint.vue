<script>
import commonMixin from "../base/mixins/common.js";
export default {
  name: "bm-marker",
  render() {},
  mixins: [commonMixin("overlay")],
  props: {
    markers: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      init: false,
      mapvLayer: null,
      dataSet: null
    };
  },
  watch: {
    markers(v) {
      this.load();
    }
  },
  methods: {
    update(data = null) {
      const { map, BMap, markers } = this;
      if (data === null) {
        data = markers;
      }
      if (!map || !BMap) {
        return;
      }
      const bounds = map.getBounds();
      this.dataSet.set(
        data
          .filter(
            v =>
              v.vehStatus > 0 &&
              bounds.containsPoint(new BMap.Point(v.lng, v.lat))
          )
          .map(v => ({
            geometry: {
              type: "Point",
              coordinates: [v.lng, v.lat]
            },
            count: v.vehStatus
          }))
      );
      this.mapvLayer.update({});
    },
    load(data) {
      const { BMap, map, markers } = this;
      if (!map) {
        return false;
      }
      if (!this.init) {
        this.init = true;
        const { DataSet, baiduMapLayer } = require("../lib/mapv");
        this.dataSet = new DataSet([]);
        this.mapvLayer = new baiduMapLayer(map, this.dataSet, {
          draw: "category",
          // fillStyle: "#555",
          splitList: {
            1: "rgb(255, 127, 0)",
            2: "rgb(0, 191, 255)"
          },
          size: 4
        });
      }
      this.update(markers);
      // console.log(markers);
    }
  },
  destroyed() {
    this.mapvLayer.destroy();
  }
};
</script>
