<template>
  <div>
    <cluster
      :key="key"
      v-for="(cluster, key) in clusters"
      :cluster="cluster"
      :count="cluster.getMarkers().length"
    />
  </div>
</template>
<script>
import commonMixin from "../base/mixins/common.js";
import { MarkerClusterer } from "../lib/cluster";
import Cluster from "./Cluster";
import { getCarIconBase64 } from "../../../utils";
export default {
  name: "bm-marker",
  components: {
    Cluster
  },
  mixins: [commonMixin("overlay")],
  props: {
    markers: {
      type: Array,
      default: () => []
    },
    showCarNo: {
      type: Boolean,
      default: true
    },
    scopeFilter: {
      type: Boolean,
      default: true
    },
    exclude: {
      type: Array,
      default: () => []
    },
    icon: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      init: false,
      mapvLayer: null,
      dataSet: null,
      clusters: [],
      cars: [],
      imageList: {}
    };
  },
  watch: {
    markers(v) {
      this.load();
    },
    showCarNo(v) {
      this.load();
    }
  },
  methods: {
    update(data = null) {
      const { map, markers, showCarNo, imageList, exclude, scopeFilter } = this;
      if (data === null) {
        data = markers;
      }
      // console.time("coast");
      this.instance = new MarkerClusterer(map, {
        scopeFilter,
        markers: exclude.length
          ? data.filter(v => !exclude.includes(v.vehicleNo))
          : data
      });
      // console.timeEnd("coast");
      this.clusters = this.instance.getClusters();
      this.cars = this.instance.getMarkers();

      this.dataSet.set(
        this.cars.map(v => ({
          geometry: {
            type: "Point",
            coordinates: [v.lng, v.lat]
          },
          deg: typeof v.direction !== "undefined" ? 2 * v.direction - 90 : 0,
          icon: imageList[this.filterIconIndex(v)],
          text: v.vehicleNo,
          carData: v
        }))
      );
      this.mapvLayer.update({
        options: {
          showCarNo
        }
      });
    },
    load(data) {
      const {
        BMap,
        map,
        showCarNo,
        markers,
        imageList,
        exclude,
        scopeFilter
      } = this;
      if (!map) {
        return false;
      }
      if (!this.init) {
        this.init = true;
        const { DataSet, baiduMapLayer } = require("../lib/mapv");
        this.dataSet = new DataSet([]);
        this.mapvLayer = new baiduMapLayer(map, this.dataSet, {
          draw: "icon",
          showCarNo,
          fillStyle: "#555",
          methods: {
            click: item => {
              if (item && item.carData) {
                this.$emit("click", item.carData);
              }
            }
          }
        });
      }
      if (Object.keys(imageList).length === 0) {
        return false;
      }
      this.update(markers);
      // console.log(markers);
    },
    filterIconIndex(v) {
      let { vehStatus, warningStatus } = v;
      return warningStatus &&
        warningStatus != 0 &&
        (vehStatus == 1 || vehStatus == 2)
        ? parseInt(vehStatus) + 4
        : vehStatus;
    }
  },
  created() {
    const icon = Object.keys(this.icon);
    if (icon.length) {
      icon.forEach(v => {
        const src = this.icon[v].src;
        if (src) {
          var img = new Image();
          img.src = src;
          img.onload = () => {
            this.imageList[v] = img;
            if (Object.keys(this.imageList).length === icon.length) {
              this.load();
            }
          };
        }
      });
    } else {
      const status = [0, 1, 2, 3, 4, 5];
      status.forEach(v => {
        var img = new Image();
        img.src = getCarIconBase64(v);
        img.onload = () => {
          this.imageList[v] = img;
          if (Object.keys(this.imageList).length === status.length) {
            this.load();
          }
        };
      });
    }
  },
  destroyed() {
    this.instance = null;
    this.mapvLayer.destroy();
  }
};
</script>
