<template>
  <div class="distance-tool" @click="open" title="点击开始测距">
    <i class="iconfont">&#xe623;</i>
  </div>
</template>

<script>
import DistanceTool from "../lib/distanceTool";

export default {
  name: "bm-distance-tool",
  props: {
    map: {
      type: Object,
      default: () => null
    }
  },
  data() {
    return {
      tools: null
    };
  },
  methods: {
    open() {
      if (this.tools) {
        this.tools.open();
      }
    }
  },
  mounted() {
    if (this.map) {
      this.tools = new DistanceTool(this.map);
    }
  }
};
</script>

<style lang="scss" scoped>
.distance-tool {
  cursor: pointer;
  width: 32px;
  height: 32px;
  border: 1px solid #ccc;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: #f6f6f6;
  }
  i {
    font-size: 20px;
    color: #666;
  }
}
</style>
