<template>
  <bm-control :anchor="anchor" :offset="offset">
    <el-card :class="{carInfo: true, close}" @click.native="toggle">
      <div class="item" v-for="(item, key) in [1, 2, 0,3]" :key="key">
        <img :src="getCarIcon(item)" alt />
        <span>{{ getCarStatus(item) }}</span>
      </div>
    </el-card>
  </bm-control>
</template>

<script>
import { getCarIconBase64, getCarStatus } from "../../../utils";

export default {
  name: "bm-legend",
  props: {
    anchor: {
      type: String,
      default: "BMAP_ANCHOR_TOP_RIGHT"
    },
    offset: {
      type: Object,
      default: () => ({
        width: 15,
        height: 240
      })
    },
  },
  data() {
    return {
      close: false
    };
  },
  methods: {
    getCarIcon(data) {
      return getCarIconBase64(data);
    },
    getCarStatus(data) {
      return getCarStatus(data);
    },
    toggle() {
      this.close = !this.close;
    }
  }
};
</script>

<style lang="scss" scoped>
.carInfo {
  transition: transform opacity .3s;
  &.close {
    transform: translateX(64px);
    opacity: .4;
  }
  ::v-deep .el-card__body {
    padding: 10px 15px;
  }
  .item {
    padding: 5px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    img {
      display: block;
    }
    span {
      padding-left: 10px;
      color: #666;
    }
  }
}
</style>

