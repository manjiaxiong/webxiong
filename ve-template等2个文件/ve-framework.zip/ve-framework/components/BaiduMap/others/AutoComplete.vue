<template>
  <span>
    <slot>
      <input />
    </slot>
  </span>
</template>

<script>
import commonMixin from "../base/mixins/common.js";
import bindEvents from "../base/bindEvent.js";

export default {
  name: "bm-autocomplete",
  mixins: [commonMixin()],
  props: {
    types: {
      type: String
    },
    location: {
      type: String
    },
    sugStyle: {
      type: Object,
      default() {
        return {};
      }
    },
    localSearch: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    types() {
      this.reload();
    },
    location() {
      this.reload();
    }
  },
  methods: {
    load() {
      const { BMap, map, $el, types, location, sugStyle, localSearch } = this;
      const input = $el.querySelector("input");
      if (!input) {
        return;
      }
      this.originInstance = new BMap.Autocomplete({
        input,
        types,
        location: location || map,
        onSearchComplete: e => {
          const $sugs = document.querySelectorAll(".tangram-suggestion-main");
          for (const $sug of $sugs) {
            for (const name in sugStyle) {
              $sug.style[name] = sugStyle[name].toString();
            }
          }
          this.$emit("searchcomplete", e);
        }
      });

      // Support v-model
      var marker = null;
      this.originInstance.addEventListener("onconfirm", e => {
        const val = e.item.value;
        const myValue =
          val.province + val.city + val.district + val.street + val.business;
        this.$emit("input", myValue);
        if (localSearch) {
          function myFun() {
            if (marker) {
              map.removeOverlay(marker);
              marker = null;
            }
            var pp = local.getResults().getPoi(0).point; //获取第一个智能搜索的结果
            map.centerAndZoom(pp, 16);
            marker = new BMap.Marker(pp);
            map.addOverlay(marker); //添加标注
          }
          var local = new BMap.LocalSearch(map, {
            //智能搜索
            onSearchComplete: myFun
          });
          local.search(myValue);
        }
      });

      bindEvents.call(this, this.originInstance);
    }
  }
};
</script>
