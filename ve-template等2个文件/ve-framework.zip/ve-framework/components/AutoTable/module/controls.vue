<template>
  <div class="controls">
    <template v-for="(item, key) in controls">
      <el-button-group :key="key" v-if="item.group">
        <el-button
          :key="key"
          v-for="(item, key) in item.group"
          :type="item.type || 'primary'"
          :icon="renderIcon(item, true)"
          >{{ item.name }}</el-button
        >
      </el-button-group>
      <el-radio-group
        @change="change"
        v-model="radio"
        :key="key"
        v-if="ifShow(item.radioGroup, item.show)"
      >
        <template v-for="(item, key) in item.radioGroup">
          <el-radio-button
            :key="key"
            v-if="ifShow(item, item.show)"
            :label="item.command"
          >
            <i
              v-if="renderIcon(item, true) === 'iconfont'"
              :class="item.iconClass"
              v-html="item.iconContent"
            ></i>
            <i v-else-if="item.iconClass" :class="item.iconClass"></i>
            {{ item.name }}
          </el-radio-button>
        </template>
      </el-radio-group>
      <el-upload
        v-else-if="item.command === 'import'"
        :key="key"
        class="upload-container"
        :action="getUploadAction(item)"
        :headers="getHeaders()"
        :name="item.field || 'files'"
        :show-file-list="item.showFiles || false"
        :before-upload="file => beforeUpload(file, item)"
        :on-success="
          (response, file, fileList) =>
            onUploadSuccess(response, file, fileList, item)
        "
        :on-error="onUploadError"
      >
        <el-tooltip
          class="item"
          effect="dark"
          :content="renderUploadTooltip(item)"
          placement="top-start"
        >
          <el-button
            v-if="item.auth"
            v-auth="item.auth"
            :type="item.type || 'primary'"
            :size="item.size || 'small'"
            :icon="
              renderIcon(item, true) !== 'iconfont'
                ? renderIcon(item, true)
                : null
            "
          >
            <i
              v-if="renderIcon(item, true) === 'iconfont'"
              :class="item.iconClass"
              v-html="item.iconContent"
            ></i>
            {{ item.name }}
          </el-button>
          <el-button
            v-else
            :type="item.type || 'primary'"
            :size="item.size || 'small'"
            :icon="
              renderIcon(item, true) !== 'iconfont'
                ? renderIcon(item, true)
                : null
            "
          >
            <i
              v-if="renderIcon(item, true) === 'iconfont'"
              :class="item.iconClass"
              v-html="item.iconContent"
            ></i>
            {{ item.name }}
          </el-button>
        </el-tooltip>
      </el-upload>
      <template v-else-if="item.name">
        <el-button
          v-if="item.auth"
          :key="key"
          v-auth="item.auth"
          :type="item.type || 'primary'"
          :size="item.size || 'small'"
          :loading="
            typeof item.loading === 'function' ? item.loading() : item.loading
          "
          :disabled="
            typeof item.disabled === 'function'
              ? item.disabled()
              : item.disabled
          "
          :icon="
            renderIcon(item, true) !== 'iconfont'
              ? renderIcon(item, true)
              : null
          "
          @click="item.click ? item.click() : call(item.command, item)"
        >
          <i
            v-if="renderIcon(item, true) === 'iconfont'"
            :class="item.iconClass"
            v-html="item.iconContent"
          ></i>
          {{ item.name }}
        </el-button>
        <el-button
          v-else
          :key="key"
          :type="item.type || 'primary'"
          :size="item.size || 'small'"
          :loading="
            typeof item.loading === 'function' ? item.loading() : item.loading
          "
          :disabled="
            typeof item.disabled === 'function'
              ? item.disabled()
              : item.disabled
          "
          :icon="
            renderIcon(item, true) !== 'iconfont'
              ? renderIcon(item, true)
              : null
          "
          @click="item.click ? item.click() : call(item.command, item)"
        >
          <i
            v-if="renderIcon(item, true) === 'iconfont'"
            :class="item.iconClass"
            v-html="item.iconContent"
          ></i>
          {{ item.name }}
        </el-button>
      </template>
    </template>
    <slot />
    <slot name="controls" />
  </div>
</template>

<script>
import mixin from "../script/mixin";
import { getToken } from "../../../utils/auth";
export default {
  name: "v-controls",
  mixins: [mixin],
  props: {
    controls: {
      type: Array
    },
    total: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      radio: "table"
    };
  },
  methods: {
    refresh() {
      const { refresh } = this.$parent;
      if (typeof refresh === "function") {
        refresh();
      }
    },
    getUploadAction(item) {
      let baseURL = this.$config.baseURL;
      if (baseURL && baseURL.substr(-1) === "/") {
        baseURL = baseURL.substring(0, baseURL.length - 1);
      }
      return baseURL + this.$parent.getUrl(item);
    },
    change(view) {
      const { changeView } = this.$parent;
      changeView && changeView(view);
    },
    ifShow(data, show) {
      if (typeof show === "function") {
        return data && show(this.total);
      }
      return !!data;
    },
    getHeaders() {
      const tokenString = getToken();
      if (tokenString) {
        const data = JSON.parse(tokenString);
        if (data.accessToken) {
          return {
            Authorization: "Bearer " + data.accessToken
          };
        }
      }
      return null;
    },
    renderUploadTooltip(item) {
      if (!item.extensions) {
        item.extensions = ["xls", "xlsx"];
      }
      if (!item.maxSize) {
        item.maxSize = 20; // default MB
      }
      return (
        this.$t("_tm.messages.tip_24") +
        item.extensions.join(", ") +
        this.$t("_tm.messages.tip_25") +
        item.maxSize +
        "MB"
      );
    },
    onUploadSuccess(response, file, fileList, item) {
      this.$message.success(this.$t("_tm.messages.tip_23"));
      this.refresh();
      if (item.onSuccess && typeof item.onSuccess === "function") {
        item.onSuccess(response, file, fileList);
      }
    },
    onUploadError(err) {
      const error = JSON.parse(err.message);
      this.$message.error(error.message || this.$t("_tm.messages.tip_21"));
      this.refresh();
    },
    beforeUpload(file, item) {
      const { name, size } = file;
      if (name && size) {
        let { size: maxSize, extensions } = item;
        const ext = name.substring(name.lastIndexOf(".") + 1);

        if (extensions && Array.isArray(extensions) && extensions.length) {
          if (!extensions.includes(ext)) {
            this.$message.error(
              this.$t("_tm.messages.tip_20") +
                extensions.join("、") +
                this.$t("_tm.messages.tip_22")
            );
            return false;
          }
        }

        if (size > maxSize * 1024 * 1024) {
          this.$message.error(this.$t("_tm.messages.tip_19") + maxSize + "MB!");
          return false;
        }
        if (item.beforeUpload && typeof item.beforeUpload === "function") {
          item.beforeUpload(file);
        }
        return true;
      }
      return false;
    }
  }
};
</script>

<style lang="scss" scoped>
.controls {
  user-select: none;
  display: flex;
  justify-content: flex-end;
  margin-bottom: 15px;

  > .el-button,
  > .el-radio-group {
    margin-left: 10px;
  }
  .el-button {
    .iconfont {
      font-size: 12px;
      padding-right: 5px;
    }
  }
  .el-radio-group {
    i {
      position: relative;
      top: 1px;
      padding-right: 4px;
      font-size: 14px;
    }
  }

  ::v-deep .upload-container {
    .el-upload-list {
      position: absolute;
    }
  }
}
</style>
