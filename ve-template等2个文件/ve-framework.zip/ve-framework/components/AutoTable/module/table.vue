<template>
  <tm-table
    ref="table"
    :url="table.url"
    :baseURL="table.baseURL"
    :height="table.height"
    :max-height="maxHeight || table.maxHeight"
    :rowKey="table.rowKey"
    :defaultExpandAll="table.defaultExpandAll"
    :method="table.method"
    :fetch="table.fetch"
    :columns="table.columns"
    :indexIncrease="table.indexIncrease"
    :pageIndexKey="table.pageIndexKey"
    :pageSizeKey="table.pageSizeKey"
    :totalField="table.totalField"
    :listField="table.listField"
    :formOptions="table.formOptions"
    :dataHandler="table.dataHandler"
    :dataFormatter="table.dataFormatter"
    :showOrderNo="
      typeof table.showOrderNo === 'undefined' || table.showOrderNo
        ? true
        : false
    "
    :orderNoWidth="table.orderNoWidth"
    :showPagination="table.showPagination"
    :paginationType="table.pagination"
    :autoLoad="table.autoLoad"
    :params.sync="table.params"
    :paramsFormatter="table.paramsFormatter"
    :align="table.align"
    :view="table.view"
    :highlightCurrentRow="table.highlightCurrentRow"
    :border="table.border === undefined || table.border"
    :stripe="table.stripe"
    @onData="onData"
    @onSearch="onSearch"
    @onSuccess="onSuccess"
    @select="(selection, row) => eventEmitter('select', selection, row)"
    @select-all="selection => eventEmitter('selectAll', selection)"
    @selection-change="selection => eventEmitter('selectionChange', selection)"
    @sort-change="e => eventEmitter('sortChange', e)"
    @cell-click="
      (row, column, cell, event) =>
        eventEmitter('cellClick', row, column, cell, event)
    "
    @cell-dblclick="
      (row, column, cell, event) =>
        eventEmitter('cellDblclick', row, column, cell, event)
    "
    @row-click="
      (row, column, event) => eventEmitter('rowClick', row, column, event)
    "
    @current-change="
      (currentRow, oldCurrentRow) =>
        eventEmitter('currentChange', currentRow, oldCurrentRow)
    "
  >
    <el-table-column
      slot="prepend"
      v-if="table && table.showCheckBox"
      :align="
        table.operation && table.operation.align
          ? table.operation.align
          : table.align
      "
      type="selection"
      :selectable="events.selectable"
      :reserve-selection="table.reserveSelection ? true : false"
      width="55"
    ></el-table-column>
    <el-table-column
      class-name="operation"
      v-if="table.operation"
      :label="$t('_tm.table.columns.operation')"
      slot="append"
      :align="table.operation.align || table.align"
      :width="table.operation.width || '160px'"
      :fixed="table.operation.fixed || false"
    >
      <template v-if="table.operation.buttons.length" #default="{ row: data }">
        <template v-for="(item, key) in table.operation.buttons">
          <template v-if="ifShow(item, data)">
            <el-button
              v-if="item.auth"
              :key="key"
              v-auth="item.auth"
              :disabled="ifDisabled(item, data)"
              :loading="ifLoading(item, data)"
              :type="item.type || table.operation.type || 'text'"
              :size="item.size || table.operation.size || 'mini'"
              :icon="renderIcon(item)"
              :plain="item.isPlain || false"
              @click="
                item.click
                  ? item.click(data, data[item.name])
                  : call(item.command, data, item)
              "
              >{{ item.name }}</el-button
            >
            <el-button
              v-else
              :key="key"
              :disabled="ifDisabled(item, data)"
              :loading="ifLoading(item, data)"
              :type="item.type || table.operation.type || 'text'"
              :size="item.size || table.operation.size || 'mini'"
              :icon="renderIcon(item)"
              :plain="item.isPlain || false"
              @click="
                item.click
                  ? item.click(data, data[item.name])
                  : call(item.command, data, item)
              "
              >{{ item.name }}</el-button
            >
          </template>
        </template>
      </template>
    </el-table-column>

    <template #search="{ search }">
      <slot name="search" :search="search"></slot>
    </template>
    <template #prependView>
      <slot name="prependView"></slot>
    </template>
    <template v-for="slot in slots" v-slot:[slot]="{ row }">
      <slot :name="slot" :row="row"></slot>
    </template>
    <!-- tm-table search-form 插槽 -->
    <template
      v-for="slot in searchFormSlots"
      v-slot:[slot.slotName]="{ params }"
    >
      <slot :name="slot.slotName" :params="params"></slot>
    </template>
    <template v-if="table.view" v-slot:[table.view]="{ data }">
      <slot :name="table.view" :data="data"></slot>
    </template>
    <template #buttons>
      <slot name="buttons"></slot>
    </template>
    <template #buttons-right>
      <slot name="buttons-right"></slot>
    </template>
  </tm-table>
</template>

<script>
import mixin from "../script/mixin";
export default {
  mixins: [mixin],
  props: {
    table: {
      type: Object
    },
    maxHeight: [String, Number],
    slots: {
      type: Array,
      default: () => []
    },
    searchFormSlots: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    events() {
      return this.table.events || {};
    }
  },
  methods: {
    eventEmitter(evt) {
      if (evt && typeof this.events[evt] === "function") {
        this.events[evt](...Array.from(arguments).slice(1));
      }
    },
    ifShow(item, data) {
      const { show } = item;
      if (typeof show === "function") {
        return show(data);
      }
      return true;
    },
    ifDisabled(item, data) {
      const { disabled } = item;
      if (typeof disabled === "function") {
        return disabled(data);
      }
      return false;
    },
    ifLoading(item, data) {
      const { name } = item;
      if (name) {
        if (typeof data[name] === "undefined") {
          this.$set(data, name, { loading: false });
        }
        return data[name].loading;
      }
      return false;
    },
    getSearchParams() {
      return this.$refs.table.getSearchParams();
    },
    getPageSize() {
      return this.$refs.table.getPageSize();
    },
    getPagination() {
      return this.$refs.table.getPagination();
    },
    getPaginationKey() {
      return this.$refs.table.getPaginationKey();
    },
    getParams(callback) {
      return this.$refs.table.getParams(callback);
    },
    search(params = {}) {
      const table = this.$refs.table;
      table.fetchHandler(params);
      // if (params && !Object.isEmpty(params)) {
      //   table.searchHandler(params);
      // } else {
      //   // const formParams = table.getSearchParams();
      //   // console.log(formParams);

      //   // table.getParams((error, formParams) => {
      //   //   if (!error) {
      //   //     console.log(formParams);
      //   //     table.searchHandler(formParams);
      //   //   }
      //   // });
      // }
    },
    onData(total) {
      this.$emit("onData", total);
    },
    onSearch(params) {
      this.$emit("onSearch", params);
    },
    onSuccess(data) {
      this.$emit("onSuccess", data);
    },
    getTableData() {
      const table = this.$refs.table;
      if (table) {
        return table.getTableData();
      }
      return [];
    },
    getSearchFormHeight() {
      return this.$refs.table.getSearchFormHeight();
    },
    resetForm() {
      return this.$refs.table.resetForm();
    }
  }
};
</script>
