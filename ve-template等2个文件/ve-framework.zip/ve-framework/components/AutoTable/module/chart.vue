<template>
  <v-line v-if="type === 'lineChart'" :data="chartData" :settings="settings" />
  <v-bar
    v-else-if="type === 'barChart'"
    :data="chartData"
    :settings="settings"
  />
  <v-pie
    v-else-if="type === 'pieChart'"
    :data="chartData"
    :settings="settings"
  />
</template>

<script>
import vline from "v-charts/lib/line.common";
import vbar from "v-charts/lib/histogram.common";
import vpie from "v-charts/lib/pie.common";
export default {
  components: {
    "v-line": vline,
    "v-bar": vbar,
    "v-pie": vpie
  },
  props: {
    type: {
      type: String,
      default: "lineChart"
    },
    data: {
      type: Object
    }
  },
  data() {
    return {
      settings: {
        // stack: {
        //   grade: ["AAAAA", "AAAA", "AAA", "AA", "A", "B", "未评定"]
        // }
      },
      data2: {
        // columns: ["日期", "访问用户"],
        // rows: [
        //   { 日期: "1/1", 访问用户: 1393 },
        //   { 日期: "1/2", 访问用户: 3530 },
        //   { 日期: "1/3", 访问用户: 2923 },
        //   { 日期: "1/4", 访问用户: 1723 },
        //   { 日期: "1/5", 访问用户: 3792 },
        //   { 日期: "1/6", 访问用户: 4593 }
        // ]
      }
    };
  },
  computed: {
    chartData() {
      return Object.isEmpty(this.data) ? this.data2 : this.data;
    }
  },
  methods: {
    renderChartData(data) {
      this.data2 = data;
    }
  }
};
</script>
