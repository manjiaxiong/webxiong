import { renderIcon } from './icon';
export default {
  methods: {
    renderIcon(item, show) {
      return renderIcon(item, show);
    },
    call(type, data, item) {
      const { call } = this.$parent;
      if (call) {
        call(type, data, item);
      }
    }
  }
};
