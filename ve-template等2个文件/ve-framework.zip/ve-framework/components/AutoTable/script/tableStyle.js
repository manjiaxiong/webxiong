export default `
.el-table {
  position: relative;
  overflow: hidden;
  box-sizing: border-box;
  flex: 1;
  width: 100%;
  max-width: 100%;
  font-size: 14px;
  color: #606266;
}

@media print {
  .el-table .operation { display: none; }
}

table {
  width: auto!important;
}

.el-table--mini,
.el-table--small,
.el-table__expand-icon {
  font-size: 12px
}

.el-table__empty-block {
  min-height: 60px;
  text-align: center;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center
}

.el-table__empty-text {
  line-height: 60px;
  width: 50%;
  color: #909399
}

.el-table__placeholder {
  display: inline-block;
  width: 20px
}

.el-table--fit {
  border-right: 0;
  border-bottom: 0
}

.el-table--fit td.gutter,
.el-table--fit th.gutter {
  border-right-width: 1px
}

.el-table thead {
  color: #909399;
  font-weight: 500
}

.el-table thead.is-group th {
  background: #F5F7FA
}

.el-table th,
.el-table tr {
  background-color: #FFF
}

.el-table td,
.el-table th {
  padding: 12px 0;
  min-width: 0;
  box-sizing: border-box;
  text-overflow: ellipsis;
  vertical-align: middle;
  position: relative;
  text-align: left
}

.el-table td.is-center,
.el-table th.is-center {
  text-align: center
}

.el-table td.is-right,
.el-table th.is-right {
  text-align: right
}

.el-table td.gutter,
.el-table th.gutter {
  width: 15px;
  border-right-width: 0;
  border-bottom-width: 0;
  padding: 0
}

.el-table--medium td,
.el-table--medium th {
  padding: 10px 0
}

.el-table--small td,
.el-table--small th {
  padding: 8px 0
}

.el-table--mini td,
.el-table--mini th {
  padding: 6px 0
}

.el-table .cell,
.el-table th div {
  text-overflow: ellipsis;
  padding-right: 10px;
  overflow: hidden
}

.el-table .cell,
.el-table th div,
.el-table--border td:first-child .cell,
.el-table--border th:first-child .cell {
  padding-left: 10px
}

.el-table tr input[type=checkbox] {
  margin: 0
}

.el-table td,
.el-table th.is-leaf {
  border-bottom: 1px solid #EBEEF5
}

.el-table th div {
  display: inline-block;
  line-height: 40px;
  box-sizing: border-box;
  white-space: nowrap
}

.el-table th>.cell {
  position: relative;
  word-wrap: normal;
  text-overflow: ellipsis;
  display: inline-block;
  vertical-align: middle;
  width: 100%;
  box-sizing: border-box
}

.el-table td div {
  box-sizing: border-box
}

.el-table td.gutter {
  width: 0
}

.el-table .cell {
  box-sizing: border-box;
  white-space: normal;
  word-break: break-all;
  line-height: 23px
}

.el-table--border,
.el-table--group {
  border: 1px solid #EBEEF5
}

.el-table--border::after,
.el-table--group::after,
.el-table::before {
  content: '';
  position: absolute;
  background-color: #EBEEF5;
  z-index: 1
}

.el-table--border::after,
.el-table--group::after {
  top: 0;
  right: 0;
  width: 1px;
  height: 100%
}

.el-table::before {
  left: 0;
  bottom: 0;
  width: 100%;
  height: 1px
}

.el-table--border td,
.el-table--border th,
.el-table__body-wrapper .el-table--border.is-scrolling-left~.el-table__fixed {
  border-right: 1px solid #EBEEF5
}

.el-table--border th.gutter:last-of-type {
  border-bottom: 1px solid #EBEEF5;
  border-bottom-width: 1px
}

.el-table--border th,
.el-table__fixed-right-patch {
  border-bottom: 1px solid #EBEEF5
}

.el-table__fixed-header-wrapper {
  position: absolute;
  left: 0;
  top: 0;
  z-index: 3
}

.el-table__fixed-footer-wrapper {
  position: absolute;
  left: 0;
  bottom: 0;
  z-index: 3
}

.el-table__fixed-footer-wrapper tbody td {
  border-top: 1px solid #EBEEF5;
  background-color: #F5F7FA;
  color: #606266
}

.el-table__fixed-body-wrapper {
  position: absolute;
  left: 0;
  top: 37px;
  overflow: hidden;
  z-index: 3
}

.el-table__body-wrapper,
.el-table__footer-wrapper,
.el-table__header-wrapper {
  width: 100%
}

.el-table__footer-wrapper {
  margin-top: -1px
}

.el-table__footer-wrapper td {
  border-top: 1px solid #EBEEF5
}

.el-table__body,
.el-table__footer,
.el-table__header {
  table-layout: fixed;
  border-collapse: separate
}

.el-table__footer-wrapper,
.el-table__header-wrapper {
  overflow: hidden
}

.el-table__footer-wrapper tbody td,
.el-table__header-wrapper tbody td {
  background-color: #F5F7FA;
  color: #606266
}

.el-table__body-wrapper {
  overflow: hidden;
  position: relative
}

.el-table .hidden-columns {
  display: none;
}
`;
