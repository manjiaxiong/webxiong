const iconMaps = {
  add: 'el-icon-plus',
  edit: 'el-icon-edit-outline',
  remove: 'el-icon-delete',
  import: 'el-icon-upload2',
  export: 'el-icon-download',
  print: 'el-icon-printer',
  lineChart: 'el-icon-data-line',
  barChart: 'el-icon-data-analysis',
  table: 'el-icon-tickets'
};
export const renderIcon = (item, show) => {
  const { iconClass, icon, command } = item;
  if (iconClass) {
    return iconClass;
  }
  if (icon && typeof icon === 'string') {
    if (icon.indexOf('#') > -1) {
      show = false;
      item.iconContent = icon;
    } else if (icon.indexOf('el-icon') > -1) {
      show = false;
    }
  }
  const iconCls =
    icon === true || (show && icon !== false)
      ? iconMaps[command] || ''
      : icon || '';
  item.iconClass = item.iconContent ? 'iconfont' : iconCls;
  return item.iconClass;
};
