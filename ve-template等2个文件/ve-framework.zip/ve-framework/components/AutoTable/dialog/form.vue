<template>
  <v-form
    ref="form"
    :options="params.options"
    :label-width="params.labelWidth || '100px'"
    :params="params"
  >
    <el-form-item
      class="dialog-button"
      v-if="params.options && params.options.length && params.type !== 'detail'"
    >
      <template v-if="params.beforeButtons">
        <el-button
          v-for="(item, key) in params.beforeButtons"
          :key="key"
          :type="item.type || 'primary'"
          :size="item.size || 'small'"
          :loading="
            typeof item.loading === 'function' ? item.loading() : item.loading
          "
          :disabled="
            typeof item.disabled === 'function'
              ? item.disabled()
              : item.disabled
          "
          :icon="
            renderIcon(item, true) !== 'iconfont'
              ? renderIcon(item, true)
              : null
          "
          @click="item.click($refs.form)"
        >
          <i
            v-if="renderIcon(item, true) === 'iconfont'"
            :class="item.iconClass"
            v-html="item.iconContent"
          ></i>
          {{ item.name }}
        </el-button>
      </template>
      <el-button type="default" @click="cancel">{{$t('_tm.dialog.cancel')}}</el-button>
      <el-button type="primary" :loading="loading" @click="confirm"
        >{{$t('_tm.dialog.confirm')}}</el-button
      >
    </el-form-item>
  </v-form>
</template>

<script>
import Form from "../../Form";
import { renderIcon } from "../script/icon";
export default {
  components: {
    "v-form": Form
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      loading: false
    };
  },
  methods: {
    renderIcon,
    open() {
      const { methods } = this.params;
      if (methods && typeof methods.open === "function") {
        methods.open(this.$refs.form);
      }
    },
    opened() {
      this.$nextTick(() => {
        this.$refs.form.init();
      });
    },
    closed() {
      this.reset();
    },
    reset() {
      this.$refs.form.reset();
    },
    cancel() {
      this.$emit("close");
    },
    message(message, type = "success") {
      this.loading = false;
      this.cancel();
      this.$message({
        type,
        message
      });
    },
    updateItemData(v, data, item) {
      const key = v.id;
      if (Array.isArray(key)) {
        key.forEach(id => {
          if (item[id] !== data[id]) {
            this.$set(this.params.data, id, data[id]);
          }
        });
      } else if (typeof key === "string") {
        if (item[key] !== data[key]) {
          this.$set(this.params.data, key, data[key]);
        }
      }
    },
    updateTableData(data) {
      const item = this.params.copy || this.params.data;
      const options = this.params.options;
      if (item && options && options.length) {
        options.forEach(v => {
          if (v.items) {
            v.items.forEach(v => {
              this.updateItemData(v, data, item);
            });
          } else {
            this.updateItemData(v, data, item);
          }
        });
      }
    },
    confirm() {
      if (this.params.type === "detail") {
        return this.cancel();
      }
      const form = this.$refs.form;
      form.validate(valid => {
        if (valid) {
          this.loading = true;
          let params = form.getParams();
          const { methods = {}, type, options, id, refresh, success } = this.params;
          const { add, update } = methods;
          const hasUpload = options.filter(v => typeof v.show === "undefined" || v.show(type,params)).some(v => v.upload);
          let formData = null;
          switch (type) {
            case "add":
              if (hasUpload) {
                formData = new FormData();
                Object.keys(params).forEach(v => {
                  formData.append(v, params[v]);
                });
              }
              add &&
                add(formData || params, id || null)
                  .then(data => {
                    if (data) {
                      const { status, message } = data;
                      if (status && status !== 200 && message) {
                        this.loading = false;
                        this.cancel();
                      } else {
                        this.message(this.params.message || this.$t('_tm.messages.tip_16'));
                        refresh && refresh();
                        success && success(data, formData || params, this.params)
                      }
                    }
                  })
                  .catch(() => {
                    this.loading = false;
                  });
              break;

            case "edit":
              const { data: copy, onParams } = this.params;
              if (hasUpload) {
                  formData = new FormData();
                  console.log(formData)
                  Object.keys(params).forEach(v => {
                    formData.append(v, params[v]);
                  });
              }
              if (update && id) {
                if (copy && typeof onParams === "function") {
                  const result = onParams(params, copy);
                  if (result) {
                    params = result;
                  }
                }
                update(formData || params, id)
                  .then(data => {
                    if (data) {
                      this.message(this.$t('_tm.messages.tip_26'));
                      if (typeof data === "object") {
                        this.updateTableData(data);
                      } else if (refresh) {
                        refresh();
                      }
                      success && success(data, formData || params, this.params)
                    }
                  })
                  .catch(() => {
                    this.loading = false;
                  });
              }
              break;

            default:
              if (methods[type]) {
                const callback = methods[type](params, id, this.message);
                if (callback && callback.then) {
                  callback
                    .then(data => {
                      this.message(this.$t('_tm.messages.tip_27'));
                      if (this.params.update && refresh) {
                        refresh();
                      }
                      success && success(data, formData || params, this.params)
                    })
                    .catch(() => {
                      this.loading = false;
                    });
                }
              }
              break;
          }
        }
      });
    }
  },
};
</script>

<style lang="scss" scoped>
.v-form {
  .dialog-button {
    margin-bottom: 0;
    display: flex;
    justify-content: flex-end;
  }
}
</style>
