<template>
  <v-chart type="pieChart" :data="data" />
</template>

<script>
import Chart from "../module/chart";
export default {
  components: {
    "v-chart": Chart
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      data: {}
    };
  },
  methods: {
    opened() {
      const { copy } = this.params;
      this.data = copy;
    }
  }
};
</script>
