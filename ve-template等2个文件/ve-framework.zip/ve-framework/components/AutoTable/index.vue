<template>
  <div class="auto-table-container">
    <controls :total="total" :controls="controls">
      <slot name="controls"></slot>
    </controls>

    <div ref="views" :class="{ views: true, flex: table.flex }">
      <v-table
        ref="table"
        v-show="view === 'table'"
        :table="table"
        :slots="slots"
        :searchFormSlots="searchFormSlots"
        :max-height="maxHeight"
        @onData="onData"
        @onSearch="onSearch"
        @onSuccess="onSuccess"
      >
        <!-- tm-table table 插槽 -->
        <template v-for="slot in slots" v-slot:[slot]="{ row }">
          <slot :name="slot" :row="row"></slot>
        </template>
        <!-- tm-table search-form 插槽 -->
        <template v-for="slot in searchFormSlots" v-slot:[slot.slotName]="{ params }">
          <slot :name="slot.slotName" :params="params"></slot>
        </template>
        <template v-if="table.view" v-slot:[table.view]="{ data }">
          <slot :name="table.view" :data="data"></slot>
        </template>
        <template #search="{ search }">
          <slot name="search" :search="search"></slot>
        </template>
        <template #prependView>
          <slot name="prependView"></slot>
        </template>
        <template #buttons>
          <slot name="buttons"></slot>
        </template>
        <template #buttons-right>
          <slot name="buttons-right"></slot>
        </template>
      </v-table>
      <v-chart ref="chart" v-show="view !== 'table'" :type="view" />
    </div>

    <v-dialog
      :scope="scope2"
      :dialogMaps="__dialogMaps"
      :fullscreen="dialog.fullscreen"
      :modal-close="mClose"
      :appendToBody="true"
    >
      <template v-for="slot in dslots" #[slot]="{ dialog }">
        <slot :name="slot" :dialog="dialog"></slot>
      </template>
    </v-dialog>
  </div>
</template>

<script>
import Printd from "printd";
import { json2param } from "../../utils/index.js";
import Controls from "./module/controls";
import Table from "./module/table";
import Chart from "./module/chart";
import Form from "./dialog/form";
import dChart from "./dialog/chart";
import style from "./script/tableStyle";
import { download } from "../../utils/export";
export default {
  name: "AutoTable",
  components: {
    Controls,
    "v-chart": Chart,
    "v-table": Table
  },
  props: {
    name: {
      type: String,
      default: ""
    },
    scope: {
      type: String,
      default: ""
    },
    methods: {
      type: Object,
      default: () => ({})
    },
    dialogMaps: {
      type: Object,
      default: () => ({})
    },
    table: {
      type: Object,
      default: () => ({})
    },
    maxHeight: [String, Number],
    controls: {
      type: Array,
      default: () => []
    },
    options: {
      type: Array,
      default: () => []
    },
    primaryKey: {
      type: String,
      default: "id"
    },
    modalClose: {
      type: Boolean,
      default: false
    },
    labelWidth: {
      type: String,
      default: "100px"
    },
    dialog: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    __dialogMaps() {
      const { maps } = this.dialog;
      if (maps) {
        Object.keys(maps).forEach(k => {
          if (maps[k].options) {
            maps[k].component = Form;
          }
        });
      }
      return Object.assign({}, maps || this.dialogMaps, this.dialogMaps2);
    },
    mClose() {
      return typeof this.dialog.modalClose !== "undefined"
        ? this.dialog.modalClose
        : this.modalClose;
    },
    scope2() {
      return this.scope || this.$route.name || this.$route.path;
    },
    slots() {
      return (
        this.table.slots ||
        (this.table.columns && this.table.columns.length
          ? this.table.columns.filter(v => v.slotName).map(v => v.slotName)
          : [])
      );
    },
    dslots() {
      const maps = this.dialog ? this.dialog.maps : null;
      return maps
        ? Object.keys(maps)
            .filter(v => maps[v].slotName && !maps[v].component)
            .map(v => maps[v].slotName)
        : [];
    },
    // tm-table search-form 插槽
    searchFormSlots(){
      if(this.table.formOptions && this.table.formOptions.forms && this.table.formOptions.forms.length){
        return this.table.formOptions.forms.filter(v => v.itemType === 'slot')
      }
      return []
    }
  },
  data() {
    const { width = "560px", grid = 1 } = this.dialog;
    return {
      total: 0,
      view: "table",
      basicUrl: "",
      dialogMaps2: {
        add: {
          title: this.$t('_tm.table.actions.add') + this.name,
          component: Form,
          width,
          grid
        },
        edit: {
          title: this.$t('_tm.table.actions.edit') + this.name,
          component: Form,
          width,
          grid
        },
        detail: {
          title: this.name + this.$t('_tm.table.actions.detail'),
          component: Form,
          modalClose: true,
          width,
          grid
        },
        pieChart: {
          title: this.$t('_tm.dialog.chartDetail'),
          component: dChart,
          modalClose: true,
          width
        }
      }
    };
  },
  methods: {
    call(type, data, item) {
      if (typeof this[type] === "function") {
        this[type](data, item);
      } else {
        let copy = null;
        if (data && !data.command && !data.name) {
          copy = this.formatData(data);
        }
        this.open(type, data, copy);
      }
    },
    open(type, data, copy) {
      let formOptions = this.dialog.options || this.options;
      let modeKey = this.dialog.modeKey || "";
      const { maps } = this.dialog;
      let isFullscreen = false;
      let pk = this.primaryKey;
      let others = {};
      if (maps && maps[type]) {
        const {
          title,
          width,
          modalClose,
          component,
          options,
          fullscreen,
          confirm,
          primaryKey,
          ...rest
        } = maps[type];
        if (options) {
          formOptions = options;
        }
        if (confirm) {
          this.methods[type] = confirm;
        }
        if (fullscreen) {
          isFullscreen = true;
        }
        if (primaryKey) {
          pk = primaryKey;
        }
        others = rest;
      }
      const params = {
        type,
        options: formOptions,
        fullscreen: isFullscreen,
        modeKey,
        methods: this.methods,
        refresh: this.refresh,
        labelWidth: this.dialog.labelWidth || this.labelWidth,
        groupType: this.dialog.groupType,
        onParams: this.dialog.onParams,
        success: this.dialog.success,
        ...others
      };
      // console.log(params);
      if (data.command && data.name) {
        if (data.message) {
          params.message = data.message;
        }
      } else {
        params.data = data;
        params.id = data[pk];
      }
      if (copy) {
        params.copy = copy;
      }
      this.$dialog.open(this.scope2, type, params);
    },
    renderChartData(data) {
      this.$refs.chart.renderChartData(data);
    },
    print() {
      const $dom = this.$refs.views;
      if ($dom) {
        const $el = $dom.querySelector(".el-table");
        if ($el) {
          const p = new Printd();
          p.print($el, [style]);
        }
      }
    },
    getUrl(data) {
      const baseURL = data.baseURL || this.table.baseURL || "";
      return (
        // location.origin +
        baseURL + (data.url || this.table.url + "/" + data.command)
      );
    },
    setUrl(url) {
      if (this.table.url && !this.basicUrl) {
        this.basicUrl = this.table.url;
      }
      this.table.url = url;
    },
    restore() {
      if (this.basicUrl) {
        this.table.url = this.basicUrl;
      }
    },
    axios(url, fileName, params = {}) {
      return this.$axios({
        url,
        timeout: 60000,
        responseType: "blob",
        method: "get",
        params
      }).then(res => {
        if (res) {
          if (res.type === "application/json" || !res instanceof Blob) {
            return this.$message.error(this.$t('_tm.messages.tip_18'));
          }
          download(
            res.data || res,
            res.fileName ||
              (typeof fileName === "function" ? fileName() : fileName) ||
              "导出信息.xls"
          );
        }
      });
    },
    export(data) {
      if (typeof data.loading === "undefined") {
        this.$set(data, "loading", true);
      } else {
        data.loading = true;
      }
      let url = this.getUrl(data);
      let params = this.getSearchParams() || {};
      if (url.indexOf("http://") > -1) {
        if (params) {
          url = url + "?" + json2param(params);
        }
        window.open(url);
      } else {
        const $table = this.$refs.table;
        const { pageSize, pageIndex } = $table.getPagination();
        const { pageSizeKey, pageIndexKey } = $table.getPaginationKey();
        if (Object.isEmpty(params)) {
          params[pageSizeKey] = pageSize;
          params[pageIndexKey] = pageIndex;
          $table.getParams((error, formParams) => {
            if (error) {
              data.loading = false;
              this.$message.error(this.$t('_tm.messages.tip_17')); 
            } else {
              params = Object.assign({}, formParams, params);
              this.axios(url, data.fileName, params)
                .then(() => {
                  data.loading = false;
                })
                .catch(err => {
                  data.loading = false;
                });
            }
          });
        } else {
          params[pageSizeKey] = pageSize;
          params[pageIndexKey] = pageIndex;
          this.axios(url, data.fileName, params)
            .then(() => {
              data.loading = false;
            })
            .catch(err => {
              data.loading = false;
            });
        }
      }
    },
    download(data) {
      let url = this.getUrl(data);
      if (url.indexOf("http://") > -1) {
        window.open(url);
      } else {
        this.axios(url, data.fileName || "导入模板.xls");
      }
    },
    _excute(id, data, func, item, msg) {
      if (item.name && data[item.name]) {
        data[item.name].loading = true;
      }
      func(id)
        .then(() => {
          this.refresh();
          this.$message({
            type: "success",
            message: msg
          });
          if (item.name && data[item.name]) {
            data[item.name].loading = false;
          }
        })
        .catch(err => {
          if (item.name && data[item.name]) {
            data[item.name].loading = false;
          }
        });
    },
    update(data, func, item, msg) {
      if (data && item) {
        const id = data[this.primaryKey];
        if (id) {
          if (typeof item.method === "function") {
            func = item.method;
          }
          if (item.message) {
            msg = item.message;
          }
          if (typeof func === "function") {
            if (typeof item.confirmMessage === "string") {
              this.$confirm(item.confirmMessage, this.$t('_tm.dialog.tip'), {
                type: "warning"
              })
                .then(() => {
                  this._excute(id, data, func, item, msg);
                })
                .catch(() => null);
            } else {
              this._excute(id, data, func, item, msg);
            }
          }
        }
      }
    },
    status(data, item) {
      this.update(data, this.methods.status, item, "状态更新成功!");
    },
    enable(data, item) {
      this.update(data, this.methods.enable, item, "启用成功!");
    },
    disable(data, item) {
      this.update(data, this.methods.disable, item, "停用成功!");
    },
    changeView(view) {
      this.view = view;
    },
    onData(total) {
      this.total = total;
      this.$emit("onData", total);
    },
    onSearch(params) {
      this.$emit("onSearch", params);
    },
    onSuccess(data) {
      this.$emit("onSuccess", data);
    },
    getTableData() {
      return this.$refs.table.getTableData();
    },
    getSearchParams() {
      return this.$refs.table.getSearchParams();
    },
    getParams(callback) {
      return this.$refs.table.getParams(callback);
    },
    formatData(data) {
      const { formatData } = this.$parent;
      let copy = null;
      if (formatData) {
        const item = Object.assign({}, data);
        copy = formatData(item);
      }
      return copy;
    },
    refresh(params = {}) {
      this.$refs.table.search(params);
      this.$emit("onRefresh");
    },
    remove(data) {
      const id = data[this.primaryKey];
      const { remove } = this.methods;
      if (id && remove) {
        this.$confirm(this.$t('_tm.messages.tip_11'), this.$t('_tm.dialog.tip'), {
          type: "warning"
        })
          .then(() => {
            remove(id).then(data => {
              this.refresh({ remove: true });
              this.$message({
                type: "success",
                message: this.$t('_tm.messages.tip_12')
              });
            });
          })
          .catch(() => {});
      }
    },

    getSearchFormHeight() {
      return this.$refs.table.getSearchFormHeight()
    },
    // 重置查询form
    resetForm() {
      this.$refs.table.resetForm()
    },

    getPagination() {
        const page = this.$refs.table.getPagination();
        return page;
    }
  }
};
</script>

<style lang="scss">
.auto-table-container {
  .views {
    &.flex {
      display: flex;
      .tm-table-warp {
        flex: 1;
      }
    }
  }
  .el-table__row {
    td {
      padding-top: 8px;
      padding-bottom: 6px;
    }
  }
}
</style>
