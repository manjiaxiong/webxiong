<template>
  <div class="form-item" v-if="ifShow(item)">
    <template v-if="typeof item.id === 'string'">
      <el-form-item
        :prop="item.id"
        :label="item.name"
        :label-width="item.labelWidth"
        :rules="getRules(item, item.id)"
        :inline-message="item.inlineMessage || false"
        :style="item.image ? 'margin-bottom: 0;' : ''"
        :class="item.class"
      >
        <template v-if="item.image && typeof $config.photoURL !== 'undefined'">
          <el-image
            v-if="form[item.id]"
            :style="getImageStyle(item.image)"
            :src="$config.photoURL + form[item.id]"
          >
            <div slot="error" class="image-slot">
              <i class="el-icon-picture-outline"></i>
            </div>
          </el-image>
          <div v-else :style="getImageStyle(item.image)">
            <div slot="error" class="image-slot">
              <i class="el-icon-picture-outline"></i>
            </div>
          </div>
        </template>

        <el-cascader
          v-else-if="item.cascader"
          v-model="form[item.id]"
          :options="typeof item.cascader === 'function'
              ? item.cascader(params.copy || params.data, form)
              : item.cascader"
          :props="item.props"
          :size="item.size"
          :placeholder="item.placeholder"
          :disabled="item.disabled"
          :clearable="item.clearable"
          :show-all-levels="item.showAllLevels || false"
          :collapse-tags="item.collapseTags || true"
          :separator="item.separator"
          :filterable="item.filterable"
          @change="value => cascaderChange(value, item)"
        ></el-cascader>

        <el-select
          v-else-if="item.select"
          :multiple="item.multiple || false"
          :collapse-tags="item.collapseTags || false"
          v-model="form[item.id]"
          :disabled="readonly(item.disabled || item.readonly)"
          :clearable="item.clearable"
          :remote="item.remote"
          :remote-method="item.remoteMethod"
          :loading="
            typeof item.loading === 'function' ? item.loading() : item.loading
          "
          :filterable="item.filterable"
          :placeholder="item.placeholder"
          :allow-create="item.allowCreate"
          @change="v => change(v, item)"
          @clear="() => eventCall(item, 'clear')"
        >
          <template
            v-for="(item2, key) in typeof item.select === 'function'
              ? item.select(params.copy || params.data, form)
              : item.select"
          >
            <el-option
              :key="key"
              v-if="
                typeof item2.show === 'undefined' ||
                  (item2.show && item2.show(params))
              "
              :label="item2[item.labelKey || 'name']"
              :value="item2[item.valueKey || 'id']"
            >
              <span v-if="item.showTips">
                {{
                item2[item.labelKey || "name"]
                }}
              </span>
              <span
                v-if="item.showTips"
                style="float: right; color: #aaa; font-size: 14px"
              >{{ item2[item.tipsKey || item.valueKey || "id"] }}</span>
            </el-option>
          </template>
        </el-select>
        <el-radio-group v-else-if="item.radio" v-model="form[item.id]">
          <el-radio
            :key="key"
            v-for="(item, key) in typeof item.radio === 'function'
              ? item.radio()
              : item.radio"
            :label="item.id"
          >{{ item.name }}</el-radio>
        </el-radio-group>
        <el-switch
          v-else-if="item.switch"
          v-model="form[item.id]"
          :active-text="item.switch.activeText"
          :inactive-text="item.switch.inactiveText"
        ></el-switch>
        <el-slider
          class="v-slider"
          v-else-if="item.slider"
          v-model="form[item.id]"
          :min="item.slider.min"
          :max="item.slider.max"
        ></el-slider>
        <el-upload
          v-else-if="item.upload"
          ref="upload"
          class="v-upload"
          :show-file-list="item.upload.type==='photo'?false:true"
          :action="item.upload.action || '#'"
          :limit="item.upload.limit"
          :headers="item.upload.headers || {}"
          :auto-upload="false"
          :on-change="file => uploadChange(file, item.upload.change, item.id,item.type)"
          :before-upload="file=>beforeAvatarUpload(file,item.upload.before)"
        >
          <div v-if="item.upload.type === 'photo'">
            <img
              v-if="form[item.id]"
              :src="/^(blob:http:|http(s:|:))\/\//.test(form[item.id]) ? form[item.id] : $config.photoURL + form[item.id]"
              class="avatar"
            />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </div>
          <el-button v-else size="small" type="primary">{{ item.upload.name || $t('_tm.components.message_2') }}</el-button>
          <div v-if="item.upload.tip" slot="tip" class="el-upload__tip">{{ item.upload.tip }}</div>
        </el-upload>
        <el-input-number
          v-else-if="item.integer"
          :precision="item.precision || 0"
          :controls-position="item.position"
          :min="item.min"
          :max="item.max"
          v-model="form[item.id]"
          :placeholder="item.placeholder"
        ></el-input-number>
        <el-input-number
          v-else-if="item.number"
          v-model="form[item.id]"
          :placeholder="item.placeholder"
        ></el-input-number>
        <el-time-picker
          v-else-if="item.time"
          v-model="form[item.id]"
          :is-range="item.isRange"
          :value-format="item.valueFormat"
          :format="item.valueFormat"
          :editable="false"
          :picker-options="item.pickerOptions"
          :placeholder="item.placeholder || $t('_tm.placeholders.message_31')"
        ></el-time-picker>
        <el-date-picker
          v-else-if="item.date"
          v-model="form[item.id]"
          :value-format="item.valueFormat || 'yyyy-MM-dd'"
          type="date"
          :picker-options="
            typeof item.pickerOptions === 'function'
              ? item.pickerOptions(form)
              : item.pickerOptions
          "
          :placeholder="$t('_tm.placeholders.message_31')"
        ></el-date-picker>
        <el-date-picker
          v-else-if="item.datetime"
          :value-format="item.valueFormat || 'yyyy-MM-dd HH:mm:ss'"
          :format="item.format"
          v-model="form[item.id]"
          type="datetime"
          :placeholder="item.placeholder"
        ></el-date-picker>
        <el-date-picker
          v-else-if="item.datetimerange"
          v-model="form[item.id]"
          type="datetimerange"
          :format="item.format"
          :value-format="item.valueFormat || 'yyyy-MM-dd HH:mm:ss'"
          :time-arrow-control="true"
          :picker-options="
            typeof item.pickerOptions === 'function'
              ? item.pickerOptions(form)
              : item.pickerOptions
          "
          :range-separator="$t('_tm.common.to')"
          :start-placeholder="$t('_tm.placeholders.message_24')"
          :end-placeholder="$t('_tm.placeholders.message_26')"
        ></el-date-picker>
        <el-input
          v-else-if="item.textarea"
          type="textarea"
          :maxlength="item.maxlength"
          :show-word-limit="item.showWordLimit"
          :autosize="item.textarea.autosize || { minRows: 3, maxRows: 6 }"
          :placeholder="item.placeholder"
          v-model="form[item.id]"
        ></el-input>
        <el-input
          v-else-if="['number', 'integer'].includes(item.type)"
          :type="item.type"
          :max="item.max"
          :min="item.min"
          :clearable="item.clearable"
          v-model.number="form[item.id]"
          :placeholder="item.placeholder"
          :readonly="readonly(item.readonly)"
          @change="val=>inputChange(val,item)"
        >
          <template v-if="item.unit" slot="append">{{ item.unit }}</template>
        </el-input>        
        <el-input
          v-else
          v-model="form[item.id]"
          :maxlength="item.maxlength"
          :show-word-limit="item.showWordLimit"
          :max="item.max"
          :min="item.min"
          :clearable="item.clearable"
          :placeholder="item.placeholder"
          :readonly="readonly(item.readonly)"
          :disabled="readonly(item.disabled)"
          @focus="() => eventCall(item, 'focus')"
        >
          <template v-if="typeof item.unit === 'string'" slot="append">
            {{
            item.unit
            }}
          </template>
          <el-button
            v-else-if="typeof item.unit === 'object'"
            slot="append"
            :icon="item.unit.icon || 'el-icon-setting'"
            @click="
              () => {
                if (typeof item.unit.click === 'function') {
                  item.unit.click(params, form);
                }
              }
            "
          ></el-button>
        </el-input>
      </el-form-item>
    </template>
    <div
      class="range-input-wrapper"
      v-else-if="typeof item.id === 'object' && item.id.length"
    >
      <el-form-item :label="item.name" :rules="getRules(item)"></el-form-item>
      <el-form-item
        v-if="ifShow(item)"
        :prop="item.id[0]"
        :rules="getRules(item, item.id[0])"
        :inline-message="item.inlineMessage || false"
      >
        <el-input
          v-if="['number', 'integer'].includes(item.type)"
          :type="item.type"
          :max="item.max"
          :min="item.min"
          v-model.number="form[item.id[0]]"
          :placeholder="
            Array.isArray(item.placeholder)
              ? item.placeholder[0]
              : item.placeholder
          "
          :readonly="readonly(item.readonly)"
        >
          <template v-if="item.unit" slot="append">{{ item.unit }}</template>
        </el-input>
        <el-input
          v-else-if="item.type === 'coordinate'"          
          :placeholder="
            Array.isArray(item.placeholder)
              ? item.placeholder[0]
              : item.placeholder
          "
          v-model="form[item.id[0]]"
          @focus="item.focus"
          @change="item.change"
        ></el-input>
        <el-input
          v-else
          v-model="form[item.id[0]]"
          :maxlength="item.maxlength"
          :show-word-limit="item.showWordLimit"
          :max="item.max"
          :min="item.min"
          :placeholder="
            Array.isArray(item.placeholder)
              ? item.placeholder[0]
              : item.placeholder
          "
          :readonly="readonly(item.readonly)"
        >
          <template v-if="item.unit" slot="append">{{ item.unit }}</template>
        </el-input>
      </el-form-item>
      <span>~</span>
      <el-form-item
        v-if="ifShow(item)"
        :prop="item.id[1]"
        :rules="getRules(item, item.id[1])"
        :inline-message="item.inlineMessage || false"
      >
        <el-input
          v-if="['number', 'integer'].includes(item.type)"
          :type="item.type"
          :max="item.max"
          :min="item.min"
          v-model.number="form[item.id[1]]"
          :placeholder="
            Array.isArray(item.placeholder)
              ? item.placeholder[1]
              : item.placeholder
          "
          :readonly="readonly(item.readonly)"
        >
          <template v-if="item.unit" slot="append">{{ item.unit }}</template>
        </el-input>
        <el-input
          v-else-if="item.type === 'coordinate'"        
          :placeholder="
            Array.isArray(item.placeholder)
              ? item.placeholder[1]
              : item.placeholder
          "
          v-model="form[item.id[1]]"
          @focus="item.focus"
          @change="item.change"
        ></el-input>
        <el-input
          v-else
          v-model="form[item.id[1]]"
          :maxlength="item.maxlength"
          :show-word-limit="item.showWordLimit"
          :max="item.max"
          :min="item.min"
          :placeholder="
            Array.isArray(item.placeholder)
              ? item.placeholder[1]
              : item.placeholder
          "
          :readonly="readonly(item.readonly)"
        >
          <template v-if="item.unit" slot="append">{{ item.unit }}</template>
        </el-input>
      </el-form-item>
    </div>
  </div>
</template>

<script>
const types = [
  "string",
  "number",
  "boolean",
  "method",
  "regexp",
  "integer",
  "float",
  "array",
  "object",
  "enum",
  "date",
  "url",
  "hex",
  "email",
  "mobile",
  "phone",
  "idcard",
  "carNo",
  "ip",
  "domain",
  "ipdomain"
];
export default {
  props: {
    item: {
      type: Object
    },
    form: {
      type: Object
    },
    params: {
      type: Object
    }
  },
  computed: {
    mode() {
      return this.form[this.params.modeKey];
    }
  },
  methods: {
    inputChange(val, item) {
      if (typeof item.formatter === "function") {
        this.form[item.id] = item.formatter(val, item);
      }
    },
    beforeAvatarUpload(file, before) {
      return typeof before === "function" ? before(file) : true;
    },
    uploadChange(file, onChange, id, type) {
      if (id && file.raw) {
        if (type === "photo") {
          this.form[id] = URL.createObjectURL(file.raw);
        } else this.form[id] = file.raw;
      }
      if (typeof onChange === "function") {
        onChange(file, this.form, id);
      }
    },
    // 级联选择器
    cascaderChange(value, form) {
      let { prop, change } = form;
      if (change && typeof change === "function") {
        change(value, prop, form, this.params);
      }
    },
    getImageStyle({ width, height }) {
      let style = "";
      if (width) {
        style = "width: " + width + "px;";
      }
      if (height) {
        style += (style ? " " : "") + "height: " + height + "px;";
      }
      return style;
    },
    getRules(item, id) {
      // console.log(id);
      const rules = item.rules || [];
      if (item._rules && typeof item.id === "string") {
        // console.log("cache", item._rules);
        return item._rules;
      }
      const trigger = item.select
        ? // || item.radio
          // || item.date
          // || item.datetime
          // || item.datetimerange
          "change"
        : "blur"; // 目前都使用 blur 暂时保留判断
      if (item.validator) {
        const { callback, trigger: vTrigger } = item.validator;
        if (callback) {
          return [
            {
              validator: (a, b, c) => {
                callback(a, b, c, this.form);
              },
              trigger: vTrigger || trigger
            }
          ];
        }
      }
      let name = item.name;
      const isRange = Array.isArray(item.id) && id;
      if (isRange) {
        if (id === item.id[0]) {
          name = this.$t('_tm.rules.message_17') + (item.compare ? item.compare[0] : this.$t('_tm.rules.message_18')) + name;
        } else if (id === item.id[1]) {
          name = this.$t('_tm.rules.message_17') + (item.compare ? item.compare[1] : this.$t('_tm.rules.message_19')) + name;
        }
      }
      if (typeof item.required === 'function' ? item.required(this.params, id) : item.required) {
        rules.push({
          required: true,
          message: name + this.$t('_tm.rules.message_20'),
          trigger
        });
        if (!id) {
          return rules;
        }
      }
      if (!id) {
        return [];
      }
      if (typeof this.form[id] !== "undefined" && this.form[id] !== "") {
        if ((item.type && types.includes(item.type)) || item.pattern) {
          const message = name + this.$t('_tm.rules.message_21');
          const rule = {
            message,
            trigger
          };

          if (item.type === "mobile") {
            rule.pattern = /^1[3456789]\d{9}$/;
          } else if (item.type === "phone") {
            rule.pattern = /^(1[3456789]\d{9})|((\d{3,4})-(\d{7,8}))$/;
          } else if (item.type === "idcard") {
            rule.pattern = /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$)/;
          } else if (item.type === "ip") {
            rule.pattern = /^(((25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9])\.){3}(25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9]))$/;
          } else if (item.type === "domain") {
            rule.pattern = /^([A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*)$/;
          } else if (item.type === "ipdomain") {
            rule.pattern = /^(((25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9])\.){3}(25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|[0-9]))|([A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*)$/;
          } else if (item.type === "carNo") {
            rule.pattern = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳]{1}$/;
            if (this.form[id].length === 8) {
              rule.pattern = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}(([0-9]{5}[DF]$)|([DF][A-HJ-NP-Z0-9][0-9]{4}$))/;
            }
          } else if (item.pattern) {
            rule.pattern = item.pattern;
          } else {
            rule.type = item.type;
          }
          rules.push(rule);
        }
        const hasMin = typeof item.min !== "undefined";
        const hasMax = typeof item.max !== "undefined";
        if ((hasMin || hasMax) && !item.integer) {
          const rule = {
            type: item.type || "string",
            trigger
          };
          if (hasMin && !hasMax) {
            rule.min = item.min;
            rule.message = name + this.$t('_tm.rules.message_22') + item.min;
          } else if (hasMax && !hasMin) {
            rule.max = item.max;
            rule.message = name + this.$t('_tm.rules.message_23') + item.max;
          } else {
            rule.min = item.min;
            rule.max = item.max;
            rule.message = name + this.$t('_tm.rules.message_24') + item.min + "~" + item.max;
          }
          if (isRange) {
            if (id === item.id[1]) {
              rule.min = this.form[item.id[0]];
              rule.message = name + this.$t('_tm.rules.message_22') + rule.min;
            }
          }
          rules.push(rule);
        }
      } else {
        if (this.form[id] === "") {
          this.params.clearValidate(id);
        }
      }
      // console.log(rules);
      // item._rules = rules;
      return rules.length ? rules : null;
    },
    ifShow(item) {
      return (
        typeof item.show === "undefined" ||
        (item.show &&
          item.show(
            this.mode || this.params.type,
            this.form,
            this.params.copy || this.params.data
          ))
      );
    },
    readonly(func) {
      return (
        this.params.type === "detail" ||
        (typeof func === "function" ? func(this.params.type) : !!func)
      );
    },
    change(v, item) {
      const { change, id } = item;
      if (typeof change === "function") {
        const key = change(v);
        if (typeof key === "string") {
          if (
            id &&
            (id === this.params.modeKey || !this.params.modeKey) &&
            key &&
            this.form[key]
          ) {
            this.form[key] = "";
          }
        } else if (typeof key === "object" && key.key) {
          if (typeof key.value !== "undefined") {
            this.params.setItemData(key.key, key.value);
          } else if (Array.isArray(key.select)) {
            this.params.setItemData(key.key, "");
            this.params.setItemSelect(key.key, key.select);
          }
        }
      }
    },
    eventCall(item, evt) {
      const eventCall = item[evt];
      if (typeof eventCall === "function") {
        eventCall();
      }
    },

    updateForm(data, key) {
      if (Array.isArray(data) && key === 'coord') {
        this.$set(this.form, 'lng', data[0])
        this.$set(this.form, 'lat', data[1])
      } else {
        this.$set(this.form, key, data)
      }
    },

    clearFiles() {
      const upload = this.$refs.upload;
      upload && upload.clearFiles();
    }
  },

  created() {
  },

  mounted() {
    this.$bus.$on('updateForm', this.updateForm)
  },
 
  destroyed() {
    this.$bus.$off('updateForm')
  },
};
</script>

<style lang="scss" scoped>
::v-deep .image-slot {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background: #f5f7fa;
  color: #909399;
  font-size: 24px;
}
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

::v-deep .el-form-item__error {
  height: 36px;
}
</style>
