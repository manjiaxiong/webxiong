<template>
  <el-form
    class="v-form"
    ref="form"
    :inline="inline"
    :model="form"
    :rules="rules"
    :size="size"
    :label-width="labelWidth"
    :disabled="disabled"
  >
    <template v-if="options.length && options[0].items">
      <el-tabs class="v-tabs" v-if="params.groupType === 'tab'" :class="wrapperClass" value="0">
        <el-tab-pane
          :key="key"
          :label="item.name"
          :name="key.toString()"
          v-for="(item, key) in options"
        >
          <item
            :key="key"
            v-for="(item, key) in item.items"
            :item="item"
            :form="form"
            :params="getItemParams(item)"
          ></item>
        </el-tab-pane>
      </el-tabs>
      <el-collapse v-else class="v-collapse" :class="wrapperClass" :value="0">
        <el-collapse-item :key="key" :title="item.name" :name="key" v-for="(item, key) in options">
          <item
            :key="key"
            v-for="(item, key) in item.items"
            :item="item"
            :form="form"
            :params="getItemParams(item)"
          ></item>
        </el-collapse-item>
      </el-collapse>
    </template>

    <div v-else :class="['form-item-wrapper', 'grid' + (params.grid || 1)]">
      <item
        :ref="item.upload ? 'upload' : item.id"
        :key="key"
        v-for="(item, key) in options"
        :item="item"
        :form="form"
        :params="getItemParams(item)"
      ></item>
    </div>
    <slot></slot>
  </el-form>
</template>

<script>
import Item from "./item";
export default {
  name: "v-form",
  components: {
    Item
  },
  props: {
    options: {
      type: Array,
      default: []
    },
    labelWidth: {
      type: String,
      default: "100px"
    },
    rules: {
      type: Object,
      default: null
    },
    inline: {
      type: Boolean,
      default: false
    },
    size: {
      type: String,
      default: "medium"
    },
    params: {
      type: Object,
      default: () => ({})
      // 内置属性 copy data modeKey type grid groupType
    }
  },
  computed: {
    disabled() {
      return this.params.type === "detail";
    },
    wrapperClass() {
      return ["v-wrappers", "grid" + (this.params.grid || 1)];
    }
  },
  data() {
    return {
      form: {},
      select: {}
    };
  },
  methods: {
    getItemParams(item) {
      if (item.select && item.id) {
        if (!this.select[item.id]) {
          this.select[item.id] = item;
        }
        // console.log(item);
      }
      return {
        copy: this.params.copy,
        data: this.params.data,
        modeKey: this.params.modeKey,
        type: this.params.type,
        setItemData: this.setItemData,
        clearValidate: this.clearValidate,
        setItemSelect: this.setItemSelect
      };
    },
    validate(callback) {
      return this.$refs.form.validate(callback);
    },
    clearValidate() {
      this.$refs.form.clearValidate();
    },
    reset() {
      this.form = {};
      this.delay(100).then(() => {
        this.clearValidate();
        this.clearFiles();
      });
    },
    setData(item, id, v) {
      if (typeof item[id] !== "undefined") {
        let data = item[id];
        if (v && typeof v.render === "function") {
          data = v.render(data);
        }
        // 强制校验select无此数据，不显示原始值
        if (v.select && !v.remote && !v.multiple) {
          let options = v.select;
          if (typeof options === "function") {
            options = v.select();
          }
          if (Array.isArray(options) && options.length) {
            if (!options.find(vv => vv[v.valueKey || 'id'] == data)) {
              return;
            }
          }
        }
        // console.log(id, data, typeof data);
        this.setItemData(id, data);
      }
    },
    setItemData(id, data) {
      this.$set(this.form, id, data);
    },
    setItemSelect(id, data) {
      if (this.select[id]) {
        this.select[id].select = data;
      }
    },
    initData(v) {
      if (typeof v.default !== "undefined" && v.default !== null) {
        this.setItemData(
          v.id,
          typeof v.default === "function" ? v.default() : v.default
        );
      }
      const item = this.params.copy || this.params.data;
      if (item && this.params.type !== "add") {
        if (Array.isArray(v.id)) {
          v.id.forEach(val => {
            this.setData(item, val, v);
          });
        } else if (typeof v.id === "string") {
          this.setData(item, v.id, v);
        }
      }
    },
    init() {
      this.options.forEach(v => {
        if (v.items) {
          v.items.forEach(v => {
            this.initData(v);
          });
        } else {
          this.initData(v);
        }
      });
    },
    getParams() {
      this.options.filter(v => typeof v.format === "function").forEach(v => {
        const value = v.format(this.form[v.id]);
        this.form[v.id] = value;
      });
      return this.form;
    },

    clearFiles() {
      const upload = this.$refs.upload;
      // v-for 中的ref 返回数组
      Array.isArray(upload) && upload[0].clearFiles();
    },
  }
};
</script>

<style lang="scss" scoped>
.v-form {
  user-select: none;
  ::v-deep .el-input.is-disabled .el-input__inner {
    color: #666;
  }
  .v-collapse {
    margin-bottom: 20px;
    ::v-deep .el-collapse-item__header {
      padding-left: 10px;
    }
    ::v-deep .el-collapse-item__content {
      padding-right: 20px;
      overflow: hidden;
    }
  }
  .v-tabs {
    margin-bottom: 10px;
    ::v-deep .el-tabs__header {
      margin-bottom: 25px;
    }
    ::v-deep .el-tabs__content {
      padding-right: 20px;
    }
  }
  &.el-form--inline {
    ::v-deep .form-item {
      display: inline-block;
    }
  }
  .v-wrappers {
    .form-item {
      display: inline-block;
      width: 100%;
    }

    &.grid2 {
      .form-item {
        width: 50%;
        float: left;
      }
    }

    &.grid3 {
     .form-item {
        width: 33.3%;
        float: left;
      }
    }
  }
  .form-item-wrapper {
    padding: 10px;
    padding-bottom: 0;
    padding-right: 15px;
    margin-bottom: 10px;
    max-height: 420px;
    overflow: auto;

    &.grid2 {
      columns: 2;
      max-height: none;
    }

    &.grid3 {
      columns: 3;
      max-height: none;

      .form-item {
        display: inline-block;
      }
    }
  }
  ::v-deep .range-input-wrapper {
    display: flex;
    .el-form-item__content {
      margin-left: 0 !important;
    }
    > span {
      padding: 0 10px;
      display: flex;
      align-items: center;
      margin-bottom: 22px;
    }
  }
  .v-slider {
    margin-left: 8px;
    margin-right: 8px;
  }
}
</style>
