<template>
  <div class="tm-table-warp">
    <slot name="search" :search="fetchHandler">
      <search-form
        v-if="formOptions"
        ref="searchForm"
        :forms="formOptions.forms"
        :size="formOptions.size"
        :fuzzy="formOptions.fuzzy"
        :inline="formOptions.inline"
        :label-width="formOptions.labelWidth"
        :item-width="formOptions.itemWidth"
        :submit-handler="searchHandler"
        :submit-loading="loading"
        :showSearchBtn="formOptions.showSearchBtn"
        :showResetBtn="formOptions.showResetBtn"
        :submitBtnText="formOptions.submitBtnText"
        :resetBtnText="formOptions.resetBtnText"
        :baseURL="baseURL"
      >
        <template
          v-for="form in formOptions.forms.filter(it => it.itemType === 'slot')"
          v-slot:[form.slotName]="{ params }"
        >
          <slot :name="form.slotName" :params="params"></slot>
        </template>
        <template #buttons>
          <slot name="buttons"></slot>
        </template>
        <template #buttons-right>
          <slot name="buttons-right"></slot>
        </template>
      </search-form>
    </slot>

    <slot name="prependView"></slot>

    <slot
      name="form"
      :loading="loading"
      :search="searchHandler"
      :resetCurPageData="resetCurPageData"
      :data="tableData"
    />
    <slot />

    <template v-if="view">
      <div class="wrapper" v-if="view === 'table'" v-loading.lock="loading">
        <slot
          v-if="tableData && tableData.length"
          :name="view"
          :data="tableData"
        ></slot>
        <div v-else class="empty">
          <i class="iconfont">&#xe651;</i>
          <p>{{$t('_tm.table.noData')}}</p>
        </div>
      </div>
      <div class="wrapper" v-else v-loading.lock="loading">
        <slot v-if="fetchData" :name="view" :data="fetchData"></slot>
        <div v-else class="empty">
          <i class="iconfont">&#xe651;</i>
          <p>{{$t('_tm.table.noData')}}</p>
        </div>
      </div>
    </template>
    <div class="wrapper" v-else v-loading.lock="loading">
      <el-table
        ref="table"
        :data="tableData"
        :border="border"
        :stripe="stripe"
        :height="height"
        :max-height="maxHeight"
        :fit="fit"
        :size="size"
        :show-header="showHeader"
        :highlight-current-row="highlightCurrentRow"
        :current-row-key="currentRowKey"
        :row-class-name="rowClassName"
        :row-style="rowStyle"
        :cell-style="cellStyle"
        :row-key="rowKey"
        :empty-text="emptyText"
        :default-expand-all="defaultExpandAll"
        :expand-row-keys="expandRowKeys"
        :default-sort="defaultSort"
        :tooltip-effect="tooltipEffect"
        :show-summary="showSummary"
        :sum-text="sumText"
        :summary-method="summaryMethod"
        style="width: 100%; margin-top: 20px"
        @select="(selection, row) => emitEventHandler('select', selection, row)"
        @select-all="selection => emitEventHandler('select-all', selection)"
        @selection-change="
          selection => emitEventHandler('selection-change', selection)
        "
        @cell-mouse-enter="
          (row, column, cell, event) =>
            emitEventHandler('cell-mouse-enter', row, column, cell, event)
        "
        @cell-mouse-leave="
          (row, column, cell, event) =>
            emitEventHandler('cell-mouse-leave', row, column, cell, event)
        "
        @cell-click="
          (row, column, cell, event) =>
            emitEventHandler('cell-click', row, column, cell, event)
        "
        @cell-dblclick="
          (row, column, cell, event) =>
            emitEventHandler('cell-dblclick', row, column, cell, event)
        "
        @row-click="
          (row, column, event) =>
            emitEventHandler('row-click', row, column, event)
        "
        @row-dblclick="
          (row, event) => emitEventHandler('row-dblclick', row, event)
        "
        @row-contextmenu="
          (row, event) => emitEventHandler('row-contextmenu', row, event)
        "
        @header-click="
          (column, event) => emitEventHandler('header-click', column, event)
        "
        @sort-change="args => emitEventHandler('sort-change', args)"
        @filter-change="filters => emitEventHandler('filter-change', filters)"
        @current-change="
          (currentRow, oldCurrentRow) =>
            emitEventHandler('current-change', currentRow, oldCurrentRow)
        "
        @header-dragend="
          (newWidth, oldWidth, column, event) =>
            emitEventHandler(
              'header-dragend',
              newWidth,
              oldWidth,
              column,
              event
            )
        "
        @expand-change="
          (row, expanded) => emitEventHandler('expand-change', row, expanded)
        "
      >
        <slot name="prepend" />
        <el-table-column
          v-if="showOrderNo"
          type="index"
          :label="$t('_tm.table.columns.seq')"
          :width="orderNoWidth"
          header-align="center"
          align="center"
          :index="formatIndex"
        ></el-table-column>
        <template
          v-for="(column, columnIndex) in typeof columns === 'function'
            ? columns()
            : columns || []"
        >
          <el-table-column
            v-if="ifShow(column)"
            :key="columnIndex"
            :column-key="column.columnKey"
            :prop="column.prop"
            :label="column.label"
            :width="column.minWidth ? '-' : column.width || '-'"
            :min-width="
              column.minWidth || column.label
                ? 16 * (column.label.length + 1)
                : 80
            "
            :fixed="column.fixed"
            :render-header="column.renderHeader"
            :sortable="column.sortable"
            :sort-method="column.method"
            :resizable="column.resizable"
            :formatter="column.formatter"
            :show-overflow-tooltip="column.showOverflowTooltip"
            :align="column.align || align"
            :header-align="column.headerAlign || column.align || align"
            :class-name="column.className"
            :label-class-name="column.labelClassName"
            :selectable="column.selectable"
            :reserve-selection="column.reserveSelection"
            :filters="column.filters"
            :filter-placement="column.filterPlacement"
            :filter-multiple="column.filterMultiple"
            :filter-method="column.filterMethod"
            :filtered-value="column.filteredValue"
          >
            <template slot="header" slot-scope="scope">{{
              scope.column.label
            }}</template>
            <template
              slot-scope="scope"
              :scope="newSlotScope ? 'scope' : false"
            >
              <span v-if="column.filter">
                {{ Vue.filter(column["filter"])(scope.row[column.prop]) }}
              </span>
              <span v-else-if="column.slotName">
                <slot
                  :name="column.slotName"
                  :row="scope.row"
                  :column="column"
                  :$index="scope.$index"
                />
              </span>
              <span v-else>
                {{
                  column.render
                    ? column.render(scope.row, scope.row[column.prop])
                    : scope.row[column.prop]
                }}
              </span>
            </template>
          </el-table-column>
        </template>

        <template>
          <slot name="column"></slot>
        </template>

        <slot name="append" />
      </el-table>
    </div>

    <div v-if="showPagination" style="margin-top: 10px; text-align: right">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :background="paginationBackground"
        :current-page="pagination.pageIndex"
        :page-sizes="pageSizes"
        :page-size="pagination.pageSize"
        :layout="paginationLayout"
        :total="total"
      ></el-pagination>
    </div>
  </div>
</template>
<style lang="scss">
.empty {
  user-select: none;
  text-align: center;
  padding-top: 150px;
  padding-bottom: 150px;

  i {
    font-size: 48px;
    color: #999;
  }
  p {
    color: #666;
  }
}
// TODO
// 如果样式有问题，并且项目对下面的样式有依赖，请把下面的样式代码移到自己的项目，防止样式污染
// .tm-table-warp {
//   > .el-form--inline {
//     margin-right: 20px;
//     .el-form-item {
//       margin-right: 15px;
//     }
//   }
//   .el-table tr td .cell {
//     padding: 5px 2px !important;
//   }

//   .el-table .cell,
//   .el-table th div,
//   .el-table--border td:first-child .cell,
//   .el-table--border th:first-child .cell {
//     padding: 0 !important;
//     vertical-align: middle;
//     line-height: 20px;
//   }
// }
</style>

<script>
import Vue from "vue";
import props from "./props";
import axios from "../../utils/request";

import SearchForm from "./search";

// 判断对象是否为空
if (!Object.isEmpty) {
  Object.isEmpty = obj => {
    return !obj || (obj && Object.keys(obj).length === 0);
  };
}

export default {
  name: "tm-table",
  components: {
    SearchForm
  },
  props,
  data() {
    const _this = this;
    return {
      Vue,
      pagination: {
        pageIndex: 1,
        pageSize: (() => {
          const { pageSizes } = _this;
          if (pageSizes.length > 0) {
            return pageSizes[0];
          }
          return 20;
        })()
      },
      total: 0,
      loading: false,
      tableData: [],
      fetchData: null,
      cacheLocalData: [],
      searchParams: null,
    };
  },
  computed: {
    newSlotScope() {
      return Number(Vue.version.replace(/\./g, "")) >= 250;
    }
  },
  methods: {
    formatIndex(index) {
      if (this.indexIncrease) {
        return (
          index + 1 + (this.pagination.pageIndex - 1) * this.pagination.pageSize
        );
      }
      return index + 1;
    },
    ifShow(item) {
      return typeof item.show === "undefined" || (item.show && item.show());
    },
    labelHead(h, { column, index }) {
      let l = column.label.length;
      let f = 16; //每个字大小，其实是每个字的比例值，大概会比字体大小差不多大一点，
      column.minWidth = f * (l + 1); //字大小乘个数即长度 ,注意不要加px像素，这里minWidth只是一个比例值，不是真正的长度
      //然后将列标题放在一个div块中，注意块的宽度一定要100%，否则表格显示不完全
      return h(
        "div",
        {
          class: "table-head",
          style: {
            width: "100%"
          }
        },
        [column.label]
      );
    },
    handleSizeChange(size) {
      this.pagination.pageSize = size;
      this.pagination.pageIndex = 1; // 需要把页码重置到第一页，不然有偶发性bug
      this.dataChangeHandler();
    },
    handleCurrentChange(pageIndex) {
      this.pagination.pageIndex = pageIndex;
      this.dataChangeHandler();
    },
    // 刷新当前页数据方法 (李拓)
    resetCurPageData(page) {
      this.pagination.pageIndex = page;
      this.dataChangeHandler(arguments[0]);
    },
    getCurrentPage(){
      return this.pagination.pageIndex;
    },
    searchHandler(resetPageIndex = true) {
      if (resetPageIndex) {
        this.pagination.pageIndex = 1;
      }
      this.dataChangeHandler(arguments[0]);
    },
    dataChangeHandler() {
      let { type, params, formOptions } = this;
      let args = arguments[0];
      if (type === "local") {
        this.dataFilterHandler(args);
      } else if (type === "remote") {
        if (formOptions) {
          Object.keys(params).forEach(k => {
            if (typeof params[k] === "function") {
              params[k] = params[k](args[k]);
            }
          });
          if (args) {
            this.fetchHandler(Object.assign(args, params));
          } else if (this.$refs["searchForm"]) {
            this.$refs["searchForm"].getParams((error, formParams) => {
              if (!error) {
                // TODO
                this.fetchHandler(Object.assign(formParams, params));
              }
            });
          }
        } else {
          this.fetchHandler(Object.assign(args || {}, params || {}));
        }
      }
    },
    dataFilter(data) {
      const { pageIndex, pageSize } = this.pagination;
      return data.filter((v, i) => {
        return i >= (pageIndex - 1) * pageSize && i < pageIndex * pageSize;
      });
    },
    getTableData() {
      return this.tableData;
    },
    getTableREF() {
      return this.$refs.table;
    },
    dataFilterHandler(formParams) {
      const { cacheLocalData, params } = this;
      const mergeParams = Object.assign(params, formParams);
      const validParamKeys = Object.keys(mergeParams).filter(v => {
        return mergeParams[v] !== undefined && mergeParams[v] !== "";
      });
      const searchForm = this.$refs["searchForm"];
      let paramFuzzy;
      if (searchForm) {
        paramFuzzy = searchForm.getParamFuzzy();
      }

      if (validParamKeys.length > 0) {
        const validData = cacheLocalData.filter(v => {
          let valids = [];
          validParamKeys.forEach(vv => {
            if (typeof v[vv] === "number") {
              valids.push(
                paramFuzzy && paramFuzzy[vv]
                  ? String(v[vv]).indexOf(String(mergeParams[vv])) !== -1
                  : String(v[vv]) === String(mergeParams[vv])
              );
            } else {
              valids.push(
                paramFuzzy && paramFuzzy[vv]
                  ? v[vv].indexOf(mergeParams[vv]) !== -1
                  : v[vv] === mergeParams[vv]
              );
            }
          });
          return valids.every(vvv => {
            return vvv;
          });
        });

        this.tableData = this.dataFilter(validData);
        this.total = validData.length;
      } else {
        this.total = cacheLocalData.length;
        this.tableData = this.dataFilter(cacheLocalData);
      }
    },
    fetchHandler(formParams = {}) {
      this.loading = true;
      let {
        fetch,
        method,
        url,
        baseURL,
        // eslint-disable-next-line
        headers,
        // eslint-disable-next-line
        listField,
        // eslint-disable-next-line
        pageIndexKey,
        // eslint-disable-next-line
        pageSizeKey,
        totalField,
        showPagination,
        pagination,
        paginationType,
        paramsFormatter,
        formOptions,
      } = this;
      // 当动态设置查询条件时, forms可能为[]
      if (Object.isEmpty(formParams) && formOptions && formOptions.forms.length) {
        formParams = this.getSearchParams();
        if (showPagination) {
          if (Object.isEmpty(formParams) && !this.autoLoad) {
            if (pagination.pageSize > 0) {
              this.loading = false;
              return false;
            }
          }
        }
      } else {
        if (!formParams.remove) {
          if (formParams.resetPageIndex) {
            this.pagination.pageIndex = 1;
          }
          this.setSearchParams(formParams);
        }
      }
      // 合并了 table.params
      var params = Object.assign({}, this.params, formParams);
      if (params.remove) {
        params = this.getSearchParams();
        pagination.pageIndex = 1;
        delete params.remove;
      }
      if (showPagination) {
        if (paginationType === "url") {
          url += "/" + pagination.pageIndex + "/" + pagination.pageSize;
        } else if (paginationType === "urlParams") {
          url +=
            "/" +
            [
              pageIndexKey,
              pagination.pageIndex,
              pageSizeKey,
              pagination.pageSize
            ].join("/");
        } else {
          params = Object.assign(params, {
            [pageIndexKey]: pagination.pageIndex,
            [pageSizeKey]: pagination.pageSize
          });
        }
      }
      if (typeof paramsFormatter === "function") {
        params = paramsFormatter(params);
      }
      this.$emit("onSearch", params);
      let requestObject = null;
      if (fetch) {
        requestObject = fetch(params);
      } else {
        method = method.toLowerCase();
        if (method === "get") {
          let config = {
            params
          };
          if (baseURL) {
            config.baseURL = baseURL;
          }
          requestObject = axios[method](url, config);
        } else {
          requestObject = axios[method](url, params);
        }
      }

      requestObject
        .then(response => {
          // 为什么加入强制转化对象，如果是树形数据会有bug
          // let result = Object.assign({}, response);
          let result = response;
          if (this.view) {
            this.fetchData = result;
          }
          if (response && !(response instanceof Array)) {
            if (listField && listField.indexOf(".") !== -1) {
              listField.split(".").forEach(vv => {
                result = result[vv] || [];
              });
            } else {
              result = response[listField] || [];
            }
          }

          if (!result || !(result instanceof Array)) {
            throw new Error(`The result of key:${listField} is not Array.`);
            // eslint-disable-next-line
            this.loading = false;
            return false;
          }
          if (this.dataHandler) {
            this.tableData = result.map(this.dataHandler);
          } else {
            if (this.dataFormatter) {
              this.tableData = this.dataFormatter(result);
            } else {
              this.tableData = result;
            }
          }
          if (this.$listeners && this.$listeners.onSuccess) {
            // 接口调用成功事件回调
            this.$emit("onSuccess", response);
          } else {
            // 兼容旧写法 @compatible
            this.$emit("search-success", response);
          }

          let totalValue = response;
          if (Object.prototype.toString.call(response) === "[object Array]") {
            totalValue = response.length;
          } else if (typeof response === "object") {
            if (totalField && totalField.indexOf(".") !== -1) {
              totalField.split(".").forEach(vv => {
                totalValue = totalValue[vv];
              });
            } else {
              totalValue = response[totalField] || 0;
            }
          } else {
            totalValue = 0;
          }
          this.$emit("onData", totalValue);
          this.total = totalValue;

          this.loading = false;
        })
        // eslint-disable-next-line
        .catch(error => {
          // console.error('Get remote data failed. ', error)
          this.loading = false;
          this.$emit("onError");
        });
    },
    emitEventHandler(event) {
      this.$emit(event, ...Array.from(arguments).slice(1));
    },
    loadLocalData(data) {
      const { autoLoad } = this;
      if (!data) {
        throw new Error(
          `When the type is 'local', you must set attribute 'data' and 'data' must be a array.`
        );
        // eslint-disable-next-line
        this.showPagination = false;
        return false;
      }
      const cacheData = JSON.parse(JSON.stringify(data));
      this.cacheLocalData = cacheData;
      if (autoLoad) {
        this.tableData = this.dataFilter(cacheData);
        this.total = cacheData.length;
      }
    },
    getParams(callback) {
      return this.$refs["searchForm"].getParams(callback);
    },
    getSearchParams() {
      const form = this.$refs["searchForm"];
      if (form) {
        return form.getSearchParams();
      }
      return this.searchParams || {};
    },
    getPageSize() {
      return this.pagination.pageSize;
    },
    getPagination() {
      return this.pagination;
    },
    getPaginationKey() {
      return {
        pageIndexKey: this.pageIndexKey,
        pageSizeKey: this.pageSizeKey
      };
    },
    setSearchParams(params) {
      const form = this.$refs["searchForm"];
      if (params.resetPageIndex) {
        delete params.resetPageIndex;
      }
      if (form) {
        form.setSearchParams(params);
      } else {
        this.searchParams = params;
      }
    },

    getSearchFormHeight() {
      const form = this.$refs.searchForm;
      return form ? form.$el.offsetHeight : 0;
    },

    resetForm() {
      this.$refs.searchForm.resetForm()
    }
  },
  mounted() {
    const $table = this.$refs["table"];
    // event: expand changed to `expand-change` in Element v2.x
    $table &&
      $table.$on("expand", (row, expanded) =>
        this.emitEventHandler("expand", row, expanded)
      );
    const { type, autoLoad, data, formOptions, params } = this;
    if (type === "remote" && autoLoad) {
      var $searchForm = this.$refs["searchForm"];
      var promises = $searchForm ? $searchForm.getPromises() : [];
      if (promises.length > 0) {
        Promise.all(promises).then(() => {
          this.dataChangeHandler();
        });
      } else {
        this.dataChangeHandler();
      }
    } else if (type === "local") {
      this.loadLocalData(data);
    }
  },
  watch: {
    data: function (value) {
      this.loadLocalData(value);
    },
    params: function (params) {
      this.dataChangeHandler();
    }
  }
};
</script>
