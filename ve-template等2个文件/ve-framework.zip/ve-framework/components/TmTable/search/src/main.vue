<template>
  <el-form
    :model="params"
    :inline="inline"
    ref="form"
    @submit.native.prevent="searchHandler()"
    :label-width="labelWidth ? labelWidth + 'px' : ''"
  >
    <template v-for="(form, index) in forms">
      <template v-if="ifShow(form)">
        <div v-if="form.itemType === 'datetimerange2'" :key="index" class="range-datetime-wrapper">
          <el-form-item
            :prop="form.prop[0]"
            :label="form.label"
            :rules="form.required ? [{ required: true, message: $t('_tm.rules.message_16') }] : (form.rules || [])"
            :label-width="form.labelWidth ? form.labelWidth + 'px' : ''"
            :class="form.className || ''"
          >
            <el-date-picker
              v-model="params[form.prop[0]]"
              type="datetime"
              :format="typeof form.format === 'string' ? form.format : null"
              :value-format="form.valueFormat || 'yyyy-MM-dd HH:mm:ss'"
              :placeholder="form.placeholder || $t('_tm.placeholders.message_28')"
              @change="value => verify(value, form)"
              :size="form.size ? form.size : size"
              :disabled="form.disabled"
              :readonly="form.readonly"
              :editable="form.editable"
              :clearable="form.clearable"
              :style="itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')"
              :picker-options="{
                disabledDate(time) {
                  const endDateVal = new Date(params[form.prop[1]]).getTime();
                  if (endDateVal) {
                    const ctime = time.getTime();
                    const valid = ctime > endDateVal;
                    if (form.controlValid && form.dayRange && form.dayRange > 0) {
                      return valid || ctime < endDateVal - (86400000 * (form.dayRange + 1));
                    }
                    return valid;
                  }
                }
              }"
            />
          </el-form-item>
          <span class="range-text">-</span>
          <el-form-item
            :prop="form.prop[1]"
            :rules="form.required ? [{ required: true, message: $t('_tm.rules.message_15') }] : (form.rules || [])"
            :label-width="form.labelWidth ? form.labelWidth + 'px' : ''"
            :class="form.className || ''"
          >
            <el-date-picker
              v-model="params[form.prop[1]]"
              type="datetime"
              :format="typeof form.format === 'string' ? form.format : null"
              :value-format="form.valueFormat || 'yyyy-MM-dd HH:mm:ss'"
              :placeholder="form.placeholder || $t('_tm.placeholders.message_29')"
              @change="value => verify(value, form)"
              :size="form.size ? form.size : size"
              :disabled="form.disabled"
              :readonly="form.readonly"
              :editable="form.editable"
              :clearable="form.clearable"
              :style="itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')"
              :picker-options="{
                disabledDate(time) {
                  const beginDateVal = new Date(params[form.prop[0]]).getTime();
                  if (beginDateVal) {
                    const ctime = time.getTime();
                    const valid = ctime < beginDateVal - 86300000;
                    if (form.controlValid && form.dayRange && form.dayRange > 0) {
                      return valid || ctime > beginDateVal + (86400000 * (form.dayRange));
                    }
                    return valid;
                  }
                }
              }"
            />
          </el-form-item>
        </div>
        <el-form-item
          v-else
          :key="index"
          :prop="
          !['daterange', 'datetimerange', 'monthrange', 'timerange'].includes(
            form.itemType
          )
            ? form.prop
            : datePrefix + index
        "
          :label="form.label"
          :rules="form.rules || []"
          :label-width="form.labelWidth ? form.labelWidth + 'px' : ''"
          :class="form.className || ''"
        >
          <el-input
            v-if="form.itemType === 'input' || form.itemType === undefined"
            v-model.trim="params[form.modelValue]"
            :size="form.size ? form.size : size"
            :readonly="form.readonly"
            :disabled="form.disabled"
            :placeholder="form.placeholder"
            :clearable="form.clearable"
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')
          "
          />
          <el-input
            v-if="form.itemType === 'number'"
            v-model.number="params[form.modelValue]"
            :size="form.size ? form.size : size"
            :readonly="form.readonly"
            :disabled="form.disabled"
            :placeholder="form.placeholder"
            :clearable="form.clearable"
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')
          "
          />
          <template v-else-if="form.itemType === 'slot'">
            <slot :name="form.slotName" :params="params"></slot>
          </template>
          <!-- cascader START -->
          <el-cascader
            v-else-if="form.itemType === 'cascader'"
            v-model="params[form.modelValue]"
            :options="form.options"
            :props="form.props"
            :size="form.size ? form.size : size"
            :placeholder="form.placeholder"
            :disabled="form.disabled"
            :clearable="form.clearable"
            :show-all-levels="form.showAllLevels || false"
            :collapse-tags="form.collapseTags || true"
            :separator="form.separator"
            :filterable="form.filterable"
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')"
            @change="value => cascaderChange(value, form)"
          ></el-cascader>
          <!-- END -->
          <el-select
            :ref="form.prop"
            v-else-if="form.itemType === 'select'"
            v-model="params[form.modelValue]"
            :size="form.size ? form.size : size"
            :disabled="form.disabled"
            :placeholder="form.placeholder"
            :clearable="form.clearable"
            :remote="form.remote"
            :remote-method="form.remoteMethod"
            :loading="form.loading"
            :filterable="form.filterable"
            :allow-create="form.allowCreate"
            :filter-method="form.filterMethod ? value => form.filterMethod(value, form):
            (form.selectUrl || form.selectFetch) && form.maxNum
              ? value => filterSelect(value, form)
              : null
          "
            :multiple="form.multiple"
            :collapse-tags="form.collapseTags"
            @change="value => changeSelect(value, form)"
            @clear="filterSelect('', form)"
            @visible-change="value => visibleChange(value, form)"
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')
          "
          >
            <el-option
              v-for="(option, optionIndex) in typeof form.options === 'function'
              ? form.options()
              : form.options"
              :key="optionIndex + '_local'"
              :value="
              typeof option === 'object'
                ? option[form.valueKey || 'value']
                : option
            "
              :label="
              typeof option === 'object'
                ? option[form.labelKey || 'label']
                : option
            "
            >
              <span v-if="form.showTips">
                {{
                option[form.labelKey || "label"]
                }}
              </span>
              <span
                v-if="form.showTips"
                style="float: right; color: #aaa; font-size: 12px"
              >{{ option[form.tipsKey || form.valueKey || "value"] }}</span>
            </el-option>
            <el-option
              v-for="(op, opIndex) in selectOptions[selectOptionPrefix + index]"
              :key="opIndex + '_remote'"
              :value="typeof op === 'object' ? op[form.valueKey || 'value'] : op"
              :label="typeof op === 'object' ? op[form.labelKey || 'label'] : op"
            />
          </el-select>
          <el-radio-group
            v-else-if="form.itemType === 'radioGroup'"
            v-model="params[form.modelValue]"
            :disabled="form.disabled"
          >
            <el-radio
              :key="key"
              v-for="(item, key) in form.options"
              :label="item.value"
            >{{ item.label }}</el-radio>
          </el-radio-group>
          <!-- TODO：日期控件有待优化，分为两大类，单选和range -->
          <el-date-picker
            v-else-if="['date', 'datetime', 'month'].includes(form.itemType)"
            :ref="form.prop"
            v-model="params[form.modelValue]"
            :type="form.itemType"
            :format="typeof form.format === 'string' ? form.format : null"
            :value-format="
            form.valueFormat ||
              (form.itemType === 'datetime'
                ? 'yyyy-MM-dd HH:mm:ss'
                : form.itemType === 'date'
                ? 'yyyy-MM-dd'
                : 'yyyy-MM')
          "
            :placeholder="form.placeholder || $t('_tm.placeholders.message_27')"
            @change="value => verify(value, form)"
            :size="form.size ? form.size : size"
            :disabled="form.disabled"
            :readonly="form.readonly"
            :editable="form.editable"
            :clearable="form.clearable"
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')
          "
            :picker-options="
            typeof form.pickerOptions === 'function'
              ? form.pickerOptions(params)
              : form.pickerOptions || {}
          "
          />

          <el-time-picker
            v-else-if="['timerange'].includes(form.itemType)"
            is-range
            v-model="params[form.modelValue]"
            value-format="HH:mm:ss"
            range-separator="至"
            :start-placeholder="$t('_tm.placeholders.message_28')"
            :end-placeholder="$t('_tm.placeholders.message_29')"
            :placeholder="$t('_tm.placeholders.message_30')"
            @change="date => changeDate(date, form.prop[0], form.prop[1])"
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')
          "
          ></el-time-picker>

          <el-date-picker
            v-else-if="
            ['daterange', 'datetimerange', 'monthrange'].includes(form.itemType)
          "
            :ref="form.prop"
            v-model="params[form.modelValue]"
            :unlink-panels="form.unlinkPanels"
            :size="form.size ? form.size : size"
            :type="form.itemType"
            :format="typeof form.format === 'string' ? form.format : null"
            :value-format="
            form.valueFormat ||
              (form.itemType === 'datetimerange'
                ? 'yyyy-MM-dd HH:mm:ss'
                : form.itemType === 'daterange'
                ? 'yyyy-MM-dd'
                : 'yyyy-MM')
          "
            :time-arrow-control="true"
            @change="date => changeDate(date, form.prop[0], form.prop[1])"
            @focus="
            () => {
              if (typeof form.focus === 'function') {
                form.focus(form);
              }
            }
          "
            @blur="
            () => {
              if (typeof form.blur === 'function') {
                form.blur(form);
              }
            }
          "
            :clearable="
            typeof form.clearable !== 'undefined'
              ? form.clearable
              : form.dayRange > 0
              ? false
              : true
          "
            :disabled="form.disabled"
            :range-separator="form.rangeSeparator || '至'"
            :readonly="form.readonly"
            :editable="form.editable"
            :placeholder="form.placeholder"
            :start-placeholder="
            form.startPlaceholder ||
              (form.itemType === 'monthrange' ? $t('_tm.placeholders.message_23') : $t('_tm.placeholders.message_24'))
          "
            :end-placeholder="
            form.endPlaceholder ||
              (form.itemType === 'monthrange' ? $t('_tm.placeholders.message_25') : $t('_tm.placeholders.message_26'))
          "
            :style="
            itemStyle + (form.itemWidth ? `width: ${form.itemWidth}px;` : '')
          "
            :picker-options="form.pickerOptions || {}"
          ></el-date-picker>
        </el-form-item>
      </template>
    </template>

    <el-form-item class="search-button">
      <el-button
        type="primary"
        v-if="showSearchBtn"
        icon="el-icon-search"
        :size="size"
        @click="searchHandler"
        :loading="submitLoading"
      >{{ submitBtnText }}</el-button>
      <el-button
        type="primary"
        :plain="true"
        :size="size"
        v-if="showResetBtn"
        icon="el-icon-refresh"
        @click="resetForm"
        :loading="submitLoading"
      >{{ resetBtnText }}</el-button>
      <slot name="buttons"></slot>
    </el-form-item>
    <el-form-item class="pull-right mx-0">
      <slot name="buttons-right"></slot>
    </el-form-item>
  </el-form>
</template>

<script>
import { formProps } from "./props";
import { format as formatTime, addDays, addHours, minTime } from "date-fns";

const yearMonth = [minTime ? "yyyy" : "YYYY", "MM"].join("-");
const dateFormatString = [yearMonth, minTime ? "dd" : "DD"].join("-");

export default {
  name: "ElSearchForm",
  props: formProps,
  data() {
    const { forms, fuzzy } = this.$props;
    const datePrefix = "daterange-prefix";
    const selectOptionPrefix = "select-option-prefix";
    let dataObj = {
      selectOptions: {},
      selectAllOptions: {}
    };

    let params = {};
    let format = {};
    let fuzzyOps = {};
    let promises = [];

    forms.forEach((v, i) => {
      const propType = typeof v.prop;
      if (propType === "string") {
        v.modelValue = v.prop;
        // TODO 这里用到了两个字段版本： defaultValue  default 暂时两个都有效(default 优先级更高)，后续有待优化
        params[v.prop] = "";
        if (typeof v.defaultValue !== undefined) {
          params[v.prop] = v.defaultValue;
        }
        if (typeof v.default !== "undefined") {
          if (typeof v.default === "function") {
            params[v.prop] = v.default(this, v.prop);
          } else {
            params[v.prop] = v.default;
          }
        }

        fuzzyOps[v.prop] = v.fuzzy ? v.fuzzy : fuzzy;
        if (v.format && typeof v.format === "function") {
          format[v.prop] = v.format;
        }
      } else if (this.isArray(v.prop)) {
        v.prop.forEach((vv, vk) => {
          if (typeof v.default === "function") {
            v.default = v.default();
          }
          if (v.default && v.default.length) {
            params[vv] = v.default[vk] || "";
          } else {
            params[vv] = "";
          }

          if (typeof v.dayRange !== "undefined" && v.dayRange > 0) {
            const rangeDate = this.getDayRange(v.itemType, v.dayRange, v.start);
            params[vv] = rangeDate[vk] || "";
          }

          if (typeof v.format === "function") {
            format[vv] = v.format;
          }

          fuzzyOps[vv] = v.fuzzy ? v.fuzzy : fuzzy;
        });
      }
      if (
        [
          "daterange",
          "datetimerange",
          "datetimerange2",
          "monthrange",
          "timerange"
        ].includes(v.itemType)
      ) {
        // TODO 这里用到了两个字段版本： defaultDateRange  default 暂时两个都有效(default 优先级更高)，后续有待优化
        v.modelValue = datePrefix + i;
        params[v.modelValue] = [];
        if (v.itemType === "timerange") {
          // timerange 类型必须设置默认时间，否则出现不能选择时间Bug
          if (typeof v.defaultDateRange === "undefined") {
            v.defaultDateRange = [
              new Date(2016, 9, 10, 8, 0),
              new Date(2016, 9, 10, 18, 0)
            ];
          }
        }

        if (v.defaultDateRange && v.defaultDateRange.length) {
          const formatString =
            (v.itemType === "timerange" ? "" : dateFormatString + " ") +
            "HH:mm:ss";
          params[v.modelValue] = v.defaultDateRange;
          params[v.prop[0]] = formatTime(v.defaultDateRange[0], formatString);
          params[v.prop[1]] = formatTime(v.defaultDateRange[1], formatString);
        }
        if (typeof v.default !== "undefined") {
          params[v.modelValue] = v.default;
        }
        if (typeof v.dayRange !== "undefined" && v.dayRange > 0) {
          params[v.modelValue] = this.getDayRange(v.itemType, v.dayRange);
          params[datePrefix + "dateProp"] = v.prop;
          params[datePrefix + "dayRange"] = v.dayRange;
          if (v.validate === false) {
            params[datePrefix + "novalidate"] = true;
          }
        }
      }
      if (v.itemType === "select" && (v.selectFetch || v.selectUrl)) {
        if (v.link && v.link.prop && typeof v.link.value !== "undefined") {
          v.modelValue = v.prop + "-linkValue" + v.link.value.toString();
        }
        const dataKey = selectOptionPrefix + i;
        v.dataKey = dataKey; // TODO
        dataObj.selectOptions[dataKey] = [];
        const { $axios } = this;
        if (!v.selectMethod) {
          v.selectMethod = "get";
        }
        let getConfig = {
          params: v.selectParams
        };
        let baseURL = v.baseURL || this.baseURL;
        if (baseURL) {
          getConfig.baseURL = baseURL;
        }
        var promise = this.getRemoteData(
          v.selectFetch
            ? v.selectFetch
            : () => {
                return $axios[v.selectMethod](
                  v.selectUrl,
                  v.selectMethod.toLowerCase() === "get"
                    ? getConfig
                    : v.selectParams
                );
              },
          v
        );
        promises.push(promise);
      }
      if (typeof v.onModel === "function") {
        this.$nextTick(() => {
          v.onModel(this.params);
        });
      }
    });
    return {
      params,
      resetParams: Object.assign({}, params), // 缓存用于重置
      datePrefix,
      selectOptionPrefix,
      ...dataObj,
      format,
      fuzzyOps,
      searchParams: null,
      promises
    };
  },
  computed: {
    itemStyle() {
      const { itemWidth } = this;
      if (itemWidth) {
        return `width: ${itemWidth}px;`;
      }
      return "";
    }
  },
  methods: {
    setFormValue(key, value) {
      if (key) {
        this.params[key] = value;
      }
    },
    closePicker() {
      Object.keys(this.$refs)
        .filter(v => v !== "form")
        .forEach(v => {
          const ref = this.$refs[v].length ? this.$refs[v][0] : this.$refs[v];
          if (ref.handleClose) {
            ref.handleClose();
          }
        });
    },
    ifShow(form) {
      const show =
        form.link &&
        form.link.prop &&
        this.params[form.link.prop] === form.link.value;
      if (show) {
        const modelValue = this.params[form.modelValue];
        if (Array.isArray(form.prop)) {
          const hasFormat = typeof form.format === "function";
          form.prop.forEach((vv, vk) => {
            if (hasFormat) {
              this.format[vv] = form.format;
            }
            if (modelValue && modelValue.length > 1) {
              this.params[vv] = modelValue[vk];
            } else {
              this.params[vv] = "";
            }
          });
        }
      }
      const visible = !form.link || show;
      if (typeof form.prop === "string") {
        this.params[(form.modelValue || form.prop) + "-visible"] = visible;
      } else if (Array.isArray(form.prop)) {
        form.prop.forEach(v => {
          if (typeof this.params[v + "-visible"] === "undefined") {
            this.params[v + "-visible"] = visible;
          }
        });
      }
      return visible;
    },
    getDayRange(type, range, start) {
      const date = start
        ? typeof start === "function"
          ? start()
          : start
        : new Date();
      const formatString =
        type === "monthrange"
          ? yearMonth
          : type === "daterange"
          ? dateFormatString
          : dateFormatString + " HH:mm:ss";
      let startDate = formatTime(addDays(date, -range), formatString);
      if (range > 0 && range < 1) {
        startDate = formatTime(
          addHours(date, Math.round(-24 * range)),
          formatString
        );
      }
      return [startDate, formatTime(date, formatString)];
    },
    changeSelect(value, form) {
      const { target, prop, change } = form;
      form._selectedFlag = true;
      if (typeof change === "function") {
        const propId = change(value, this.params);
        if (typeof propId === "string") {
          this.params[propId] = "";
        } else if (Array.isArray(propId)) {
          propId.forEach(v => {
            this.params[v] = "";
          });
        }
      }
      if (target && target.length > 0) {
        const { forms } = this.$props;
        target.forEach(selectName => {
          var i = forms.findIndex(item => item.prop == selectName);
          var v = forms[i];
          if (v.itemType === "select" && (v.selectFetch || v.selectUrl)) {
            const dataKey = "select-option-prefix" + i;
            v.dataKey = dataKey; // TODO
            if (!v.selectMethod) {
              v.selectMethod = "get";
            }
            v.selectParams = v.selectParams || {};
            v.selectParams[prop] = value;
            // console.log(this.params[v.prop]);
            target.forEach(obj => {
              if (v.selectParams[obj]) {
                v.selectParams[obj] = "";
              }
            });
            // 这里应该加判断条件，如果不是下拉的值，才清空值
            this.params[v.prop] = "";
            let getConfig = {
              params: v.selectParams
            };
            let baseURL = v.baseURL || this.baseURL;
            if (baseURL) {
              getConfig.baseURL = baseURL;
            }
            this.getRemoteData(
              v.selectFetch
                ? v.selectFetch
                : () => {
                    return this.$axios[v.selectMethod](
                      v.selectUrl,
                      v.selectMethod.toLowerCase() === "get"
                        ? getConfig
                        : v.selectParams
                    );
                  },
              v
            );
          }
        });
      }
    },
    // 级联选择器
    cascaderChange(value, form) {
      let { prop, change } = form;
      if (change && typeof change === "function") {
        change(value, prop, form, this.params);
      }
    },
    verify(val, { onBefore, onAfter }) {
      // console.log(val,onBefore,onAfter,'ddddddddddd')
      if (onBefore) {
        // this.params[onBefore] = '2019-07-16 00:36:00'
        if (this.params[onBefore]) {
          let before = this.params[onBefore];
          if (val < before) {
            this.$message.error(this.$t('_tm.messages.tip_33'));
          }
        } else {
          return false;
        }
      }
      if (onAfter) {
        // this.params[onBefore] = '2019-07-16 00:36:00'
        if (this.params[onAfter]) {
          let after = this.params[onAfter];
          if (val > after) {
            this.$message.error(this.$t('_tm.messages.tip_32'));
          }
        } else {
          return false;
        }
      }
    },
    isArray(value) {
      return (
        typeof value === "object" &&
        Object.prototype.toString.call(value) === "[object Array]"
      );
    },
    searchHandler() {
      this.getParams((error, params) => {
        if (!error) {
          const dateProp = this.params[this.datePrefix + "dateProp"];
          const dayRange = this.params[this.datePrefix + "dayRange"];
          const novalidate = this.params[this.datePrefix + "novalidate"];
          if (dateProp && dateProp.length > 1 && dayRange > 0 && !novalidate) {
            const startDate = params[dateProp[0]];
            const endDate = params[dateProp[1]];
            const diff =
              new Date(endDate).getTime() - new Date(startDate).getTime();
            if (diff > dayRange * 86401000) {
              let msg = this.$t('_tm.messages.tip_31') + dayRange + this.$t('_tm.common.day');
              if (dayRange < 1) {
                msg = this.$t('_tm.messages.tip_31') + Math.round(dayRange * 24) + this.$t('_tm.common.hour');
              }
              return this.$message.warning(msg);
            }
          }
          //处理参数是数组的情况，例如select的多选
          for(var key in params){
            if(Array.isArray(params[key])){
              params[key]=params[key].length>0?params[key].join(","):"";
            }
          }
          const { submitHandler } = this;
          if (submitHandler) {
            submitHandler(params);
          } else {
            throw new Error("Need to set attribute: submitHandler !");
          }
        }
      });
    },
    getParamFuzzy() {
      return this.fuzzyOps;
    },
    getPromises() {
      return this.promises;
    },
    getSearchParams() {
      return this.searchParams;
    },
    setSearchParams(params) {
      this.searchParams = params;
    },
    getParams(callback) {
      this.$refs["form"].validate(valid => {
        if (valid) {
          const { params, datePrefix, format } = this;
          let formattedForm = {};
          Object.keys(params).forEach(v => {
            if (v.indexOf(datePrefix) === -1 && params[v + "-visible"]) {
              let key = v;
              if (v.indexOf("-linkValue") > -1) {
                key = v.split("-")[0];
              }
              formattedForm[key] =
                typeof format[v] === "function"
                  ? format[v](params[v], v)
                  : typeof params[v] === "undefined"
                  ? ""
                  : params[v]; // 默认没值为空字符串
            }
          });
          if (callback) callback(null, formattedForm);
        } else {
          if (callback) callback(new Error());
        }
      });
    },
    resetForm() {
      this.$refs["form"].resetFields();
      // 重置时，不仅需要重置Form，还需要重置params
      this.params = Object.assign({}, this.resetParams);
    },
    changeDate(date, startDate, endDate) {
      if (date === null) {
        this.params[startDate] = "";
        this.params[endDate] = "";
        return;
      }
      if (typeof date === "string") {
        date = date.split(" - ");
      }
      if (startDate && endDate && date && date.length > 1) {
        this.params[startDate] = date[0];
        this.params[endDate] = date[1];
      }
    },
    // eslint-disable-next-line
    getRemoteData(fetch, form) {
      const {
        dataKey,
        selectResultField = "result",
        selectResultHandler,
        maxNum = 0,
        prop,
        modelValue,
        valueKey,
        onData,
        firstSelected,
        link
      } = form;
      return fetch()
        .then(response => {
          if (typeof response === "string") {
            response = [];
          }
          let result = response;
          if (typeof response === "object" && !this.isArray(response)) {
            result = response[selectResultField] || [];
          }
          if (!result || !(result instanceof Array)) {
            console.warn(
              `The result of key:${selectResultField} is not Array. 接口返回的字段:${selectResultField} 不是一个数组`
            );
          }
          if (firstSelected && result.length) {
            this.$set(this.params, modelValue, result[0][valueKey]);
          }
          var selectData = [];
          if (selectResultHandler) {
            selectData = result.map(selectResultHandler);
          } else {
            selectData = result;
          }
          this.selectAllOptions[dataKey] = [...selectData];
          if (maxNum) {
            selectData = selectData.slice(0, maxNum);
          }
          var selectedOption = selectData.filter(item => {
            return item.selected === true;
          });
          if (selectedOption.length > 0) {
            this.params[prop] = selectedOption[0][valueKey];
          }
          this.selectOptions[dataKey] = selectData;
          if (typeof onData === "function") {
            onData(Object.clone(this.selectOptions[dataKey]), this.params);
          }
        })
        .catch(err => {});
    },
    // 重新请求下拉的数据
    handleSelectRequest(selectNameArray = []) {
      const { forms } = this.$props; //主页的配置文件
      forms.forEach((v, i) => {
        if (
          v.itemType === "select" &&
          (v.selectFetch || v.selectUrl) &&
          selectNameArray.indexOf(v.prop) != -1
        ) {
          const dataKey = this.selectOptionPrefix + i;
          v.dataKey = dataKey;
          // 置空select的输入框 - 不用置空
          // this.params[v.modelValue] = "";
          // this.selectOptions[dataKey] = [];
          const { $axios } = this;
          if (!v.selectMethod) {
            v.selectMethod = "get";
          }
          let getConfig = {
            params: v.selectParams
          };
          let baseURL = v.baseURL || this.baseURL;
          if (baseURL) {
            getConfig.baseURL = baseURL;
          }
          this.getRemoteData(
            v.selectFetch
              ? v.selectFetch
              : () => {
                  return $axios[v.selectMethod](
                    v.selectUrl,
                    v.selectMethod.toLowerCase() === "get"
                      ? getConfig
                      : v.selectParams
                  );
                },
            v
          );
        }
      });
    },
    visibleChange(visible, form) {
      if (!visible) {
        this.blurSelect(form);
      }
    },
    blurSelect({
      selectUrl,
      selectFetch,
      modelValue,
      dataKey,
      labelKey,
      valueKey,
      maxNum,
      multiple,
      _selectedFlag
    }) {
      if (!selectUrl && !selectFetch) {
        return false;
      }
      const value = this.params[modelValue];
      if (!_selectedFlag && value !== "") {
        let selectData = this.selectAllOptions[dataKey];
        if (selectData) {
          // 判断 value 是否符合要求 （在选项列表内），不符合要求的话过滤
          let valueList = selectData.map(v => v[valueKey]) || [];
          if (multiple) {
            if (value.length) {
              // 过滤每一项
              let val = value.filter(v => {
                return valueList.includes(v);
              });
              this.params[modelValue] = val;
            } else {
              this.params[modelValue] = [];
            }
          } else {
            if (!valueList.includes(value)) this.params[modelValue] = "";
          }
          if (maxNum) {
            selectData = selectData.slice(0, maxNum);
          }
          this.delay(200).then(() => {
            this.selectOptions[dataKey] = selectData;
          });
        }
      }
    },
    filterSelect(paramValue, form) {
      var { dataKey, maxNum, resultHandler, labelKey = "id", clear } = form;
      if (typeof clear === "function") {
        clear();
      }
      if (!form.selectUrl && !form.selectFetch) {
        return false;
      }
      if (form._selectedFlag) {
        form._selectedFlag = false;
      }
      this.params[form.modelValue] = paramValue;
      var selectData = this.selectAllOptions[dataKey];
      if (!selectData) {
        return false;
      }
      if (paramValue) {
        selectData = selectData.filter(item => {
          return ("" + item[labelKey]).indexOf(paramValue) > -1;
        });
      }
      if (maxNum) {
        selectData = selectData.slice(0, maxNum);
      }
      this.selectOptions[dataKey] = selectData;
    }
  }
};
</script>

<style lang="scss" scoped>
::v-deep .range-datetime-wrapper {
  display: inline-block;
  .range-text {
    display: inline-block;
    margin-right: 10px;
    margin-top: 7px;
  }
}
::v-deep .search-type {
  margin-left: 20px;
}
::v-deep .search-button {
  margin-left: 20px;
  margin-top: -1px;
}
</style>
