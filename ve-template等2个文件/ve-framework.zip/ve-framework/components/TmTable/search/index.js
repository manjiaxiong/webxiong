import SearchForm from './src/main';

SearchForm.install = function(Vue) {
  Vue.component(SearchForm.name, SearchForm);
};

export default SearchForm;
