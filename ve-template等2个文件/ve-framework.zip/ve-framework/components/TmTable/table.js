import Vue from 'vue';
import props from './props';
import axios from 'axios';
export default {
  name: 'tm-table',
  props,
  data() {
    const _this = this;
    return {
      Vue,
      pagination: {
        pageIndex: 1,
        pageSize: (() => {
          const { pageSizes } = _this;
          if (pageSizes.length > 0) {
            return pageSizes[0];
          }
          return 20;
        })()
      },
      total: 0,
      loading: false,
      tableData: [],
      cacheLocalData: []
    };
  },
  computed: {
    newSlotScope() {
      return Number(Vue.version.replace(/\./g, '')) >= 250;
    }
  },
  methods: {
    handleSizeChange(size) {
      this.pagination.pageSize = size;
      this.dataChangeHandler();
    },
    handleCurrentChange(pageIndex) {
      this.pagination.pageIndex = pageIndex;
      this.dataChangeHandler();
    },
    searchHandler(resetPageIndex = true) {
      if (resetPageIndex) {
        this.pagination.pageIndex = 1;
      }
      this.dataChangeHandler(arguments[0]);
    },
    dataChangeHandler() {
      const { type } = this;
      if (type === 'local') {
        this.dataFilterHandler(arguments[0]);
      } else if (type === 'remote') {
        this.fetchHandler(arguments[0]);
      }
    },
    dataFilter(data) {
      const { pageIndex, pageSize } = this.pagination;
      return data.filter((v, i) => {
        return i >= (pageIndex - 1) * pageSize && i < pageIndex * pageSize;
      });
    },
    dataFilterHandler(formParams) {
      const { cacheLocalData, params } = this;
      const mergeParams = Object.assign(params, formParams);
      const validParamKeys = Object.keys(mergeParams).filter(v => {
        return mergeParams[v] !== undefined && mergeParams[v] !== '';
      });
      const searchForm = this.$refs['searchForm'];
      let paramFuzzy;
      if (searchForm) {
        paramFuzzy = searchForm.getParamFuzzy();
      }

      if (validParamKeys.length > 0) {
        const validData = cacheLocalData.filter(v => {
          let valids = [];
          validParamKeys.forEach(vv => {
            if (typeof v[vv] === 'number') {
              valids.push(
                paramFuzzy && paramFuzzy[vv]
                  ? String(v[vv]).indexOf(String(mergeParams[vv])) !== -1
                  : String(v[vv]) === String(mergeParams[vv])
              );
            } else {
              valids.push(
                paramFuzzy && paramFuzzy[vv]
                  ? v[vv].indexOf(mergeParams[vv]) !== -1
                  : v[vv] === mergeParams[vv]
              );
            }
          });
          return valids.every(vvv => {
            return vvv;
          });
        });

        this.tableData = this.dataFilter(validData);
        this.total = validData.length;
      } else {
        this.total = cacheLocalData.length;
        this.tableData = this.dataFilter(cacheLocalData);
      }
    },
    fetchHandler(formParams = {}) {
      this.loading = true;
      let {
        fetch,
        method,
        url,
        // eslint-disable-next-line
        headers,
        listField,
        pageIndexKey,
        pageSizeKey,
        totalField,
        params,
        showPagination,
        pagination
      } = this;

      params = JSON.parse(JSON.stringify(Object.assign(params, formParams)));

      if (showPagination) {
        params = Object.assign(params, {
          [pageIndexKey]: pagination.pageIndex,
          [pageSizeKey]: pagination.pageSize
        });
      }

      let requestObject = null;

      if (fetch) {
        requestObject = fetch(params);
      } else {
        method = method.toLowerCase();

        if (method === 'get') {
          requestObject = axios[method](url, {
            params
          });
        } else {
          requestObject = axios[method](url, params);
        }
      }

      requestObject
        .then(response => {
          let result = response;
          if (response && !(response instanceof Array)) {
            if (listField && listField.indexOf('.') !== -1) {
              listField.split('.').forEach(vv => {
                result = result[vv];
              });
            } else {
              result = response[listField];
            }
          }

          if (!result || !(result instanceof Array)) {
            throw new Error(`The result of key:${listField} is not Array.`);
            // eslint-disable-next-line
            this.loading = false;
            return false;
          }

          if (this.dataHandler) {
            this.tableData = result.map(this.dataHandler);
          } else {
            this.tableData = result;
          }

          let totalValue = response;
          if (Object.prototype.toString.call(response) === '[object Array]') {
            totalValue = response.length;
          } else if (typeof response === 'object') {
            if (totalField && totalField.indexOf('.') !== -1) {
              totalField.split('.').forEach(vv => {
                totalValue = totalValue[vv];
              });
            } else {
              totalValue = response[totalField];
            }
          } else {
            totalValue = 0;
          }
          this.total = totalValue;

          this.loading = false;
        })
        // eslint-disable-next-line
        .catch(error => {
          // console.error('Get remote data failed. ', error)
          this.loading = false;
        });
    },
    emitEventHandler(event) {
      this.$emit(event, ...Array.from(arguments).slice(1));
    },
    loadLocalData(data) {
      const { autoLoad } = this;
      if (!data) {
        throw new Error(
          `When the type is 'local', you must set attribute 'data' and 'data' must be a array.`
        );
        // eslint-disable-next-line
        this.showPagination = false;
        return false;
      }
      const cacheData = JSON.parse(JSON.stringify(data));
      this.cacheLocalData = cacheData;
      if (autoLoad) {
        this.tableData = this.dataFilter(cacheData);
        this.total = cacheData.length;
      }
    }
  },
  mounted() {
    // event: expand changed to `expand-change` in Element v2.x
    this.$refs['table'].$on('expand', (row, expanded) =>
      this.emitEventHandler('expand', row, expanded)
    );
    const { type, autoLoad, data, formOptions, params } = this;
    if (type === 'remote' && autoLoad) {
      if (formOptions) {
        this.$refs['searchForm'].getParams((error, formParams) => {
          if (!error) {
            this.fetchHandler(Object.assign(formParams, params));
          }
        });
      } else {
        this.fetchHandler(params);
      }
    } else if (type === 'local') {
      this.loadLocalData(data);
    }
  },
  watch: {
    data: function(value) {
      this.loadLocalData(value);
    }
  },
  render(h) {
    const Table = h(
      'el-table',
      {
        style: {
          width: '100%',
          'margin-top': '20px'
        },
        props: {
          'v-loading.lock': 'loading',
          data: this.tableData,
          border: this.border,
          stripe: this.stripe,
          height: this.height,
          'max-height': this.maxHeight,
          fit: this.fit,
          'show-header': this.showHeader,
          'highlight-current-row': this.highlightCurrentRow,
          'current-row-key': this.currentRowKey,
          'row-class-name': this.rowClassName,
          'row-style': this.rowStyle,
          'row-ket': this.rowKey,
          'empty-text': this.emptyText,
          'default-expand-all': this.defaultExpandAll,
          'expand-row-keys': this.expandRowKeys,
          'default-sort': this.defaultSort,
          'tooltip-effect': this.tooltipEffect,
          'show-summary': this.showSummary,
          'sum-text': this.sumText,
          'summary-method': this.summaryMethod
        },
        on: {
          select: (selection, row) =>
            this.emitEventHandler('select', selection, row),
          'select-all': selection =>
            this.emitEventHandler('select-all', selection),
          'selection-change': selection =>
            this.emitEventHandler('selection-change', selection),
          'cell-mouse-enter': (row, column, cell, event) =>
            this.emitEventHandler('cell-mouse-enter', row, column, cell, event),
          'cell-mouse-leave': (row, column, cell, event) =>
            this.emitEventHandler('cell-mouse-leave', row, column, cell, event),
          'cell-click': (row, column, cell, event) =>
            this.emitEventHandler('cell-click', row, column, cell, event),
          'cell-dblclick': (row, column, cell, event) =>
            this.emitEventHandler('cell-dblclick', row, column, cell, event),
          'row-click': (row, event, column) =>
            this.emitEventHandler('row-click', row, event, column),
          'row-dblclick': (row, event) =>
            this.emitEventHandler('row-dblclick', row, event),
          'row-contextmenu': (row, event) =>
            this.emitEventHandler('row-contextmenu', row, event),
          'header-click': (column, event) =>
            this.emitEventHandler('header-click', column, event),
          'sort-change': args => this.emitEventHandler('sort-change', args),
          'filter-change': filters =>
            this.emitEventHandler('filter-change', filters),
          'current-change': (currentRow, oldCurrentRow) =>
            this.emitEventHandler('current-change', currentRow, oldCurrentRow),
          'header-dragend': (newWidth, oldWidth, column, event) =>
            this.emitEventHandler(
              'header-dragend',
              newWidth,
              oldWidth,
              column,
              event
            ),
          'expand-change': (row, expanded) =>
            this.emitEventHandler('expand-change', row, expanded)
        },
        ref: 'table'
      },
      [this.$slots.prepend, ...this.$slots.default, this.$slots.append]
    );
    var children = [Table];
    if (this.showPagination) {
      const Pagination = h(
        'div',
        {
          style: {
            'margin-top': '10px',
            'text-align': 'right'
          }
        },
        [
          h('el-pagination', {
            props: {
              'current-page': this.pagination.pageIndex,
              'page-sizes': this.pageSizes,
              'page-size': this.pagination.pageSize,
              layout: this.paginationLayout,
              total: this.total
            },
            on: {
              'size-change': this.handleSizeChange,
              'current-change': this.handleCurrentChange
            }
          })
        ]
      );
      children.push(Pagination);
    }

    return h('div', children);
  }
};
