<template>
  <div class="monitor-container">
    <collapse class="slideMenu" :style="treeStyle">
      <car-tree ref="tree" :params="params.tree" @car-clicked="carClicked" />
      <!-- 日期表单 -->
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        size="small"
        class="data-ruleForm"
      >
        <el-form-item prop="startTime">
          <el-date-picker
            v-model="ruleForm.startTime"
            type="datetime"
            placeholder="选择开始日期时间"
            :picker-options="pickerOptions0"
            :editable="false"
            :clearable="true"
          ></el-date-picker>
        </el-form-item>
        <el-form-item prop="endTime">
          <el-date-picker
            v-model="ruleForm.endTime"
            type="datetime"
            placeholder="选择结束日期时间"
            :picker-options="pickerOptions1"
            :editable="false"
            :clearable="true"
          ></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            :loading="loading"
            @click="submitForm('ruleForm')"
            >查询</el-button
          >
        </el-form-item>
      </el-form>
    </collapse>
    <div class="map-container bm-view">
      <div class="absolute-wrapper flex-vertical">
        <baidu-map
          :center="mapOption.center"
          :zoom="mapOption.zoom"
          :mapClick="false"
          @ready="mapLoaded"
          :scroll-wheel-zoom="true"
          class="bm-view"
        >
          <bm-marker
            v-if="busChecked"
            :position="busChecked"
            :rotation="busChecked.direction"
            :icon="busIcon"
            @click="showPopop(busChecked)"
          ></bm-marker>
          <bm-info-window
            :position="infoWindow.position"
            :width="400"
            title="车辆位置信息"
            :auto-pan="true"
            :show="infoWindow.show"
            @close="infoWindowClose"
            @open="infoWindowOpen"
          >
            <slot name="dialog" :data="infoWindow.form"></slot>
          </bm-info-window>
          <bm-control v-if="path.length > 0">
            <el-button-group style="margin: 10px">
              <el-button type="primary" size="mini" @click="handlePlay(0)">
                <i class="fa" :class="!isPlay ? 'fa-play' : 'fa-stop'"></i>
                {{ !isPlay ? "开始" : "停止" }}
              </el-button>
              <el-button
                type="primary"
                size="mini"
                @click="handlePlay(counter)"
              >
                <i
                  class="fa "
                  :class="!isPlay ? 'fa-play-circle' : 'fa-pause-circle'"
                ></i>
                {{ !isPlay ? "继续" : "暂停" }}
              </el-button>
              <el-button type="primary" size="mini" @click="ratio = 2">
                <i class="fa fa-arrow-circle-up"></i>
                加速
              </el-button>
              <el-button type="primary" size="mini" @click="ratio = 0.5">
                <i class="fa fa-arrow-circle-down"></i>
                减速
              </el-button>
            </el-button-group>
          </bm-control>
          <bm-polyline :path="path"></bm-polyline>
        </baidu-map>
        <!--地图下列表-->
        <div class="list">
          <div class="switch" @click="showTab = !showTab"></div>
          <el-tabs v-model="activeName" v-show="showTab" tab-position="top">
            <el-tab-pane label="车辆轨迹" name="first" :lazy="false">
              <el-table
                ref="scrollTable"
                :data="list"
                :row-class-name="tableRowClassName"
                size="mini"
                height="200"
                border
                style="width: 100%"
              >
                <el-table-column
                  type="index"
                  label="序号"
                  width="50"
                  align="center"
                ></el-table-column>
                <el-table-column
                  prop="siteTimeName"
                  label="时间"
                  width="160"
                ></el-table-column>
                <el-table-column prop="lng" label="经度"></el-table-column>
                <el-table-column prop="lat" label="纬度"></el-table-column>
                <el-table-column
                  prop="directionName"
                  label="方向"
                ></el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import format from "date-fns/format";
import { BaiduMap, BmInfoWindow } from "vue-baidu-map/components";
import CarTree from "./CarTree";
const coordtransform = require("coordtransform");

export default {
  components: {
    BaiduMap,
    CarTree,
    BmInfoWindow
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    var validateTime = (rule, value, callback) => {
      if (
        this.ruleForm.startTime === "" ||
        this.ruleForm.startTime === null ||
        this.ruleForm.endTime === "" ||
        this.ruleForm.endTime === null
      ) {
        callback();
      } else {
        if (
          Math.abs(
            Math.ceil(
              (this.ruleForm.endTime.getTime() -
                this.ruleForm.startTime.getTime()) /
                1000 /
                (60 * 60 * 24)
            )
          ) > 3
        ) {
          callback(new Error("请选择3天以内的数据"));
        } else {
          callback();
        }
      }
    };
    return {
      loading: false,
      busInfo: {},
      ruleForm: {
        startTime: "",
        endTime: ""
      },
      rules: {
        startTime: [
          {
            required: true,
            message: "必填",
            trigger: "change"
          },
          {
            validator: validateTime,
            trigger: "change"
          }
        ],
        endTime: [
          {
            required: true,
            message: "必填",
            trigger: "change"
          },
          {
            validator: validateTime,
            trigger: "change"
          }
        ]
      },
      pickerOptions0: {
        disabledDate: time => {
          if (this.ruleForm.endTime != "" && this.ruleForm.endTime != null) {
            let currentTime = this.ruleForm.endTime;
            let threeDays = currentTime.setDate(currentTime.getDate() - 3);
            currentTime.setDate(currentTime.getDate() + 3);
            return (
              time.getTime() > this.ruleForm.endTime ||
              time.getTime() < threeDays
            );
          }
        }
      },
      pickerOptions1: {
        disabledDate: time => {
          if (
            this.ruleForm.startTime != "" &&
            this.ruleForm.startTime != null
          ) {
            let currentTime = this.ruleForm.startTime;
            let threeDays = currentTime.setDate(currentTime.getDate() + 3);
            currentTime.setDate(currentTime.getDate() - 3);
            return (
              time.getTime() < this.ruleForm.startTime ||
              time.getTime() > threeDays
            );
          }
        }
      },
      activeName: "first",
      infoWindow: {
        show: false,
        position: {},
        form: {}
      },
      mapProps: {}, //地图相关默认属性
      list: [],
      path: [],
      timer: null,
      isPlay: false, //是否正在播放
      counter: 0,
      interval: 1000, //定时器间隔
      ratio: 1, //倍速
      showTab: true
    };
  },
  beforeDestroy() {
    clearTimeout(this.timer);
  },
  computed: {
    treeStyle() {
      if (this.params.tree && this.params.tree.width) {
        return "width: " + this.params.tree.width + "px";
      }
      return "";
    },
    mapOption() {
      var mapProps = this.mapProps || {};
      return Object.assign({}, this.params.map || {}, mapProps);
    },
    busChecked() {
      return this.list[this.counter] || "";
    },
    //车辆图标
    busIcon() {
      return Object.assign(
        { url: require("./icon/bus.png"), size: { width: 30, height: 30 } },
        this.params.busIcon || {}
      );
    }
  },
  watch: {
    counter: function(newVal, oldVal) {
      // 滚动到视线区
      this.$nextTick(() => {
        let element = this.$refs.scrollTable.$refs.bodyWrapper;
        element.scrollTop = element.offsetTop * this.counter; //行高*this.counter
      });
      this.showPopop(this.list[this.counter]);
    }
  },
  methods: {
    mapLoaded({ map, BMap }) {
      this.map = map;
      this.BMap = BMap;
    },
    init() {
      // 隐藏弹窗
      this.infoWindow.show = false;
      // 初始化表格值
      this.list = [];
      // 初始化地图路径
      this.path = [];
      this.isPlay = false;
      this.counter = 0;
      // 清掉计时器
      clearTimeout(this.timer);
    },
    handleNodeClick(data) {
      //初始化
      this.init();
      // 保存数据
      this.busInfo = { ...data };
    },
    // eslint-disable-next-line
    infoWindowClose(e) {
      this.infoWindow.show = false;
    },
    // eslint-disable-next-line
    infoWindowOpen(e) {
      this.infoWindow.show = true;
    },
    showPopop(item) {
      this.infoWindow.form.carNo = this.busInfo.name;
      this.infoWindow.form.time = item.positionTime;
      this.infoWindow.form.rotation = this.transformDirection(item.direction);
      this.infoWindow.form.coordinate = `${item.lng}, ${item.lat}`;
      this.infoWindow.position = { ...item };
      this.infoWindow.show = true;
    },
    carClicked(treeNode) {
      //初始化
      this.init();
      this.busInfo = { ...treeNode };
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          // 1.如果选择车辆，继续执行
          // 没点击的时候会有一个空的数据状态，点击了车辆之后，改变这个状态，保存这个车辆的信息。
          if (Object.keys(this.busInfo).length) {
            // 先进行初始化，存在播放时重新选择时间段的情况
            this.init();

            this.loading = true;

            // 2.获取历史轨迹定位信息
            this.getListInfo(this.busInfo);
          } else {
            this.$message({
              message: "请选择一辆车",
              type: "warning"
            });
            return false;
          }
        } else {
          return false;
        }
      });
    },
    getListInfo(busInfo) {
      let data = {
        // id: busInfo.name,
        starttime: format(this.ruleForm.startTime, "YYYY-MM-DD HH:mm:ss"),
        endtime: format(this.ruleForm.endTime, "YYYY-MM-DD HH:mm:ss")
      };
      console.log(this.ruleForm.startTime);
      console.log(busInfo);
      console.log(data);
      // return;

      this.$axios({
        method: "get",
        // url: this.api.getHisLocation,
        url: `/history/replay/${busInfo.id}`,
        data,
        params: data
      }).then(
        res => {
          this.loading = false;
          if (res && res.length) {
            let pathArray = [];
            let positionTemp = [];

            for (let item of res) {
              item.directionName = this.transformDirection(item.direction);
              item.siteTimeName = item.positionTime;
              positionTemp = this.wgs84tobd09(item.lng, item.lat);
              item.lng = positionTemp[0];
              item.lat = positionTemp[1];
              pathArray.push({
                lng: item.lng,
                lat: item.lat
              });
            }

            // 表格赋值
            this.list = res;

            // 在地图上绘制路径
            this.path = pathArray;
            // 车辆图标定位到第一个点，显示window弹窗，地图拉到中心
            this.mapProps = {
              center: {
                lng: res[0].lng,
                lat: res[0].lat
              }
            };
          } else {
            this.$message({
              message: "该时间段内没有数据",
              type: "warning"
            });
          }
        },
        err => {
          this.loading = false;
        }
      );
    },
    handlePlay(counter) {
      this.counter = counter;
      this.isPlay = !this.isPlay;
      if (this.isPlay) {
        this.run();
      } else {
        clearTimeout(this.timer);
      }
    },
    run() {
      //开始运行
      this.counter++;
      if (this.counter > this.list.length - 1) {
        this.isPlay = false;
        clearTimeout(this.timer);
      } else {
        this.timer = setTimeout(() => {
          this.run();
        }, this.interval / this.ratio);
      }
    },
    // eslint-disable-next-line
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex == this.counter) {
        return "success-row";
      }
      return "";
    },
    // 设备坐标转百度坐标
    wgs84tobd09(lng, lat) {
      let mid = coordtransform.wgs84togcj02(lng, lat);
      return coordtransform.gcj02tobd09(mid[0], mid[1]);
    },
    // 方位角转方位名称
    transformDirection(direction) {
      if (direction == 0) return "正北";
      if (direction == 90) return "正东";
      if (direction == 180) return "正南";
      if (direction == 270) return "正西";
      if (direction > 0 && direction < 90) return "东北";
      if (direction > 90 && direction < 180) return "东南";
      if (direction > 180 && direction < 270) return "西南";
      if (direction > 270 && direction < 360) return "西北";
      if (!direction) return "";
    }
  }
};
</script>

<style lang="scss" scoped>
.bm-view {
  width: 100%;
  height: 100%;
}

.monitor-container {
  display: flex;
  height: 100%;
}

.map-container {
  .absolute-wrapper {
    overflow: hidden;
    width: 100%;
    height: 100%;
  }
}

.el-tabs__nav-scroll {
  margin-left: 20px;
}

.location-detail {
  width: 440px;
  font-size: 0;

  .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }

  span {
    color: #99a9be;
  }
}

.list {
  background: #fff;
  .switch {
    height: 5px;
    cursor: pointer;
  }
}

.data-ruleForm {
  padding: 10px;
  background: #f3f3f5;
  height: 150px;
  overflow: hidden;
  .el-form-item {
    margin-bottom: 16px;

    .el-date-editor.el-input,
    .el-date-editor.el-input__inner {
      width: 100%;
    }

    .el-button {
      width: 100%;
    }
  }

  /deep/ .el-date-editor .el-range-separator {
    padding: 0;
  }
}

.el-table /deep/ .success-row {
  background: #f0f9eb;
}
</style>
