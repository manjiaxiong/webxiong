<template>
  <div class="monitor-container">
    <collapse class="slideMenu" :style="treeStyle">
      <car-tree
        ref="tree"
        :params="params.tree"
        @car-checked="carChecked"
        @car-clicked="carClicked"
      />
    </collapse>
    <div class="map-container bm-view">
      <div class="absolute-wrapper flex-vertical">
        <baidu-map
          class="bm-view"
          :scroll-wheel-zoom="true"
          :map-click="false"
          @ready="mapLoaded"
          ak="lae7xspd2Fs7PTyjyzLe6oFFlnt3aYax"
          :center="params.map.center"
          :zoom="params.map.zoom"
        >
          <bm-info-window
            :position="{ lng: currPoint.lng, lat: currPoint.lat }"
            :title="
              params.dialog && params.dialog.title ? params.dialog.title : ''
            "
            :show="showInfoWindow"
            :autoPan="true"
            @clickclose="infoWindowClose"
            :closeOnClick="false"
          >
            <slot name="dialog" :data="carInfo"></slot>
          </bm-info-window>
        </baidu-map>
        <slot name="table"></slot>
      </div>
    </div>
  </div>
</template>

<script>
import CarTree from "./CarTree";
import { BaiduMap, BmInfoWindow } from "vue-baidu-map/components";
import SockJS from "sockjs-client";
import Stomp from "stompjs";
import { getToken } from "../../utils/auth";
import MarkerClusterer from "./libs/MarkerClusterer";
import request from "../../utils/request";
export default {
  name: "monitor",
  components: {
    BaiduMap,
    CarTree,
    BmInfoWindow
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      carInfo: {}, //车辆详细信息
      stompClient: "",
      timer: "", //心跳检测定时器
      refreshTimer: "", //实时定位定时器
      currPoint: {}, //当前点击的车辆信息
      showInfoWindow: false, //是否打开弹出框
      carNos: [] //选中的车辆列表
    };
  },
  computed: {
    treeStyle() {
      if (this.params.tree && this.params.tree.width) {
        return "width: " + this.params.tree.width + "px";
      }
      return "";
    }
  },
  methods: {
    mapLoaded({ map, BMap }) {
      this.map = map;
      this.BMap = BMap;
      this.initWebSocket();
    },
    infoWindowClose() {
      this.showInfoWindow = false;
    },
    open(type, data) {
      this.$dialog.open("monitor", type, data);
    },
    carClicked(treeNode) {
      this.showInfoWindow = false;
      this.itemClick(treeNode);
    },
    carChecked(carNos) {
      carNos = carNos.filter(car => {
        return !car.isParent;
      });
      var arr = carNos.map(car => car.id);
      this.carNos = arr;
      this.send();
    },
    initWebSocket() {
      this.connection();
      let that = this;
      // 断开重连机制,尝试发送消息,捕获异常发生时重连
      // this.timer = setInterval(() => {
      //   try {
      //     that.stompClient.send("test");
      //   } catch (err) {
      //     console.log("断线了: " + err);
      //     that.connection();
      //   }
      // }, 5000);
    },
    send() {
      this.stompClient.send(
        "/app/trackers",
        this.headers,
        JSON.stringify(this.carNos)
      ); //获取车辆实时定位信息
    },
    connection() {
      // 建立连接对象
      let socket = new SockJS(this.params.socketUrl || "/ws");
      // 获取STOMP子协议的客户端对象
      this.stompClient = Stomp.over(socket);
      // 定义客户端的认证信息,按需求配置
      var token = getToken();
      var headers = {};
      if (token) {
        token = JSON.parse(token);
        headers["Authorization"] = "Bearer " + token.accessToken;
      }
      this.headers = headers;
      // 向服务器发起websocket连接
      this.stompClient.connect(
        headers,
        () => {
          this.stompClient.subscribe(
            "/user/topic/trackers",
            resp => {
              // 订阅服务端提供的某个topic
              var markers = [];
              var markerArr = JSON.parse(resp.body || "[]");
              var pt = null,
                marker = null;
              var BMap = this.BMap;
              var busIcon = Object.assign(
                {
                  url: require("./icon/bus.png"),
                  size: { width: 23, height: 25 }
                },
                this.params.busIcon || {}
              );
              var myIcons = new BMap.Icon(
                busIcon.url,
                new BMap.Size(busIcon.size.width, busIcon.size.height),
                {
                  anchor: new BMap.Size(10, 25)
                }
              );
              for (var i = 0; i < markerArr.length; i++) {
                pt = new BMap.Point(markerArr[i].lng, markerArr[i].lat);
                marker = new BMap.Marker(pt, {
                  icon: myIcons
                });
                marker.text = markerArr[i].id;
                marker.properties = markerArr[i];
                markers.push(marker);
              }
              if (this.markerClusterer) {
                this.markerClusterer.clearMarkers();
                this.markerClusterer.addMarkers(markers);
              } else {
                this.markerClusterer = new MarkerClusterer(this.map, {
                  markers: markers,
                  isAverageCenter: true,
                  maxZoom: this.params.map.maxZoom || 15,
                  mapvOption: {
                    fillStyle: "#333",
                    methods: {
                      click: item => {
                        if (item && item.properties) {
                          this.itemClick(item.properties);
                        }
                      }
                    }
                  }
                });
                this.$nextTick(() => {
                  this.markerClusterer._redraw();
                });
              }
            },
            headers
          );
          this.startTimer(); //开启刷新车辆定位定时器
        },
        err => {
          // 连接发生错误时的处理函数
          console.log("失败");
          console.log(err);
        }
      );
    }, //连接 后台
    itemClick(item) {
      request({
        type: "get",
        url: `/monitor/realtimes/${item.id}`
      }).then(resp => {
        this.carInfo = resp;
        if (JSON.stringify(resp) == "{}") {
          return false;
        }
        this.currPoint = resp.position;
        this.showInfoWindow = true;
        //将地图缩放到指定的区域
        this.$nextTick(() => {
          var { lng, lat } = this.currPoint;
          this.map.centerAndZoom(new this.BMap.Point(lng, lat), 15);
        });
      });
    },
    startTimer() {
      this.send();
      this.refreshTimer = setInterval(() => {
        this.send();
      }, this.params.refreshTimer || 1000);
    },
    disconnect() {
      if (this.stompClient) {
        this.stompClient.disconnect();
      }
    } // 断开连接
  },
  beforeDestroy: function() {
    // 页面离开时断开连接,清除定时器
    this.disconnect();
    clearInterval(this.timer);
    clearInterval(this.refreshTimer);
  }
};
</script>

<style lang="scss" scoped>
.bm-view {
  width: 100%;
  height: 100%;
}

.monitor-container {
  display: flex;
  height: 100%;
}

.map-container {
  flex: 1;
  display: flex;
  .absolute-wrapper {
    flex: 1;
    overflow: hidden;
    // position: absolute;
    // width: 100%;
    // height: 100%;
  }
}
</style>
