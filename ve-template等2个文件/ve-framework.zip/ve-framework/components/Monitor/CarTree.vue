<template>
  <div class="car-tree-wrapper" v-loading="isLoading">
    <div class="flex-wrap">
      <el-input
        size="small"
        placeholder="输入车牌号"
        @input="change"
        v-model="text"
        :clearable="true"
      />
      <el-button
        :class="['refresh', isLoading ? 'loading' : '']"
        :disabled="isLoading"
        size="small"
        @click="refresh('refresh')"
        icon="el-icon-refresh"
      />
    </div>
    <tree
      :nodes="carTreeData"
      :setting="setting"
      @onCheck="check"
      @onCreated="onCreated"
      @onClick="nodeClick"
    />
  </div>
</template>

<script>
import { getCarTreeList } from "../../api/monitor";
export default {
  props: {
    toolbar: {
      type: Boolean,
      default: true
    },
    info: {
      type: Boolean,
      default: true
    },
    params: {
      type: Object,
      default: () => ({})
    }
  },
  components: {
    tree: resolve => require(["../Tree/index"], resolve)
  },
  data() {
    return {
      setting: {
        check: {
          enable: this.getParams("checkbox")
        },
        data: {
          key: {
            name: this.params.labelKey || "name"
          }
        },
        view: {
          showIcon: this.params.icon ? true : false
        }
      },
      text: "", //查询框绑定值
      isLoading: true,
      carTreeData: []
    };
  },
  methods: {
    getParams(key, defaultValue, type = "boolean") {
      return typeof this.params[key] === type ? this.params[key] : defaultValue;
    },
    loading(flag = true) {
      this.isLoading = flag;
    },
    refresh(flag) {
      return getCarTreeList().then(data => {
        var that = this;
        function clearChildren(data) {
          data.forEach(item => {
            item.checked = false;
            if (item.level === 0) {
              //只有车辆节点可配置图标
              if (typeof that.params.icon === "function") {
                item.icon = that.params.icon(item);
                item.iconSkin = "custom_ico";
              } else if (typeof that.params.icon === "string") {
                item.icon = that.params.icon;
                item.iconSkin = "custom_ico";
              }
            }
            var labelFormat = that.params.labelFormat;
            if (typeof labelFormat === "function") {
              var labelKey = that.params.labelKey || "name";
              item[labelKey] = labelFormat(item);
            }
            if (item.children) {
              if (item.children.length > 0) {
                clearChildren(item.children);
              } else {
                delete item.children;
              }
            }
          });
        }
        clearChildren(data);
        this.carTreeData = data;
        this.loading(false);
        if (flag) {
          this.$message({
            message: "刷新成功",
            type: "success"
          });
        }
      });
    },
    handleCommand(command, data) {
      const { dropdown } = this.params;
      if (dropdown && typeof dropdown.confirm === "function") {
        dropdown.confirm(command, data);
      }
    },
    nodeClick(e, treeId, treeNode) {
      if (this.params.checkbox) {
        if (!treeNode.checked) {
          this.treeObj.checkNode(treeNode, true, true);
        }
      }
      if (treeNode.last && (treeNode.checked || !treeNode.nocheck)) {
        this.$emit("car-clicked", treeNode);
      }
    },
    onCreated(treeObj) {
      this.treeObj = treeObj;
      treeObj.expandAll(true);
    },
    check(event, treeId, treeNode) {
      var checkedNodes = this.treeObj.getCheckedNodes(true);
      this.$emit("car-checked", checkedNodes);
    },
    change() {
      this.fuzzySearch()(this.text); //调用延时处理
    },
    fuzzySearch() {
      var zTreeObj = this.treeObj; //获取树对象
      if (!zTreeObj) {
        console.log("获取树对象失败");
      }
      var nameKey = zTreeObj.setting.data.key.name; //获取name属性的key
      var isHighLight = false; //是否高亮
      var isExpand = true; //是否展开
      zTreeObj.setting.view.nameIsHTML = isHighLight; //允许在节点名称中使用html,用于处理高亮

      var metaChar = "[\\[\\]\\\\^\\$\\.\\|\\?\\*\\+\\(\\)]"; //js正则表达式元字符集
      var rexMeta = new RegExp(metaChar, "gi"); //匹配元字符的正则表达式

      // 过滤ztree显示数据
      function ztreeFilter(zTreeObj, _keywords, callBackFunc) {
        if (!_keywords) {
          _keywords = ""; //如果为空，赋值空字符串
        }

        // 查找符合条件的叶子节点
        function filterFunc(node) {
          if (node && node.oldname && node.oldname.length > 0) {
            node[nameKey] = node.oldname; //如果存在原始名称则恢复原始名称
          }
          //node.highlight = false; //取消高亮
          zTreeObj.updateNode(node); //更新节点让之前对节点所做的修改生效
          if (_keywords.length == 0) {
            //如果关键字为空,返回true,表示每个节点都显示
            zTreeObj.showNode(node);
            zTreeObj.expandNode(node, isExpand); //关键字为空时是否展开节点
            return true;
          }
          //节点名称和关键字都用toLowerCase()做小写处理
          if (
            node[nameKey] &&
            node[nameKey].toLowerCase().indexOf(_keywords.toLowerCase()) != -1
          ) {
            if (isHighLight) {
              //如果高亮，对文字进行高亮处理
              //创建一个新变量newKeywords,不影响_keywords在下一个节点使用
              //对_keywords中的元字符进行处理,否则无法在replace中使用RegExp
              var newKeywords = _keywords.replace(rexMeta, function(matchStr) {
                //对元字符做转义处理
                return "\\" + matchStr;
              });
              node.oldname = node[nameKey]; //缓存原有名称用于恢复
              //为处理过元字符的_keywords创建正则表达式,全局且不分大小写
              var rexGlobal = new RegExp(newKeywords, "gi"); //'g'代表全局匹配,'i'代表不区分大小写
              //无法直接使用replace(/substr/g,replacement)方法,所以使用RegExp
              node[nameKey] = node.oldname.replace(rexGlobal, function(
                originalText
              ) {
                //将所有匹配的子串加上高亮效果
                var highLightText =
                  '<span style="color: #fff;background-color: orange;">' +
                  originalText +
                  "</span>";
                return highLightText;
              });
              //================================================//
              //node.highlight用于高亮整个节点
              //配合setHighlight方法和setting中view属性的fontCss
              //因为有了关键字高亮处理,所以不再进行相关设置
              //node.highlight = true;
              //================================================//
              zTreeObj.updateNode(node); //update让更名和高亮生效
            }
            zTreeObj.showNode(node); //显示符合条件的节点
            return true; //带有关键字的节点不隐藏
          }

          zTreeObj.hideNode(node); // 隐藏不符合要求的节点
          return false; //不符合返回false
        }
        var nodesShow = zTreeObj.getNodesByFilter(filterFunc); //获取匹配关键字的节点
        processShowNodes(nodesShow, _keywords); //对获取的节点进行二次处理
      }

      /**
       * 对符合条件的节点做二次处理
       */
      function processShowNodes(nodesShow, _keywords) {
        if (nodesShow && nodesShow.length > 0) {
          //关键字不为空时对关键字节点的祖先节点进行二次处理
          if (_keywords.length > 0) {
            nodesShow.forEach(function(obj, n) {
              console.log(obj);
              var pathOfOne = obj.getPath(); //向上追溯,获取节点的所有祖先节点(包括自己)
              if (pathOfOne && pathOfOne.length > 0) {
                //对path中的每个节点进行操作
                for (var i = 0; i < pathOfOne.length - 1; i++) {
                  zTreeObj.showNode(pathOfOne[i]); //显示节点
                  zTreeObj.expandNode(pathOfOne[i], true); //展开节点
                }
              }
            });
          } else {
            //关键字为空则显示所有节点, 此时展开根节点
            var rootNodes = zTreeObj.getNodesByParam("level", "0"); //获得所有根节点
            rootNodes.forEach(function(obj, n) {
              zTreeObj.expandNode(obj, true); //展开所有根节点
            });
          }
        }
      }

      var timeoutId = null;
      // 有输入后定时执行一次，如果上次的输入还没有被执行，那么就取消上一次的执行
      function searchNodeLazy(_keywords) {
        if (timeoutId) {
          //如果不为空,结束任务
          clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(function() {
          ztreeFilter(zTreeObj, _keywords); //延时执行筛选方法
        }, 500);
      }
      return searchNodeLazy;
    }
  },
  created() {
    this.refresh();
  }
};
</script>

<style lang="scss">
.flex-wrap {
  display: flex;
  align-items: center;
}

.tree-dropdown {
  border-color: #ddd;

  &.region {
    padding: 1px 0;

    .popper__arrow {
      border-bottom-color: #d6d6d6;
    }
  }

  &.set-height {
    padding: 2px 0;
    overflow: auto;
  }

  .el-dropdown-menu__item {
    border-top: 1px solid #ddd;

    &:first-child {
      border-top: none;
    }
  }
}

.car-tree-wrapper {
  width: 220px;
  flex: 1;
  user-select: none;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
</style>
