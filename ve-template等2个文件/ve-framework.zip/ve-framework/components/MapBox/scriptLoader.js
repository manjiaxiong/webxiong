let loadCache = [];
const inputScript = (src, callback) => {
  let element = document.createElement("script");
  element.src = src;
  document.body.appendChild(element);
  element.onload = callback || (() => null);
};
const inputCSS = src => {
  let element = document.createElement("link");
  element.rel = "stylesheet";
  element.href = src;
  document.body.appendChild(element);
};
const assets = {
  mapbox: {
    js: "https://cdn.bootcss.com/mapbox-gl/1.4.0/mapbox-gl.js",
    css: "https://cdn.bootcss.com/mapbox-gl/1.4.0/mapbox-gl.css"
  },
  supermap: {
    js:
      "https://cdn.jsdelivr.net/npm/@supermap/iclient-mapboxgl@10.0.0/dist/iclient-mapboxgl-es6.min.js",
    css:
      "https://cdn.jsdelivr.net/npm/@supermap/iclient-mapboxgl@10.0.0/dist/iclient-mapboxgl.min.css"
  },
  mapv: {
    js: "https://cdn.jsdelivr.net/npm/mapv@2.0.56/build/mapv.min.js"
  },
  draw: {
    js:
      "https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.0.9/mapbox-gl-draw.js",
    css:
      "https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.0.9/mapbox-gl-draw.css"
  }
};
const loadPlugin = (resolve, plugins) => {
  const result = plugins.filter(v => {
    return v !== "mapbox" && !loadCache.includes(v);
  });
  if (result.length) {
    let count = 0;
    result.forEach(v => {
      if (assets[v].css) {
        inputCSS(assets[v].css);
      }
      inputScript(assets[v].js, () => {
        count++;
        loadCache.push(v);
        if (count === result.length) {
          resolve();
        }
      });
    });
  } else {
    resolve();
  }
};
export default (plugins = []) => {
  return new Promise(resolve => {
    if (loadCache.includes("mapbox")) {
      loadPlugin(resolve, plugins);
    } else {
      inputCSS(assets.mapbox.css);
      inputScript(assets.mapbox.js, () => {
        loadCache.push("mapbox");
        loadPlugin(resolve, plugins);
      });
    }
  });
};
