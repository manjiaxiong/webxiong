import load from "./scriptLoader";
import coordtransform from "coordtransform";
import superMapMixin, { getSuperMapUrl } from "../../mixins/supermap";
const deepmerge = Object.merge || Object.assign;

const themeURL = {
  normal: getSuperMapUrl("/map-mongodb/rest/maps/China"),
  amap:
    "http://webrd04.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=8",
  blue:
    "https://map.geoq.cn/ArcGIS/rest/services/ChinaOnlineStreetPurplishBlue/MapServer/tile/{z}/{y}/{x}",
  dark: "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
  gray:
    "https://map.geoq.cn/ArcGIS/rest/services/ChinaOnlineStreetGray/MapServer/tile/{z}/{y}/{x}",
  gmap: "http://mt2.google.cn/vt/lyrs=m&hl=zh-CN&gl=cn&x={x}&y={y}&z={z}",
  openstreet: "http://a.tile.openstreetmap.org/{z}/{x}/{y}.png"
};
export default {
  name: "mapbox",
  mixins: [superMapMixin],
  props: {
    styles: {
      type: Object,
      required: false,
      default: () => ({
        width: "100%",
        height: "100%"
      })
    },
    option: {
      type: Object,
      required: false
    },
    mapStyle: {
      type: Object,
      default: () => ({})
    },
    plugins: {
      type: Array,
      default: () => []
    },
    theme: {
      type: String,
      default: "normal"
    }
  },
  watch: {
    "option.center": {
      handler(newVal, oldVal) {
        if (newVal != oldVal) {
          this.map.setCenter(newVal);
        }
      }
    },
    "option.zoom": {
      handler(newVal, oldVal) {
        if (newVal != oldVal) {
          this.map.setZoom(newVal);
        }
      }
    }
  },
  data() {
    return {
      map: null,
      opts: null,
      isCluster: null,
      isHeatmap: null
    };
  },
  mounted() {
    this.initMap();
  },
  methods: {
    // 地图初始化
    initMap() {
      const tileURL =
        this.theme.indexOf("http") > -1
          ? this.theme
          : this.theme.indexOf("/") > -1
          ? getSuperMapUrl(this.theme)
          : themeURL[this.theme] || themeURL.normal;
      const defaultSettings = {
        wgs84: true,
        zoom: 10,
        minZoom: 9,
        maxZoom: 17,
        center: [113.670443, 34.756572] // 郑州
      };
      const defaultStyle = {
        sources: {
          "raster-tiles": {
            type: "raster",
            tiles: [tileURL],
            tileSize: 256
          }
        },
        layers: [
          {
            id: "simple-tiles",
            type: "raster",
            source: "raster-tiles"
          }
        ]
      };
      const opts = Object.assign(defaultSettings, this.option);
      const mapStyle = Object.assign(defaultStyle, this.mapStyle);
      this.opts = opts;
      opts.center = this.fixCoordinate(opts.center);
      const { center, zoom, minZoom, maxZoom, ...rest } = opts;
      if (!this.map) {
        load(this.plugins).then(() => {
          // mapboxgl.accessToken =
          //   "pk.eyJ1IjoiZXhhbXBsZXMiLCJhIjoiY2p0MG01MXRqMW45cjQzb2R6b2ptc3J4MSJ9.zA2W0IkI0c6KaAhJfk9bWg";
          this.map = new mapboxgl.Map({
            container: this.$el,
            style: {
              version: 8,
              // glyphs: "http://pbf.gaogeek.com/{fontstack}/{range}.pbf",
              glyphs:
                "http://minedata.cn/minemapapi/v2.0.0/fonts/{fontstack}/{range}.pbf",
              ...mapStyle
            },
            center,
            zoom,
            minZoom,
            maxZoom,
            ...rest
          });
          this.map.on("load", () => {
            this.resetCenter();
            // this.map.scrollZoom.setWheelZoomRate(1/200);
            this.$emit("ready", this.map);
          });
        });
      }
    },
    // 修正坐标偏移
    fixCoordinate(coordinate) {
      if (this.opts.wgs84) {
        return coordtransform.wgs84togcj02(coordinate[0], coordinate[1]);
      }
      return coordinate;
    },
    // 加载图片
    loadImages(images = {}) {
      const map = this.map;
      let count = 0;
      return new Promise((resolve, reject) => {
        if (map && typeof images === "object") {
          const keys = Object.keys(images);
          keys.forEach(key => {
            const id = "icon-" + key;
            if (map.hasImage(id)) {
              count++;
              if (count === keys.length) {
                resolve();
              }
            } else {
              const item = images[key];
              map.loadImage(
                item && item.src ? item.src : item,
                (error, image) => {
                  if (error) throw error;
                  map.addImage(id, image);
                  count++;
                  if (count === keys.length) {
                    resolve();
                  }
                }
              );
            }
          });
        } else {
          reject();
        }
      });
    },
    // 绑定事件
    _bindEvents(type, layer, callback) {
      const map = this.map;
      if (map) {
        const eventLayer = ["_initEvent", layer, type].join("_");
        if (this[eventLayer]) {
          return;
        }
        this[eventLayer] = true;
        map.on(type, layer, callback);
      }
    },
    // 点击聚合点
    _onClusterClick({ features }) {
      const map = this.map;
      if (map && features && features.length) {
        const { properties, geometry, source } = features[0];
        map
          .getSource(source)
          .getClusterExpansionZoom(properties.cluster_id, (err, zoom) => {
            if (err) return;
            map.easeTo({
              center: geometry.coordinates,
              zoom: zoom
            });
          });
      }
    },
    // 绘制 marker, 支持聚合
    async renderMarker({
      data = [],
      draw = {},
      cluster = false,
      line = false,
      onClick
    }) {
      let sourceId = "marker-source";
      const layers = ["marker-layer", "cluster-layer", "cluster-count-layer"];
      const { type, images, options, key = "status" } = draw;
      const isImage = type === "image" && images;
      const isHeatmap = type === "heatmap";
      if (isImage) {
        await this.loadImages(images);
      }
      let clusterOptions = {
        cluster: true,
        clusterMaxZoom: 14
      };
      let lineOptions = {
        paint: {
          "line-color": "#125FF8",
          "line-width": 5
        }
      };
      let imageOptions = {
        layout: {
          "icon-image": "icon-{" + key + "}",
          "icon-size": 0.7,
          "icon-allow-overlap": false
        }
      };
      if (options) {
        imageOptions = deepmerge(imageOptions, options);
      }
      if (cluster && cluster.config) {
        clusterOptions = deepmerge(clusterOptions, cluster.config);
      }
      if (typeof line === "object") {
        lineOptions = deepmerge(lineOptions, line);
      }
      let isCluster = cluster && clusterOptions.cluster;
      if (this.isCluster !== isCluster) {
        if (this.isCluster !== null) {
          layers.forEach(id => {
            this.removeLayer(id);
          });
        }
        this.isCluster = isCluster;
      }
      if (isCluster) {
        sourceId += "-cluster";
        this._bindEvents("click", layers[1], this._onClusterClick);
      }
      if (this.isHeatmap !== isHeatmap) {
        if (this.isHeatmap !== null) {
          this.removeLayer(layers[0]);
        }
        this.isHeatmap = isHeatmap;
      }
      if (typeof onClick === "function") {
        this._bindEvents("click", layers[0], ({ features }) => {
          if (features && features.length) {
            const { properties, geometry } = features[0];
            onClick({ properties, coordinates: geometry.coordinates });
          }
        });
      }
      if (line) {
        this.setSourceLayer({
          sourceId: "line-source",
          layerId: "line-layer",
          data: this.geojson(data, true),
          layerOptions: {
            type: "line",
            ...lineOptions
          }
        });
      }
      this.setSourceLayer({
        sourceId,
        layerId: layers[0],
        data: this.geojson(data),
        sourceOptions: cluster ? clusterOptions : {},
        layerOptions: {
          type: isImage ? "symbol" : isHeatmap ? "heatmap" : "circle",
          filter: ["!", ["has", "point_count"]],
          ...(isImage ? imageOptions : options || {})
        }
      });
      this.setSourceLayer({
        sourceId,
        layerId: layers[1],
        layerOptions: {
          type: "circle",
          filter: ["has", "point_count"],
          paint: {
            "circle-color": [
              "step",
              ["get", "point_count"],
              "#2680EB",
              100,
              "#f1f075",
              750,
              "#f28cb1"
            ],
            "circle-radius": [
              "step",
              ["get", "point_count"],
              16,
              10,
              20,
              100,
              26,
              1000,
              32
            ]
          }
        }
      });
      this.setSourceLayer({
        sourceId,
        layerId: layers[2],
        layerOptions: {
          type: "symbol",
          filter: ["has", "point_count"],
          layout: {
            "text-field": "{point_count_abbreviated}",
            "text-size": 16
          },
          paint: {
            "text-color": "#fff"
          }
        }
      });
    },
    // 设置 layer 属性
    setPaintProperty(layerId, key, value) {
      if ((this.map && layerId, key, value)) {
        const layer = this.map.getLayer(layerId);
        if (layer) {
          this.map.setPaintProperty(layerId, key, value);
        }
      }
    },
    // 设置 viewport
    setViewport(points, options = { padding: 120 }) {
      if (this.map && Array.isArray(points) && points.length > 0) {
        const firstPoint = this.fixCoordinate(points[0]);
        this.map.fitBounds(
          points
            .reduce(
              (bounds, coord) => bounds.extend(this.fixCoordinate(coord)),
              new mapboxgl.LngLatBounds(firstPoint, firstPoint)
            )
            .toArray(),
          options
        );
      }
    },
    // 设置 source, layer
    setSourceLayer({
      sourceId,
      layerId,
      beforeLayerId = undefined,
      data = null,
      layerOptions = {},
      sourceOptions = {}
    }) {
      if (!this.map) {
        return;
      }
      const dataSource = this.map.getSource(sourceId);
      if (dataSource) {
        if (data) {
          dataSource.setData(data);
        }
      } else {
        this.map.addSource(sourceId, {
          type: "geojson",
          data,
          ...sourceOptions
        });
      }
      if (!this.map.getLayer(layerId)) {
        this.map.addLayer(
          {
            id: layerId,
            source: sourceId,
            ...layerOptions
          },
          beforeLayerId
        );
      }
    },
    // 生成标准 geojson
    geojson(data, line = false) {
      if (!Array.isArray(data)) {
        return false;
      }
      if (line) {
        return {
          type: "Feature",
          geometry: {
            type: "LineString",
            coordinates: data.map(v => this.fixCoordinate(v.coordinates))
          }
        };
      }
      return {
        type: "FeatureCollection",
        features: data.map(v => {
          return {
            type: "Feature",
            geometry: {
              type: v.type || "Point",
              coordinates: this.fixCoordinate(v.coordinates)
            },
            properties: v.properties || {}
          };
        })
      };
    },
    // 删除 layer
    removeLayer(id) {
      if (this.map && this.map.getLayer(id)) {
        this.map.removeLayer(id);
      }
    },
    // 显示 layer
    showLayer(id) {
      if (this.map && this.map.getLayer(id)) {
        this.map.setLayoutProperty(id, "visibility", "visible");
      }
    },
    // 隐藏 layer
    hideLayer(id) {
      if (this.map && this.map.getLayer(id)) {
        this.map.setLayoutProperty(id, "visibility", "none");
      }
    },
    // 设置地图中心点和缩放级别
    setCenterZoom(center, zoom) {
      if (this.map) {
        this.map.setCenter(center);
        this.map.setZoom(zoom);
      }
    },
    // 重置默认中心点
    resetCenter() {
      if (this.opts) {
        this.setCenterZoom(this.opts.center, this.opts.zoom);
      }
    },
    // 重置地图大小
    resize() {
      if (this.map) {
        this.map.resize();
      }
    },
    // 简单获取线路中心点
    getCentroid(coordinates) {
      const midIndex = Math.floor(coordinates.length / 2);
      const coords = coordinates[midIndex];
      if (Array.isArray(coords[0])) {
        const index = Math.floor(coords.length / 2);
        return coords[index];
      }
      return coords;
    },
    // 获取n条线路的所有点
    getPoints(coordinates) {
      let points = [];
      if (coordinates && coordinates.length) {
        if (Array.isArray(coordinates[0][0])) {
          coordinates.forEach(v => {
            if (Array.isArray(v)) {
              points = points.concat(v);
            }
          });
        } else {
          points = coordinates;
        }
      }
      return points;
    },
    // 关闭弹窗
    removeAllPopup() {
      if (this.popup) {
        this.popup.remove();
        this.popup = null;
      }
    },
    // 简易弹窗
    showPopup({ content, position, options = {} }) {
      this.removeAllPopup();
      this.popup = new mapboxgl.Popup(options)
        .setLngLat(position)
        .setHTML(`<div style="padding: 10px 15px 0 15px;">${content}</div>`)
        .addTo(this.map);
    }
  },
  render(h) {
    return h("resize-detector", {
      style: this.styles,
      on: {
        contextmenu: e => {
          e.preventDefault();
          return false;
        },
        resize: () => {
          this.resize();
        }
      }
    });
  }
};
