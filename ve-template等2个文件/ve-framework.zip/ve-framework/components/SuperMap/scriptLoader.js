const SCRIPT_URL = "./static/superMap/libs/SuperMap.Include.js";
let loadScriptPromise = null;
export default function() {
  if (loadScriptPromise) {
    return loadScriptPromise;
  } else if (window.SuperMap) {
    return new Promise(resolve => {
      resolve();
    });
  }
  loadScriptPromise = appendScriptTag(SCRIPT_URL);
  return loadScriptPromise;
}

function appendScriptTag(url) {
  return new Promise(resolve => {
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = url;
    script.onerror = function() {
      document.body.removeChild(script);
      setTimeout(() => {
        appendScriptTag(url);
      }, 3000);
    };
    script.onload = function() {
      window.loadScriptResolver = resolve;
    };
    document.body.appendChild(script);
  });
}
