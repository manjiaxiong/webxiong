# SuperMap 组件 [Deprecated] 废弃

## 推荐使用 MapBox 组件
