import load from "./scriptLoader";
const maphost = "http://218.28.140.213:10521";
const baseMapUrl = maphost + "/iserver/services/map-mongodb/rest/maps/China";
// const restmapurl = maphost + "/iserver/services/map-ZhengZhou/rest/maps";
const restdataurl = maphost + "/iserver/services/data-ZhengZhou/rest/data";
export default {
  name: "supermap",
  props: {
    styles: {
      type: Object,
      required: false,
      default: () => ({
        width: "100%",
        height: "100%"
        // height: "calc(100vh - 84px)"
      })
    },
    option: {
      type: Object,
      required: false
    }
  },
  watch: {
    "option.center": {
      handler: function(newVal, oldVal) {
        if (newVal != oldVal) {
          this.instance.setCenter(newVal, 1);
        }
      }
    },
    "option.zoom": {
      handler: function(newVal, oldVal) {
        if (newVal != oldVal) {
          this.instance.setCenter(this.instance.getCenter(), newVal);
        }
      }
    }
  },
  data() {
    return {
      instance: null,
      opts: null
    };
  },
  mounted() {
    this.initMap();
  },
  methods: {
    initMap() {
      const defaultSettings = {
        baseMapUrl,
        scales: [
          1 / 18055.9,
          1 / 27083.9,
          1 / 36111.9,
          1 / 54167.9,
          1 / 72223.9,
          1 / 108335.9,
          1 / 144447.9,
          1 / 216671.85,
          1 / 288895.8
        ],
        zoom: 11,
        center: [113.670443, 34.756572]
      };
      const opts = Object.assign({}, defaultSettings, this.option);
      this.opts = opts;
      if (!this.instance) {
        const dom = this.$el;
        load().then(() => {
          this.instance = new SuperMap.Map(dom, {
            // theme: null,
            controls: [
              // new SuperMap.Control.Zoom(),
              new SuperMap.Control.Navigation({
                dragPanOptions: { enableKinetic: true }
              })
            ],
            allOverlays: true,
            minZoom: 10,
            maxZoom: 18
          });
          const layer = new SuperMap.Layer.TiledDynamicRESTLayer(
            "底图",
            opts.baseMapUrl,
            { transparent: true, cacheEnabled: true },
            // scales: opts.scales
            { maxResolution: "auto" }
          );
          layer.events.on({
            layerInitialized: () => {
              this.instance.addLayers([layer]);
              this.resetCenter();
              // this.setCenter(opts.center, opts.zoom);
              this.$emit("ready", this.instance);
            }
          });
          this.instance.events.on({
            zoomend: () => {
              this.$emit("zoomend", this.instance.getZoom());
            },
            moveend: () => {
              this.$emit("moveend");
            }
          });
        });
      }
    },
    getPoint(point) {
      //如果坐标不是平面坐标则转换为平面坐标
      if (point.length == 2 && (point[0] < 180 && point[1] < 90)) {
        point = new SuperMap.LonLat(...point).transform(
          "EPSG:4326",
          "EPSG:3857"
        );
      }
      return point;
    },
    setCenter(center, zoom) {
      this.instance && this.instance.setCenter(this.getPoint(center), zoom);
    },
    resetCenter() {
      if (this.opts) {
        this.setCenter(this.opts.center, this.opts.zoom);
      }
    },
    /**sql查询公用方法
     *@param opts 查询需要用到的参数
     * {
     *   layerName:'',//图层名称，必填
     *   fields:[],//要查询的字段，默认为全部字段
     *   serviceUrl:'',//超图服务地址，必填
     *   joinItems:[],//关联查询时需要的查询条件，可不传
     *   attributeFilter:''//sql查询时的查询条件，可不传
     *
     * }
     */
    queryBySQL(opts, type = "features") {
      const queryParam = new SuperMap.REST.FilterParameter({
        name: opts.layerName,
        fields: opts.fields || null,
        joinItems: opts.joinItems || null,
        attributeFilter: opts.attributeFilter || ""
      });
      const features = type === "features";
      const condition = {
        queryParameter: queryParam,
        datasetNames: opts.datasetNames || []
      };
      const queryBySQLParams = new SuperMap.REST[
        features ? "GetFeaturesBySQLParameters" : "QueryBySQLParameters"
      ](
        features
          ? typeof opts.toIndex !== "undefined"
            ? {
                ...condition,
                toIndex: opts.toIndex
              }
            : condition
          : {
              queryParams: [queryParam]
            }
      );
      return new Promise((resolve, reject) => {
        const queryBySQLService = new SuperMap.REST[
          features ? "GetFeaturesBySQLService" : "QueryBySQLService"
        ](opts.serviceUrl || restdataurl, {
          eventListeners: {
            processCompleted: featuresEventArgs => {
              const result = featuresEventArgs.result;
              resolve(
                features ? result.features || [] : result.recordsets || []
              );
            },
            processFailed: e => {
              if (
                e.error.code == "404" ||
                e.error.errorMsg == "null" ||
                e.error.errorMsg == "NULL" ||
                e.error.errorMsg == "Null"
              ) {
                reject("数据加载时出错，请联系管理员！");
              } else {
                reject(e.error.errorMsg);
              }
            }
          }
        });
        queryBySQLService.processAsync(queryBySQLParams);
      });
    }
  },
  render(h) {
    return h("div", {
      style: this.styles
    });
  }
};
