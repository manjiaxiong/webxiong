<template>
  <div class="grid-container flex-vertical" :class="{ columnsX: columns > 2 && !fullscreen }">
    <div class="toolbar" v-if="topbar">
      <div class="btns">
        <div
          class="btn"
          :class="{active: ccolumns === item.columns && crows === item.rows}"
          :key="key"
          v-for="(item, key) in btns"
          @click="changeGrid(item)"
        >
          <i class="iconfont" v-html="item.icon"></i>
        </div>
      </div>
    </div>
    <div class="auto-fill" :style="gridStyle">
      <div class="grid-content" v-for="k in (crows * ccolumns)" :key="k">
        <slot :index="k"></slot>
      </div>
    </div>
  </div>
</template>

<script>
import screenfull from "screenfull";
// 兼容screenfull 4.x
const enabled = screenfull.isEnabled || screenfull.enabled;
export default {
  props: {
    topbar: {
      type: Boolean,
      default: true
    },
    gap: {
      type: Number,
      default: 6
    },
    rows: {
      type: Number,
      default: 2
    },
    columns: {
      type: Number,
      default: 2
    }
  },
  data() {
    return {
      crows: this.rows,
      ccolumns: this.columns,
      init: false,
      fullscreen: false,
      btns: [
        {
          icon: "&#xe617;",
          rows: 1,
          columns: 2
        },
        {
          icon: "&#xe619;",
          rows: 2,
          columns: 2
        },
        {
          icon: "&#xe616;",
          rows: 2,
          columns: 3
        },
        {
          icon: "&#xe615;",
          rows: 2,
          columns: 4
        },
        {
          icon: "&#xe61e;",
          rows: 4,
          columns: 4
        }
      ]
    };
  },
  computed: {
    gridStyle() {
      return {
        gridTemplateColumns: "repeat(" + this.ccolumns + ", 1fr)",
        gridTemplateRows: "repeat(" + this.crows + ", 1fr)",
        gridGap: this.gap + "px"
      };
    }
  },
  methods: {
    created() {
      if (this.init) {
        return false;
      }
      this.init = true;
      if (enabled) {
        screenfull.on("change", this.fullscreenchange);
      }
    },
    destroyed() {
      this.init = false;
      if (enabled) {
        screenfull.off("change", this.fullscreenchange);
      }
    },
    changeGrid(item) {
      if (this.crows === item.rows && this.ccolumns === item.columns) {
        return false;
      }
      this.crows = item.rows;
      this.ccolumns = item.columns;
      this.$nextTick(() => {
        this.$emit("change", this.crows, this.ccolumns);
      });
    },
    fullscreenchange() {
      this.fullscreen = screenfull.isFullscreen;
      if (!this.fullscreen) {
        this.$emit("fullscreenchange");
      }
    }
  },
  activated() {
    this.created();
  },
  created() {
    this.created();
  },
  destroyed() {
    this.destroyed();
  },
  deactivated() {
    this.destroyed();
  }
};
</script>

<style lang="scss">
body[data-theme="night"] {
  $bg-color: #304156;
  .grid-container {
    .toolbar {
      background-color: $bg-color;
    }
    .title-header {
      background-color: $bg-color;
    }
    .el-icon-close {
      background-color: lighten($bg-color, 18%) !important;
    }
    .btn:hover {
      background-color: lighten($bg-color, 8%) !important;
    }
  }
}
</style>

<style lang="scss" scoped>
.grid-container {
  height: 100%;
  .map-container {
    width: 100%;
    height: 100%;
    flex: 1;
    .map {
      height: auto;
    }
  }
  &.columnsX {
    .title-header {
      .title {
        flex: 1;
        display: flex;
        justify-content: space-between;
        .left {
          white-space: nowrap;
        }
        .center {
          display: none;
        }
      }
    }
  }
  .toolbar {
    height: 40px;
    background-color: #2394f2;
    // background-color: #67C23A;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-bottom: 6px;
    .btns {
      display: flex;
      margin-right: 10px;
      border-radius: 4px;
      overflow: hidden;
      .btn {
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 50px;
        height: 30px;
        background-color: #fff;
        border-left: 1px solid #ddd;
        i {
          color: #999;
          font-size: 20px;
          font-weight: bold;
        }
        &:first-child {
          border-left: 0;
        }
        &:hover,
        &.active {
          background-color: #eee;
        }
      }
    }
  }

  .auto-fill {
    display: grid;
    overflow: hidden;
    .grid-content {
      overflow: hidden;
      height: 100%;
      background-color: #b9d5ea;
      border: 1px solid #ccc;

      display: flex;
      align-items: center;
      justify-content: center;

      .plus {
        cursor: pointer;
        width: 56px;
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px dashed #fff;
        border-radius: 10px;

        i {
          color: #fff;
          font-size: 30px;
        }

        &:hover {
          border-color: #eee;
          i {
            color: #eee;
          }
        }
      }
    }
  }
}
</style>
