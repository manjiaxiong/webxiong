const filterNode = (value, data, caseSensitive = false, exclude = []) => {
  let { id, filter } = data;
  if (id && filter) {
    if (Array.isArray(value)) {
      return !value.includes(id);
    } else {
      if (!value) {
        return !exclude.includes(id);
      }
      if (!caseSensitive) {
        value = value.toLowerCase();
        filter = filter.toLowerCase();
      }
      return !exclude.includes(id) && filter && filter.indexOf(value) !== -1;
    }
  }
  return true;
};

export { filterNode };
