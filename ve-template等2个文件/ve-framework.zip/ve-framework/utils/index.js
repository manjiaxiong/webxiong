/**
 * Created by jiachenpan on 16/11/18.
 */

export function parseTime(time, cFormat) {
  if (arguments.length === 0) {
    return null;
  }
  const format = cFormat || "{y}-{m}-{d} {h}:{i}:{s}";
  let date;
  if (typeof time === "object") {
    date = time;
  } else {
    if (typeof time === "string" && /^[0-9]+$/.test(time)) {
      time = parseInt(time);
    }
    if (typeof time === "number" && time.toString().length === 10) {
      time = time * 1000;
    }
    date = new Date(time);
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  };
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key];
    // Note: getDay() returns 0 on Sunday
    if (key === "a") {
      return ["日", "一", "二", "三", "四", "五", "六"][value];
    }
    if (result.length > 0 && value < 10) {
      value = "0" + value;
    }
    return value || 0;
  });
  return time_str;
}
// 获取当月的第一天
export function getMonthFirstDay() {
  var date = new Date();
  date.setDate(1);
  var month = parseInt(date.getMonth() + 1);
  var day = date.getDate();
  if (month < 10) {
    month = "0" + month;
  }
  if (day < 10) {
    day = "0" + day;
  }
  return [date.getFullYear(), month, day].join("-");
}

export function formatTime(time, option) {
  time = +time * 1000;
  const d = new Date(time);
  const now = Date.now();

  const diff = (now - d) / 1000;

  if (diff < 30) {
    return "刚刚";
  } else if (diff < 3600) {
    // less 1 hour
    return Math.ceil(diff / 60) + "分钟前";
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + "小时前";
  } else if (diff < 3600 * 24 * 2) {
    return "1天前";
  }
  if (option) {
    return parseTime(time, option);
  } else {
    return (
      d.getMonth() +
      1 +
      "月" +
      d.getDate() +
      "日" +
      d.getHours() +
      "时" +
      d.getMinutes() +
      "分"
    );
  }
}

//传入的分钟数  转换成天、时、分
export function formatMinute(StatusMinute) {
  var day = parseInt(StatusMinute / 60 / 24);
  var hour = parseInt((StatusMinute / 60) % 24);
  var min = parseInt(StatusMinute % 60);
  StatusMinute = "";
  if (day > 0) {
    StatusMinute = day + "天";
  }
  if (hour > 0) {
    StatusMinute += hour + "小时";
  }
  if (min > 0) {
    StatusMinute += parseFloat(min) + "分钟";
  }
  //三元运算符 传入的分钟数不够一分钟 默认为0分钟，else return 运算后的StatusMinute
  return StatusMinute === "" ? "0分钟" : StatusMinute;
}

// 格式化时间
export function getQueryObject(url) {
  url = url == null ? window.location.href : url;
  const search = url.substring(url.lastIndexOf("?") + 1);
  const obj = {};
  const reg = /([^?&=]+)=([^?&=]*)/g;
  search.replace(reg, (rs, $1, $2) => {
    const name = decodeURIComponent($1);
    let val = decodeURIComponent($2);
    val = String(val);
    obj[name] = val;
    return rs;
  });
  return obj;
}

/**
 *get getByteLen
 * @param {Sting} val input value
 * @returns {number} output value
 */
export function getByteLen(val) {
  let len = 0;
  for (let i = 0; i < val.length; i++) {
    // eslint-disable-next-line
    if (val[i].match(/[^\x00-\xff]/gi) != null) {
      len += 1;
    } else {
      len += 0.5;
    }
  }
  return Math.floor(len);
}

export function cleanArray(actual) {
  const newArray = [];
  for (let i = 0; i < actual.length; i++) {
    if (actual[i]) {
      newArray.push(actual[i]);
    }
  }
  return newArray;
}

export function param(json) {
  if (!json) return "";
  return cleanArray(
    Object.keys(json).map(key => {
      if (json[key] === undefined) return "";
      return encodeURIComponent(key) + "=" + encodeURIComponent(json[key]);
    })
  ).join("&");
}

export function param2Obj(url) {
  const search = url.split("?")[1];
  if (!search) {
    return {};
  }
  return JSON.parse(
    '{"' +
      decodeURIComponent(search)
        .replace(/"/g, '\\"')
        .replace(/&/g, '","')
        .replace(/=/g, '":"') +
      '"}'
  );
}

export function html2Text(val) {
  const div = document.createElement("div");
  div.innerHTML = val;
  return div.textContent || div.innerText;
}

export function objectMerge(target, source) {
  /* Merges two  objects,
     giving the last one precedence */

  if (typeof target !== "object") {
    target = {};
  }
  if (Array.isArray(source)) {
    return source.slice();
  }
  Object.keys(source).forEach(property => {
    const sourceProperty = source[property];
    if (typeof sourceProperty === "object") {
      target[property] = objectMerge(target[property], sourceProperty);
    } else {
      target[property] = sourceProperty;
    }
  });
  return target;
}

export function toggleClass(element, className) {
  if (!element || !className) {
    return;
  }
  let classString = element.className;
  const nameIndex = classString.indexOf(className);
  if (nameIndex === -1) {
    classString += "" + className;
  } else {
    classString =
      classString.substr(0, nameIndex) +
      classString.substr(nameIndex + className.length);
  }
  element.className = classString;
}

export const pickerOptions = [
  {
    text: "今天",
    onClick(picker) {
      const end = new Date();
      const start = new Date(new Date().toDateString());
      end.setTime(start.getTime());
      picker.$emit("pick", [start, end]);
    }
  },
  {
    text: "最近一周",
    onClick(picker) {
      const end = new Date(new Date().toDateString());
      const start = new Date();
      start.setTime(end.getTime() - 3600 * 1000 * 24 * 7);
      picker.$emit("pick", [start, end]);
    }
  },
  {
    text: "最近一个月",
    onClick(picker) {
      const end = new Date(new Date().toDateString());
      const start = new Date();
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
      picker.$emit("pick", [start, end]);
    }
  },
  {
    text: "最近三个月",
    onClick(picker) {
      const end = new Date(new Date().toDateString());
      const start = new Date();
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
      picker.$emit("pick", [start, end]);
    }
  }
];

export function getTime(type) {
  if (type === "start") {
    return new Date().getTime() - 3600 * 1000 * 24 * 90;
  } else {
    return new Date(new Date().toDateString());
  }
}

export function debounce(func, wait, immediate) {
  let timeout, args, context, timestamp, result;

  const later = function () {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp;

    // 上次被包装函数被调用时间间隔last小于设定时间间隔wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last);
    } else {
      timeout = null;
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args);
        if (!timeout) context = args = null;
      }
    }
  };

  return function (...args) {
    context = this;
    timestamp = +new Date();
    const callNow = immediate && !timeout;
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait);
    if (callNow) {
      result = func.apply(context, args);
      context = args = null;
    }

    return result;
  };
}

/**
 * This is just a simple version of deep copy
 * Has a lot of edge cases bug
 * If you want to use a perfect deep copy, use lodash's _.cloneDeep
 */
export function deepClone(source) {
  if (!source && typeof source !== "object") {
    throw new Error("error arguments", "shallowClone");
  }
  const targetObj = source.constructor === Array ? [] : {};
  Object.keys(source).forEach(keys => {
    if (source[keys] && typeof source[keys] === "object") {
      targetObj[keys] = deepClone(source[keys]);
    } else {
      targetObj[keys] = source[keys];
    }
  });
  return targetObj;
}

export function uniqueArr(arr) {
  return Array.from(new Set(arr));
}

export function isExternal(path) {
  return /^(https?:|mailto:|tel:)/.test(path);
}

export function json2param(json) {
  if (!json) {
    return "";
  }
  return Object.keys(json)
    .map(key => {
      if (typeof json[key] === "undefined") {
        return "";
      }
      return encodeURIComponent(key) + "=" + encodeURIComponent(json[key]);
    })
    .filter(v => !!v)
    .join("&");
}

export function zero(t) {
  return t < 10 ? "0" + t : t;
}

export function range(start, end) {
  let result = [];
  if (Number.isInteger(start) && Number.isInteger(end)) {
    if (start === end) {
      return [start];
    }
    const min = Math.min(start, end);
    const max = Math.max(start, end);
    for (let i = min; i <= max; i++) {
      result.push(i);
    }
    if (start > end) {
      result = result.reverse();
    }
  }
  return result;
}

export function toThousands(num) {
  return (num || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, "$1,");
}

export function formatFileSize(fileSize) {
  var arrUnit = ["B", "KB", "MB", "GB", "TB", "PB"];
  var powerIndex = Math.floor(Math.log2(fileSize) / 10);
  var len = arrUnit.length;
  powerIndex = powerIndex < len ? powerIndex : len - 1;
  var sizeFormatted = (fileSize / Math.pow(2, powerIndex * 10)).toFixed(2);
  var sizeArr = sizeFormatted.toString().split(".");
  if (sizeArr[1] === "00") {
    sizeFormatted = sizeArr[0];
  }
  return [sizeFormatted, arrUnit[powerIndex]].join(" ");
}

/**
 * 日期字符串格式化
 * @param dateNumber {number} 20180301 201812261302 20181226130249 1302 130249
 * @return {string} '2018-03-01' '2018-12-26 13:02' '2018-12-26 13:02:49' 13:02 13:02:49
 */
export function formatDateString(dateNumber) {
  if (isNaN(dateNumber)) return dateNumber;
  let dateString = dateNumber.toString();
  if (dateString.length < 8) {
    if ([4, 6].includes(dateString.length)) {
      let h = dateString.substr(0, 2);
      let i = dateString.substr(2, 2);
      let s = dateString.substr(4, 2);
      return s ? `${h}:${i}:${s}` : `${h}:${i}`;
    }
    return dateNumber;
  }
  let y = dateString.substr(0, 4);
  let m = dateString.substr(4, 2);
  let d = dateString.substr(6, 2);
  if (dateString.length > 8) {
    let h = dateString.substr(8, 2);
    let i = dateString.substr(10, 2);
    let s = dateString.substr(12, 2);
    return s ? `${y}-${m}-${d} ${h}:${i}:${s}` : `${y}-${m}-${d} ${h}:${i}`;
  }
  return `${y}-${m}-${d}`;
}

// 默认车辆图标
export function getCarIcon({ vehStatus }) {
  return getCarIconBase64(vehStatus);
}

const carIconBase64 = {
  0: {
    normal:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAMAAADSpG8HAAAC9FBMVEUAAAAZGA2ZemIzLCkCAgKCX0IjKBsiHhwUEg0gEhE4OiqgfWV8XEGPdmIgJRl9dXFMPzVLQTsxKCEbFw80HBOEaVDErqMwNCWLcl4oLB6BZlGgino1Nil2Z1RuUjqEa1l2XUhgSDCTk5WeinyHfHVdUkkfIxlxWko4OC5gVkxLSUlOOidcYF9gTDxWTjI7Lh5oV05BPTVGNCNvYl1IMiMqHhVIRkU7NCxHQDw0KhwfGhAaFw4KCQgCAgIEAwTq3dXYwbNSUD7eyrzUvqzi0cTgzsHXuaxraFzs3tjm0szl1svcx7mhfV+eeFk6NSTw4uDp29Po2tHn2M/m183k1craxbbRva3TtabFrpypknyJh3xua15OTDs7OzIqJBXq19Tlz8nhyMLfzL7exrzWwLLYuq7MuqvRuajLsJrJp5HAn4mSkYfCnoOIhXqlj3m1knWUiXSCf3S6kHJ0cmWlgWSxhGOWd1ukeldiX01uW0NWUkB2Yz9FRj9MRzpLRDUzMx8fHxEbGxHt39ro09Dj08fj0sbjzMTcxrfWxLfTvKvSu6nVuKmyrafOtaPRsKGhoJW3pJHApY+ynYvGnIuum4aomYOoloO+m4GMi4GnkX6fkXyZi3i2lHari3KdhW+vim15d2uUgGp3c2iwiGeohGWffmNxbl+tfVhqZ1ebdVWQcVVmX097ZE6EcExcWkp8aUReVURMQDBHQC0xMicmJRMmIBMNDQf////19frA1NTj08icssbbybzRxLncwrjbuLXSwbO5t7DRsaejopnAp5a8w5XHr5S9pZSwrJGzoI+yn46Zloy5n4u+o4nEpYe4m4W4mH6rlnq9lnmfjHmainehiXOyjXCPgHCxjG+fim9+e26OfmubiGiEe2iBdWaYhGWbfGKFc2CWel96b1yTclmNeliEcFh8bVaNbVRsYlCVbk1TVEtWV0pkWklTTjxOSDxvXTlrWjhtUDhFRDhZSDZXSDVQQS8zLSIoKSEZFg0UFAsCAgK+A3RSAAAAP3RSTlMAZ+NXBPPcUUM7/uro0s+tgHJoV0n8+vLn59/e3drY087KxsW+vr27tLOysbCrqaino6OgkI+GhHp3bWEgGRTuZRq5AAACQ0lEQVQoz2KgALCYgggUISEDfn5jCw4OYXNNK0YQsBYW5VWWlpBS0BWCqdE6tD+x/did6o8f1q+trl6/9un9i5GREyc5u2XmlHoqQcwTOdpz5Pikk2lhYWFpaQc69jglpmyo89u67efM5Ii5EdtVwYr0dlbGutfea4738AeCJg+PIIe6hoa4uG1bw1w6Is6XsoMUyU/+/nrR5+vxAYGBAfZA4GGfPHuG45Ytcb/XuDk7ORdpgxQx5ccWRsdMiw/xCg4KAqnzSFg44+Ayv7jGjTnnsjIy5cCKltbkujueanZpbQGqCw4KaPKct+Jwz+ns7Nolc0pWLuYBKyqriXKvmpDgCgStu4Dq7D3zKqJys/v73z+54eNbzgpSBBD3C7CiNienJFdXF5eWkEDPyA0LFtwqjKotuwZXtCoWaN2UxHZvb6C6JBcXr4TId+7Ry4qL65bOhylierAZ6PDLyQ6hod7e3qGhTl5tVzetW7d6xZuN85f4rFwOdhNvfmPxopjbDs4pDkCQ0pnusG+hX4yjY8XmL5d8X5WUKoIUqWf9+hEd+7K7K73L2dm5M703I/x5vaOjY1XDmqI5F3yXG4EUAWay+5Pf6rcPw93cUlNT3dy6w8P7Kuv96rkavxWVzFu1N4IDpIjzxOTpWWdmXpk6dVbB3YKC2bOmTcm7+azy66ZHPmWLM3aYQVKBjmdf5tm8xzJsklwV4mxsfHxqGoayOXPzp0/sFVNhh6UVZkEBAUERYCqzYbeDCulbcjIzM3PaEp9OATTq4bnJ1m3xAAAAAElFTkSuQmCC",
    small:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAQCAMAAAAhxq8pAAAAaVBMVEUAAAClinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinulinufUBmMAAAAInRSTlMA+PKonuzEUDjgtGHnzH/62767l46HcloI6LF5QT4uKiUWE/+qIAAAAHhJREFUGNO1yEcSwjAUBNGxvoKFgnMgw9z/kMgscLGmeKuuxp9crDFGKbljp+3kvXPzkPTnWU5O6brQjGOobyh8xS9tAHBWjPuPTLICIovkbA9FNwaZh9MTYG5JZ7hxis3CI9BpkqmvCr9lbyyAVZEBb4+KzRW/egHw2ApUdtdjDgAAAABJRU5ErkJggg=="
  },
  1: {
    normal:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAMAAADSpG8HAAAC91BMVEUAAAAAJQskNR8JNS8AAAAHwgAu2CIAZQIDGgccFA8aTDwVvRAtwyUNqQgcZhgsXSUQQQ0BJQcHMwIpJw4BAQCM63sRRDct5xwHswAMOzAv4SAIxAAr3xofuhZWzUwYRTMqnDEvtyRDvjgKMSwBjQCWkJRdxFNnm2A0cy8KLSgknR0hQTEydjNDYzFhjFpocEsXig9wimhcTi45hy0kTy1Vg0hQLx0EPABCSkAYSxwATQc0UjIFCwOU/4mt/6YP7wXI/8Gh/5eK/4CG/3tJfla5/7K3/7Ck/5tL/0Yq/h0ANxDi/9DG/77D/7vA/7jG/7Cz/6yb/5Gd/4WY/4GF/oFrl3Zy9WtTh2Fj319F2kklakMgbjgOSDAx/yoALBgc8RECIQ7N/8bL/7Sx/6m6/6Oq/6Gm/6Cb/5aX/410oYRuln+U/3tklXNZjGtY019Ou15y/1RV/0YlZUUs1j1E/jk8/ysiYisWZiMFUh8CsR0i6hkj/xUd2RMa+hAAPgwK+gDa/8nT/8bW/7/a/73O/7m9/7W//6qLrZyt/5qk/5GY/JB/rI2k/4eK8YeO/3aI/3N6/21w/2Jf/2Jt72Jj5GJNemJLhmBEgVtOxlhR1lZAgVE2aFEzdE0ye0w/5Uk+nkdGzUY1TUVG4EQ+u0ElXzsicTkhZjgsijYsrDI37i0kgiwhSCwAoxsTnBsY0hALgBAAEQgN4gcHowUS/wT/////8PeWt8HI47WlxK/K/6aUuqGm/52f7Zyx/5qt/5XCupS9/5C+pI+U9456m4uI9oSS/4CE/4B+9nqa/3hkjHBVgWxUxWGA/2BNtl5WvFtS4Vll/1hGpFhY2ldd/FRa71Ne+lI6eFJAXlFq/05Ks01U2ExS9EcxTUAldz481zssRDszyDcfWTc9+jAXyzAx2S4PYSwIUiscOSkitygVMSgLwyYCvCEfpiEDyCAAvR4i3xwe1xwQaxoj9xgQShcKaBYKQBYMWBQU7BAMbA8X8A0J1wsFdgsAAABw6AJ/AAAAPXRSTlMAZ1XZBPPiqUM7/v7d04B2aFdSSRb68uzp5+fn5N/e3drT0MzKxsW+vr27tLOysLCrqqmno6CQj4aEd3Ig/fi2ogAAAkNJREFUKM9ioACwmIMIFCEBYz1DU34ODkFLHUYIEORWUpPjkeU1EICp0T1xYGfnpOLKNWveva2sfP3qcfG8eZGXI0J6LhR6+qtCzBPef2by5IiI4yEhR3p7D3U5uqfYrir/5rUh4VZH2MqwLRpgRUbbN62etWR+c1ODNxA0NDa22JbHxdXVbfBysusKu10rBFKkWPD1evjDm82+vr4+Pg4ODokOHeeyor28vP68CT6WHlLKDlLEFrv6pMuyvCY3N9dWPz+gukT/xZk7plXUJfwo9PCYNJEXrKjqTqhLdESLXXJAAEidb2LSglntu7ozD5fVxsbbV0uDFMnULAx1WTrFPy011S4ZqMzVISlyblZOZnd7WY1nvH09K0gRQOLrwIraHN3d01LtgOr8/Bfdzc3NzclCUiS17j7Qukspgenpju670+zsXNsWRU+dPi38VHkVXBHb++c5LssW7LXNCHR0dAwMdHdLufd09pxr02d/9Pz0036zBEgRT2xCePiSxZ1OtrYZGba2Ts62+x48K4qKmhOzvsR+Y221CkiR1o2El1O5lh91dnZ2cnJydp4wsW9FTBFQVRx36aMS+83gcALMbNumz8tXrcgODgrqCQoKDs7O7ltbURETE/e7tOrJrz1hHCBFnAcLPAqvzJyRl3c6/+LZ/PwZM89HFr9Yu/7Lh+8bqydstYCkAv2k/gKPyPnyzJJcc8WYmZmVNbVNFDxWxpZc7RdVZ4KlFSZrPj5+YWAqs2ESgQqxW3EKMTFxArnEAgDLUd+tnLfEzAAAAABJRU5ErkJggg==",
    small:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAQCAMAAAAhxq8pAAAAbFBMVEUAAABpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBpwmBS+vtJAAAAI3RSTlMA+PKonuzEOOC0YVPnzH/62767l46HclwI6LF5SkE+LiolFuDg090AAAB3SURBVBjTtchHEsIwAATBVbRQcg7ksP//IzIHXJwp92lqsJOrNcZIqR7YaDs6F8LUJ/19luNF6qrQjIOv7iic4I/GAzhLxu1HJrUASs0qZ3so2sGrqT+9AOaGDIarIFnPPAKtJpk6Ubg1O2MBLJL0+HgK1jf86w0ekQqcSHfyLAAAAABJRU5ErkJggg=="
  },
  2: {
    normal:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAMAAADSpG8HAAAC91BMVEUAAAAABiUJFSMDaL4aDDMpdrMkNDoLIzMdEhQkarEqi9AZDC81VXBkfYkANmwmXIIdQ2EoSFknO0kCFi8DDiQuGg8AAQCDw+QgFUEqkdoAYbMtjtQNabcyfLUaDzguhckxiMtVlsUfG0IyXpUHWJ9BhbUaZKEASI2WlZFblb1khJcYDSsjZZUjIz8xXWFNbmNcUisBJlUnMkxMcX9QMBsAIjxBR0ocL0gDIEoECQvA5/+GyfpMWHuw3v+s3P6n2v6b1f6T0f6Ax/u75f+Q0PuNz/sfiuNtdpQmNGnQ+v+38v+x7v+Z4v+y4P911P+g1/6V1v5GrvyIxPhyteskj+YTgt9ro9lQk9RVdrMJQa8qKmE3M0kAET0DACu/+P+i6P+44/+14f+G3f+D2v+B1/8spv+j2f6YzfULhu8XheEkh9shf8xYgr6Ljqt0d5VrcI9ZYoZMVYBHTHo4PXInL2MIEE4fGEYGEzgFCSLJ9v/G8P/H6v+o6v/C6P+85v981/9RzP9cwf8GkP2d1fxNpvv///gynPcdk/Uum/FfsfA3nPBCou4smO6Ov+pKitplo9dOic8pgM88gs5hmM1aj80deMVOisQUT7lDcKGChKArX58EOJ93fZ5FYZpeZIkyUoRVXoNXV3sqS3sTQXgpN28rLmYbMmMTMmMnO18hNVwpMFsmJE8SIkkkLEYSD0QABTccGzMAABcAAAi7/P+m9/+Q9f+u8P+G5P+P3v943v+m3P+A0v9g0P9pxf9Nw/9Yuf82qP9Epv8Wn/8Tnv+Z0P4elfp7yPlos/l5wvdjp/dwvPaPzfVUsfNVo/GMwe+DvO6cyOx2uOxTqOleqOVssOQ7meO04N86lN8HetpclNgde9RWms9fjs5Gi82Wsss2bstfickXbskzbsinrMIjXL89er6XnLhFfLZdhbVIeK8baq1RfKwSRKIEV54TVZoaS5Vja5EfVpG/yJC9tYQ3Q3c+RHQNOW85OWgTOmY+O2NEQlwVH1wRK1OQQr8ZAAAAOnRSTlMAaETz3NdYUjv+5M+5raqpgHZvYldOFvry7Onn5+fn4+De3drY0M7KxsW+vbu0srCpqKOgkI+GhHcgpViXGgAAAjlJREFUKM9ioASYYogI8fPyGgsyMYmY8zCCgbAIp6qmoiyrGr8wTI3ezq1bAk7efzN7duT0yMjI6U8e9fWFd/Y7bd8feMhbA6JG9NOe4Cv9YeeDgs719qanNzvEn1607E/5xorbPsHXL7bygBUZXHu31mbVjM1xlZ5AUFlV5eW6LDY2JmZTufWu9OBL7ewgRawN5b8KVr+Oc3Z2rrMCgupanxd5HuvXx2yalRJ0JCiVD6RIvm1tvk3J5DhbW9/EBJC62m3P8x4Xromp+BHY0nK8UQWkiCsr2t3GI8zL3s4Ooq7aa1pR7rOZc2aucGsLCT0qA1aUDVbk7Z+WBlQHVGblFf4lz31Obu6K7A63zAxmkCKAJKcCFS0Jq3FwaPZPsweqS/AOXzKvYN6H/JUIRdIgRR6T4x0dHR0c/P3t7X1rwj2KCgsXLFyZ1eMWClGkMHED0OHTfFxdHAMCAoAqbePv/v5e/LXo5/KeELfQJilwEHRVLChY9XKHtauLi4urq7WTi8/T0qiSpcVliw9k3gg5rA5SpLNv44aFq+fvdnKyBgInpxOn/Gati4qKWhr7KrW7O7QJHE6Amdx7u2b+ohn1yclJSUnJKSn1fn7vS0vXlcV+Sw2Z9PBCMBNIEcfnhsAzl6fk3HmQEzE3IiIiZ8rNCZM4Py5ePjHrVvveVjNIDOt7+zWenTBXiUWurFiChYWbW1vXSPng1a7AzmPiWqKwtMImJCAgCDLVkl0MKmRowcHOxsYB5BILAGV13KaCvVGdAAAAAElFTkSuQmCC",
    small:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAQCAMAAAAhxq8pAAAAb1BMVEUAAAAkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeQkjeTDfXW2AAAAJHRSTlMAqPjCtDj68Ozn4H1hU/LMvKCcBtuXi1zGkIRzcUpBPi4qJRZjMdzMAAAAe0lEQVQY07XIRxLCMBAF0ZFkKyfLiRz//c+IxMIFa4q36mr6k4vQWinF7h+viIO1IZzmNGxPYDnH0lcFZu/7W5tW4svkRyKnYPi2DBKrk7GVOSe6SiyeHefuSQQ3AUGjCRFyhSHKA4CUJefctsx6R0RjBDy9PTjklX71AoV0CyxBzfL8AAAAAElFTkSuQmCC"
  },
  3: {
    normal:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAYAAADlep81AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAZDSURBVEiJzZZbjFVXGcd/a9/O3uecOWfuw9xkoBUsSCFtoSqlUlu1UzHVJlUbTZRGkyYmlgdf1BcjafpgDNHEShHThGhp1dCmkeKDCBWKpWVAS4Fxpsytc2Nu57rve5/lw54ZOljSJ5N+yZe119rr8tvft/9rLSGl5CNlUkr+T1DaPQb7bmz7MBaxBCOEAGBnU/aJL3T3fNbYuMmq1TUE/siIMzA8cPn4+HAfQFqJm9e3rdq0saN985GLF/5y09kjivu76g8rnZ94W1/VYacjv90eGZBeqaQUnHJ1NE71v+rGx0/OV/ffFOjxLZ955XdffPDLsn09oqUBOXcFMX+eK++eY3D0MuUo6dthQkZVuOYn9YwBKd3CtOrIZJrJZZsBcGKDNXqe96wMPWvXIip1yLE3EYV55MgVxI8O8suxq//c84Pv3wtEK4Buy6/vPfDUb1/d0XeIYr4GQEFJylUdHZimCYArVEJFBSClGehCRdVSoGlADgrD/OyPB5mwy5SLDsNelYES5C2Fv/b2sv7er+CMXcA7ewrz7h2k9/6aH27bfOIXb739OSnl9Zzevnrbd9asrfH7nx/iD82dfHpDD1evjbOzsYPdu54EJQLLwDItrPdlRnguxF5SqfpQGGbCLnNmYQaAxhg2ZeFitca3jx/ljS1bSd+xndTqdfijA9jffJCng9H7TujKI8CRZaDd+hsbOp/zOCg0Vt/ag5FrIpwYosXMLCa4BA4IB1CTCC2XALoGGcBs4mvbd7Klo43+E69w9p1RANbl4ewUHP7zczzW+zhqgyS9/pPItjbExDh35i59HTiiLM23RovzonoZq6mN29fcgmvb1KkKPS25JDqenXjggu9C6IPnQBwnHkYJVGs3cnaajG7w6JNP8fBXH6KjSSMVQ0+Twpmpebh8Gi68Dn9/CTE7BFu28UDW3AA3yHBmroDe2EbGSFEGTCHJxGYC4dlIRUWoi0NUDRQFarWkjLUESNVpNEzO/LuPbOsq7trRy7oNW7HdKoFucOb5Fwj730Rv76Q8MUntVJV8toGO0GteAZSyPaWADy3XGRWhohsKuC5EIaIWAT4YGjKOErglMEIwDADqDElgl7g2Mca07ZKtz5OxsmTrsgAMRSrrCuXldaLyLFKQXQFkqopZiWp8oPkeOO6ikgBFJnBGDKF/PXKeA7FADyRRtYozPweAO21TNTOIsvXB87/PloECXQuJwHW85Zc1GeM6NgQ+MgwQ2uKObkcJXByBriI0oBaDboCffJTrB8w7VVKRi6EbhG5A4BXRQ5sGK/XhQK6qhNlclmqhSK0WAOBJQaVYBNdBeC4yjkDVELoBUQSAtJO+wkqDmYHAx/McKnaBoHiNjIzRtBSWFTBdKKP7AS11Wfw4RMYxADoqpTh2VgDNKFq4o95ierCfcqGAlcngCY2FwEO6ZUToIQDCMAEDRBgmbYEH8zNQmAe1kWLkU6wFNLsLuItBjaI8I2ODfCqIoL0L751zVFSFVZkMUhgM2LOjAMuyH6x6Q9K6FYAX//EaZRmwIB15vrCAqBQgDMGugF1BLDqBl7SFIZTLcPU/MPouE66PqyQ/eCgWM+CWGJ8oc49uSFGokFm7ka7b7sC2bUR5gf6I4RUROlC881Ljns8/sLfvGM/bEfVXh9nqpcUtWcCNEgWpySLIFNT85DleXFHJQzYPYUBxdhLLd5grj+Dm0gCMT5R5SGrc39opZuwFiulmasP/onXvfpxL5zm679kDwPWzrK2+e/szPz10+pHXn0HUJbtysb6OKaNGgRq5VKKQEjFu7DPt+jSZBvriLSEdCRpQyOgCv1QlcicZnXaYKJUYL3lMKZI9zY20eDaO7dBl5RG936D0k1/x2K77nj528uSP/+e03/Ol3S/ve+JbD3PqKHJoDFFXYlCB01Wfw+8NDC0ExcjUtFxDNte2ublNnJ0arhRsb2opylGkVKKIUku61c3XtMKuBuPu73Z1fnxhfJpGNUaaOaKmdvSmNcylzPDlycnTz/7t5G/OjY78CW5yH7prdc+j3a0N3S1zUzkA18g6b00pF/vLA8eWlJlW1a4NXd1b+0ZHXpMwc6N0l+x7Tbw4LTh/Nuw63eVMtikdH1MBxorR5GxpfPDGsSuAPir2XwwlCH+FaxnpAAAAAElFTkSuQmCC",
    small:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAYAAADlep81AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAZDSURBVEiJzZZbjFVXGcd/a9/O3uecOWfuw9xkoBUsSCFtoSqlUlu1UzHVJlUbTZRGkyYmlgdf1BcjafpgDNHEShHThGhp1dCmkeKDCBWKpWVAS4Fxpsytc2Nu57rve5/lw54ZOljSJ5N+yZe119rr8tvft/9rLSGl5CNlUkr+T1DaPQb7bmz7MBaxBCOEAGBnU/aJL3T3fNbYuMmq1TUE/siIMzA8cPn4+HAfQFqJm9e3rdq0saN985GLF/5y09kjivu76g8rnZ94W1/VYacjv90eGZBeqaQUnHJ1NE71v+rGx0/OV/ffFOjxLZ955XdffPDLsn09oqUBOXcFMX+eK++eY3D0MuUo6dthQkZVuOYn9YwBKd3CtOrIZJrJZZsBcGKDNXqe96wMPWvXIip1yLE3EYV55MgVxI8O8suxq//c84Pv3wtEK4Buy6/vPfDUb1/d0XeIYr4GQEFJylUdHZimCYArVEJFBSClGehCRdVSoGlADgrD/OyPB5mwy5SLDsNelYES5C2Fv/b2sv7er+CMXcA7ewrz7h2k9/6aH27bfOIXb739OSnl9Zzevnrbd9asrfH7nx/iD82dfHpDD1evjbOzsYPdu54EJQLLwDItrPdlRnguxF5SqfpQGGbCLnNmYQaAxhg2ZeFitca3jx/ljS1bSd+xndTqdfijA9jffJCng9H7TujKI8CRZaDd+hsbOp/zOCg0Vt/ag5FrIpwYosXMLCa4BA4IB1CTCC2XALoGGcBs4mvbd7Klo43+E69w9p1RANbl4ewUHP7zczzW+zhqgyS9/pPItjbExDh35i59HTiiLM23RovzonoZq6mN29fcgmvb1KkKPS25JDqenXjggu9C6IPnQBwnHkYJVGs3cnaajG7w6JNP8fBXH6KjSSMVQ0+Twpmpebh8Gi68Dn9/CTE7BFu28UDW3AA3yHBmroDe2EbGSFEGTCHJxGYC4dlIRUWoi0NUDRQFarWkjLUESNVpNEzO/LuPbOsq7trRy7oNW7HdKoFucOb5Fwj730Rv76Q8MUntVJV8toGO0GteAZSyPaWADy3XGRWhohsKuC5EIaIWAT4YGjKOErglMEIwDADqDElgl7g2Mca07ZKtz5OxsmTrsgAMRSrrCuXldaLyLFKQXQFkqopZiWp8oPkeOO6ikgBFJnBGDKF/PXKeA7FADyRRtYozPweAO21TNTOIsvXB87/PloECXQuJwHW85Zc1GeM6NgQ+MgwQ2uKObkcJXByBriI0oBaDboCffJTrB8w7VVKRi6EbhG5A4BXRQ5sGK/XhQK6qhNlclmqhSK0WAOBJQaVYBNdBeC4yjkDVELoBUQSAtJO+wkqDmYHAx/McKnaBoHiNjIzRtBSWFTBdKKP7AS11Wfw4RMYxADoqpTh2VgDNKFq4o95ierCfcqGAlcngCY2FwEO6ZUToIQDCMAEDRBgmbYEH8zNQmAe1kWLkU6wFNLsLuItBjaI8I2ODfCqIoL0L751zVFSFVZkMUhgM2LOjAMuyH6x6Q9K6FYAX//EaZRmwIB15vrCAqBQgDMGugF1BLDqBl7SFIZTLcPU/MPouE66PqyQ/eCgWM+CWGJ8oc49uSFGokFm7ka7b7sC2bUR5gf6I4RUROlC881Ljns8/sLfvGM/bEfVXh9nqpcUtWcCNEgWpySLIFNT85DleXFHJQzYPYUBxdhLLd5grj+Dm0gCMT5R5SGrc39opZuwFiulmasP/onXvfpxL5zm679kDwPWzrK2+e/szPz10+pHXn0HUJbtysb6OKaNGgRq5VKKQEjFu7DPt+jSZBvriLSEdCRpQyOgCv1QlcicZnXaYKJUYL3lMKZI9zY20eDaO7dBl5RG936D0k1/x2K77nj528uSP/+e03/Ol3S/ve+JbD3PqKHJoDFFXYlCB01Wfw+8NDC0ExcjUtFxDNte2ublNnJ0arhRsb2opylGkVKKIUku61c3XtMKuBuPu73Z1fnxhfJpGNUaaOaKmdvSmNcylzPDlycnTz/7t5G/OjY78CW5yH7prdc+j3a0N3S1zUzkA18g6b00pF/vLA8eWlJlW1a4NXd1b+0ZHXpMwc6N0l+x7Tbw4LTh/Nuw63eVMtikdH1MBxorR5GxpfPDGsSuAPir2XwwlCH+FaxnpAAAAAElFTkSuQmCC"
  },
  4: {
    normal:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAYAAADlep81AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAZRSURBVEiJzZZZbFxXGcd/d5/N47HjJbYT2RniLG7TUpykbRJSkhZKCG1pyKJSsVQRalpVqKGIvvCAQNCnqIWCKFKgUECBgkoEFXmIgmmVxE2bFEIW1+M6ztR7JpkZz3Lv3PXwMJOJXBzxBOJ8Orq6V/ec73f+5/u+cyQhBP9XTQjBfwlKVTfx/Ie//ScW6TqMJEkAJLY07Fv9qZ57Vmlrwo1B3Jm0L5tDqdGLQ8c+OAMQRGlpX9G6pvOW9tvf/eN7r99scgkv3/JS+NBt0qp/dupdZTtsdwyZw6JgzcnZXKEUSRvv2UeCY/mB4ks3Bbp37x1/2nPw/gc+wmIaaCNFhqOc5czQCBdHLhMUgurITgUlKiNm/ep7VCVsaMRCEVqjDSxqjAGgl2FxMoo+HiXZnaRb0nmDs+TJckEMcVB6kX/8YGLwyaef2gx484D6VjVu++mL3//LXz95mmt5GQAzX3XY1d6FETIAUCoKsqsAENENVE0mrBgoqLQRIsUUL3z3VxQmLMzCHKUxD1IV5ITOjiObeWTlg5wwz3LCfpONxmYORH7Eum98dOD0gbNbhRA39rR/Zc9X9NXLeO7X++n8zUq67+5l8tIVOu6J8exjX8JDRiVCKGxA+MbWVLCxqYK7FEkxRWHC4srJcjVkmiuwRiU45/CHLx9n/Vtr2RjZyAqjl5Q9wufLn2bqufQW42/yDuA1+frE554w+15d8jLKz5robutlkZ7AcTxirToA1/CYpUCaDBNkmSDLFHNkqVDGxQEcQnTQxCd238XXnnycnq09YKvVviIEp/L8+NAvyTDCVSXP6sgt9Ec2kNS6sD/GHoA6kFgWNA5wkfZQG8tv68a0ysgNEvGeZjxkSpQpUcbEwsLCwaGCRYBPgI+Li4ZGB23MiCn0qMb3dj/L9oc+h9bVCIaHvCzOtZNZjnGCQU5ymMOkpDRruZOG+/Q++FAazmVyJLSVGFEdCiBCEI1BBQcTExUFGQUHUFGRkfHxUWqmoaGhEmrWOH3yDO2xxWxbu4W1K9ZQLlvojsFvB3/BCfdt2rVOMoVpisEALYkEblelZR6Qb1RkN+egotUBZUUCTaGChY2DT7U0KGgE+MgoBKjItRjS0FEA0aBQcFzGZ8cxZ0okYk1Eo2Fiscbq+DEFu7dY9zPtZhABsXlAckgOuUWfhZqNg4tFUPtdRuAjoaDh4NSVq2Ch4yHpLkWvTMa8CkDZmiZaCtGk23xz534eTG6jTWojiAekgzQHxU94Wf25NB/IUV0AyzLrIIEvKJtlXGwcHKBaInS8mjIeoAA64GPjIHCqGWc5lLIWlmFjaBqOa/L1R/ZhTqSQN21COTWGAkTv6ubh3x9gfe8GA2iqAwlLdiMNMfLlLHZQVUqqQLaYw8LCpoKCh4oK6Ph4+ICDQxkIEyFCBBcb07LIFUvMOjn8mIehanxxyw788XH6P759nvodb6XpWLqTd86/JmjhCzeAMorbuCnO2ZkJcoUskXAU1VaoZF2KWJhYRAjj4+HhVeOu9jSxyHCFPFk6iGHNedhzgtyiEpjV6r57w2ep9PcvGBIA3Xv2C84//Fg97a1U5dLdLAfgzVcHcYoS5WuSyP69TJYcHi6FmhVrZmJRoICHS4kC7zNMmjT2hItu1pLDrbpojjXSmRq9KVDbhbQO9NUVuvWHXLi185n7tO8cwT2UYyxxnsh6UyKpI+PSjI5WCzkDGZvqyt1a5sWJA3EcXKbzs1gRlcvXcoTNpptCLNTqZ9nS1sTGV1749vHXHz3BMAUigJZvwJpW8PMykYbqWeYVZBzTpzLrYDTrSNerRNRBSQRIUYWinWfaK2GmM8xNFqlMlLn8zPt4W9ex+J2xhUmSyUlGR6/OO+33Pb398N7nn3joGANcIc0wBZwRBft4QOrQ1Utzec9TdCkeb4q1L749IY2dyhQrc5Xp+uo8v4jnzbW3hC0l7uX0B9Q7l+1t7b2am2ZX06N8ZvIOVi+5f2Gg0dFBksmD/3YfWr6ue1di6aKlMy1TcYCE1WD6b8+eGxouHKkNVbWosqS7b8m60dPpN4Tgyk31/6r8O2a0d5cMho5nuovto3/+4FvGzEwsvnNXQr801lpX5ujRcZLJEeCp+o3xf9SjQoj9QoiLQghXCGEJIc4LIR4XQoSEEPwLn8Y5eaU4sBoAAAAASUVORK5CYII=",
    small:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAYAAADlep81AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAZRSURBVEiJzZZZbFxXGcd/d5/N47HjJbYT2RniLG7TUpykbRJSkhZKCG1pyKJSsVQRalpVqKGIvvCAQNCnqIWCKFKgUECBgkoEFXmIgmmVxE2bFEIW1+M6ztR7JpkZz3Lv3PXwMJOJXBzxBOJ8Orq6V/ec73f+5/u+cyQhBP9XTQjBfwlKVTfx/Ie//ScW6TqMJEkAJLY07Fv9qZ57Vmlrwo1B3Jm0L5tDqdGLQ8c+OAMQRGlpX9G6pvOW9tvf/eN7r99scgkv3/JS+NBt0qp/dupdZTtsdwyZw6JgzcnZXKEUSRvv2UeCY/mB4ks3Bbp37x1/2nPw/gc+wmIaaCNFhqOc5czQCBdHLhMUgurITgUlKiNm/ep7VCVsaMRCEVqjDSxqjAGgl2FxMoo+HiXZnaRb0nmDs+TJckEMcVB6kX/8YGLwyaef2gx484D6VjVu++mL3//LXz95mmt5GQAzX3XY1d6FETIAUCoKsqsAENENVE0mrBgoqLQRIsUUL3z3VxQmLMzCHKUxD1IV5ITOjiObeWTlg5wwz3LCfpONxmYORH7Eum98dOD0gbNbhRA39rR/Zc9X9NXLeO7X++n8zUq67+5l8tIVOu6J8exjX8JDRiVCKGxA+MbWVLCxqYK7FEkxRWHC4srJcjVkmiuwRiU45/CHLx9n/Vtr2RjZyAqjl5Q9wufLn2bqufQW42/yDuA1+frE554w+15d8jLKz5robutlkZ7AcTxirToA1/CYpUCaDBNkmSDLFHNkqVDGxQEcQnTQxCd238XXnnycnq09YKvVviIEp/L8+NAvyTDCVSXP6sgt9Ec2kNS6sD/GHoA6kFgWNA5wkfZQG8tv68a0ysgNEvGeZjxkSpQpUcbEwsLCwaGCRYBPgI+Li4ZGB23MiCn0qMb3dj/L9oc+h9bVCIaHvCzOtZNZjnGCQU5ymMOkpDRruZOG+/Q++FAazmVyJLSVGFEdCiBCEI1BBQcTExUFGQUHUFGRkfHxUWqmoaGhEmrWOH3yDO2xxWxbu4W1K9ZQLlvojsFvB3/BCfdt2rVOMoVpisEALYkEblelZR6Qb1RkN+egotUBZUUCTaGChY2DT7U0KGgE+MgoBKjItRjS0FEA0aBQcFzGZ8cxZ0okYk1Eo2Fiscbq+DEFu7dY9zPtZhABsXlAckgOuUWfhZqNg4tFUPtdRuAjoaDh4NSVq2Ch4yHpLkWvTMa8CkDZmiZaCtGk23xz534eTG6jTWojiAekgzQHxU94Wf25NB/IUV0AyzLrIIEvKJtlXGwcHKBaInS8mjIeoAA64GPjIHCqGWc5lLIWlmFjaBqOa/L1R/ZhTqSQN21COTWGAkTv6ubh3x9gfe8GA2iqAwlLdiMNMfLlLHZQVUqqQLaYw8LCpoKCh4oK6Ph4+ICDQxkIEyFCBBcb07LIFUvMOjn8mIehanxxyw788XH6P759nvodb6XpWLqTd86/JmjhCzeAMorbuCnO2ZkJcoUskXAU1VaoZF2KWJhYRAjj4+HhVeOu9jSxyHCFPFk6iGHNedhzgtyiEpjV6r57w2ep9PcvGBIA3Xv2C84//Fg97a1U5dLdLAfgzVcHcYoS5WuSyP69TJYcHi6FmhVrZmJRoICHS4kC7zNMmjT2hItu1pLDrbpojjXSmRq9KVDbhbQO9NUVuvWHXLi185n7tO8cwT2UYyxxnsh6UyKpI+PSjI5WCzkDGZvqyt1a5sWJA3EcXKbzs1gRlcvXcoTNpptCLNTqZ9nS1sTGV1749vHXHz3BMAUigJZvwJpW8PMykYbqWeYVZBzTpzLrYDTrSNerRNRBSQRIUYWinWfaK2GmM8xNFqlMlLn8zPt4W9ex+J2xhUmSyUlGR6/OO+33Pb398N7nn3joGANcIc0wBZwRBft4QOrQ1Utzec9TdCkeb4q1L749IY2dyhQrc5Xp+uo8v4jnzbW3hC0l7uX0B9Q7l+1t7b2am2ZX06N8ZvIOVi+5f2Gg0dFBksmD/3YfWr6ue1di6aKlMy1TcYCE1WD6b8+eGxouHKkNVbWosqS7b8m60dPpN4Tgyk31/6r8O2a0d5cMho5nuovto3/+4FvGzEwsvnNXQr801lpX5ujRcZLJEeCp+o3xf9SjQoj9QoiLQghXCGEJIc4LIR4XQoSEEPwLn8Y5eaU4sBoAAAAASUVORK5CYII="
  },
  5: {
    normal:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAYAAADlep81AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAZeSURBVEiJzZZZbFxXGcd/d5vtjsczHu92Utu4dkDZSpa2SZpCkeIGCEnbhBYooFIEIiDSPiAKCEQeKCCBoAjxgEsEQlGLICWlIETKIqUpqZJmaeNs3hI7cTz2eGY8y507dz08jD3IafLAA4hP+kvn6Op8+p3/9517jiSE4P8qhBD816B6tvzoP2WRFmEkSQKgf/P2faL73k1bu4MqQKpULo5eHL4wcerEaQDbkpJt3b2r2vpWbDj58p9+f6vEcjxiSxXD6H78hy8s61Dfbo+HDFsKtY3dmA+btj+fz2bNaGViZPTIob/4s28duC3QXZ984g8D+w/saG2BZhlyVwSn37I4d3yI0QsXKZQ8ALRwHD0WwSiUaxB6LEJ9XYB4Q5iWzgYAAmGb+uWdBArTdPT2Elim8vZ5yBoeZ/MKgzth6oWfHN/7xX2b3gG0piP+kede2v/yr0L7aJiaw3YsrGKRADKtbU1ooQgAqmci+w4AkZheBQwF8ZEJJiUyU2UGv/Us+ekUZWseIzWFnbmCFtZ56LlDfODBtVw+N8cbV0ps6a3j+wNRNn70mSMnf/vjASEE6uIOV9/T+QmjdSevfGWQxMXfsWLlBsYuXaX9fdvY9YNPoboQ8SGoBpeUx3LBs6vjvAxpOUB+OkXq9BsAeIkGSPTh5E5y+GtfYO2ao6zvb6SvNcJwqszu3+RJbf3ONv30aw8DL8mLiU/1fm/1L+a6KP79AF3NzdRFdLxSiVhUR3XBzUAhB+k0zM3BfKYqMw+2CZINehmiSZUHHnmYp7+6l3et3wolu6rEBuzMWQ7+7CAjDsybCv0dSTZ01lOfjGAk730MoAak1TdHJ85WWN4Wo3/1OoplA0lvJN7ZDYBhVWU6YDlQccHxwV04oFa1vWiKQcqsHpD9z3yMD+/aTsOyhoXeayc1cpzXL3q8PqnwxwseV3MSazsg2LNuNfDvkrmBoFROXycZVJADWrXrtQARPUrFBtMVaDLggypLOB7IMigSuDIoMkQ1CMsQjsU4d3SKlpZmPjRwDxvXdGFYPnpQ5uCf/8Hl0WmSDY0Uijn+OWqhJzsIJFrrlwABeJU8twrbrTqw6IbqL4XzBCg+WAt+y+E486bHzMwsk6kZIsEIjYm6Wj7ZmMFNxHAcD1WRyeQNKiIYXQoUiIRcK70ERFECAJgL5XF8kPHxZBlXgCqBswgHKLKE7VbHhVKF2UwJx/fQZIO5bJF4VOWpz+1m165VNEUD+KKOybzH4BmHwbQqLekhxbOdm53xPJuyUcL2qz1TcaHsyjgLc8urahHW9qrwi2tnUnmKRZts3qRQLPDkpz/I3a0xpC33oSgSmioTuX8zD8XS/PzxFUEgUXNItU0rGoowlZrFX2CTHJtMwcS0wfY9FAkUScGWFkopwHegCIRUCKtg+1CuWOTSRZKaQKgRAkGZHdvej7h2jbsG7l+y6bahE7RtvAPptSEBTR+vAVWyKTPWdx+j2Ryz2RJ1ER1ZqmBn05RdsGxBMCABXu2/4y2eMFuQ8SUMB8KqipnLU8wXyOsanuagCoU9j2zFWrfu5iLUouszjwqGh56olczOTV5v7q/HMQ2O/+0wvmHglUrMDp8nXwLblyhWoGyJmixbUKxUv1mOy9U5h9ECZKcmiIjqtaI4PsJ1SCSitF4Zvi1Q88j5APCeGtCqk8+e3557E/XR71IONjPihFH7V5JYvgxXAyWpoiRVaNRq8hIaUlxFiqsoTSG01jAAubkyZSnC+I0MqalrGNmp24LcHLW7bHmyafMvf/3UsZ+2fANj0iOmmETMAu50Cr+YJxiNg+NgWQZeyWA+PU28qa2WSInqyHX1yJpOwTDJWoJU6ppw5q5KpfQ0lw99HXfrA7QMvXlrkp6eKcbG5pbc9ju+/OThz377+Z3HbsB0BqzJAtaNccxLJxk+8uK4k88LFE3XwrHWtjtXkrp0pmibhVkAgVsEEJKb1ZsbTbW+Lqev3H53w4N77zSL19mzppFteoZ3r+q8NdDY2HF6ep5/x3uod/2mx5RgfUs51JoA0LVKeeLUidNmeuyvi2vVsN4VbF/xXmP81DEEs7e1v2/Pi7JtnGkvnDiWTdzRcunoK98MzaT02O7d8cD4eFPNmVdfvUZPzwjwpdqL8X8kXQjxtBDighDCEUKYQoghIcTnhRAhIQT/AhHRbW5jdefGAAAAAElFTkSuQmCC",
    small:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAUCAYAAADlep81AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAZeSURBVEiJzZZZbFxXGcd/d5vtjsczHu92Utu4dkDZSpa2SZpCkeIGCEnbhBYooFIEIiDSPiAKCEQeKCCBoAjxgEsEQlGLICWlIETKIqUpqZJmaeNs3hI7cTz2eGY8y507dz08jD3IafLAA4hP+kvn6Op8+p3/9517jiSE4P8qhBD816B6tvzoP2WRFmEkSQKgf/P2faL73k1bu4MqQKpULo5eHL4wcerEaQDbkpJt3b2r2vpWbDj58p9+f6vEcjxiSxXD6H78hy8s61Dfbo+HDFsKtY3dmA+btj+fz2bNaGViZPTIob/4s28duC3QXZ984g8D+w/saG2BZhlyVwSn37I4d3yI0QsXKZQ8ALRwHD0WwSiUaxB6LEJ9XYB4Q5iWzgYAAmGb+uWdBArTdPT2Elim8vZ5yBoeZ/MKgzth6oWfHN/7xX2b3gG0piP+kede2v/yr0L7aJiaw3YsrGKRADKtbU1ooQgAqmci+w4AkZheBQwF8ZEJJiUyU2UGv/Us+ekUZWseIzWFnbmCFtZ56LlDfODBtVw+N8cbV0ps6a3j+wNRNn70mSMnf/vjASEE6uIOV9/T+QmjdSevfGWQxMXfsWLlBsYuXaX9fdvY9YNPoboQ8SGoBpeUx3LBs6vjvAxpOUB+OkXq9BsAeIkGSPTh5E5y+GtfYO2ao6zvb6SvNcJwqszu3+RJbf3ONv30aw8DL8mLiU/1fm/1L+a6KP79AF3NzdRFdLxSiVhUR3XBzUAhB+k0zM3BfKYqMw+2CZINehmiSZUHHnmYp7+6l3et3wolu6rEBuzMWQ7+7CAjDsybCv0dSTZ01lOfjGAk730MoAak1TdHJ85WWN4Wo3/1OoplA0lvJN7ZDYBhVWU6YDlQccHxwV04oFa1vWiKQcqsHpD9z3yMD+/aTsOyhoXeayc1cpzXL3q8PqnwxwseV3MSazsg2LNuNfDvkrmBoFROXycZVJADWrXrtQARPUrFBtMVaDLggypLOB7IMigSuDIoMkQ1CMsQjsU4d3SKlpZmPjRwDxvXdGFYPnpQ5uCf/8Hl0WmSDY0Uijn+OWqhJzsIJFrrlwABeJU8twrbrTqw6IbqL4XzBCg+WAt+y+E486bHzMwsk6kZIsEIjYm6Wj7ZmMFNxHAcD1WRyeQNKiIYXQoUiIRcK70ERFECAJgL5XF8kPHxZBlXgCqBswgHKLKE7VbHhVKF2UwJx/fQZIO5bJF4VOWpz+1m165VNEUD+KKOybzH4BmHwbQqLekhxbOdm53xPJuyUcL2qz1TcaHsyjgLc8urahHW9qrwi2tnUnmKRZts3qRQLPDkpz/I3a0xpC33oSgSmioTuX8zD8XS/PzxFUEgUXNItU0rGoowlZrFX2CTHJtMwcS0wfY9FAkUScGWFkopwHegCIRUCKtg+1CuWOTSRZKaQKgRAkGZHdvej7h2jbsG7l+y6bahE7RtvAPptSEBTR+vAVWyKTPWdx+j2Ryz2RJ1ER1ZqmBn05RdsGxBMCABXu2/4y2eMFuQ8SUMB8KqipnLU8wXyOsanuagCoU9j2zFWrfu5iLUouszjwqGh56olczOTV5v7q/HMQ2O/+0wvmHglUrMDp8nXwLblyhWoGyJmixbUKxUv1mOy9U5h9ECZKcmiIjqtaI4PsJ1SCSitF4Zvi1Q88j5APCeGtCqk8+e3557E/XR71IONjPihFH7V5JYvgxXAyWpoiRVaNRq8hIaUlxFiqsoTSG01jAAubkyZSnC+I0MqalrGNmp24LcHLW7bHmyafMvf/3UsZ+2fANj0iOmmETMAu50Cr+YJxiNg+NgWQZeyWA+PU28qa2WSInqyHX1yJpOwTDJWoJU6ppw5q5KpfQ0lw99HXfrA7QMvXlrkp6eKcbG5pbc9ju+/OThz377+Z3HbsB0BqzJAtaNccxLJxk+8uK4k88LFE3XwrHWtjtXkrp0pmibhVkAgVsEEJKb1ZsbTbW+Lqev3H53w4N77zSL19mzppFteoZ3r+q8NdDY2HF6ep5/x3uod/2mx5RgfUs51JoA0LVKeeLUidNmeuyvi2vVsN4VbF/xXmP81DEEs7e1v2/Pi7JtnGkvnDiWTdzRcunoK98MzaT02O7d8cD4eFPNmVdfvUZPzwjwpdqL8X8kXQjxtBDighDCEUKYQoghIcTnhRAhIQT/AhHRbW5jdefGAAAAAElFTkSuQmCC"
  }
};

export function getCarIconBase64(vehStatus = 0, size = "normal") {
  const data = carIconBase64[vehStatus];
  if (data && data[size]) {
    return data[size];
  }
  return "";
}

// 默认车辆状态
export function getCarStatus(status) {
  const types = ["离线", "空车", "重车", "报警"];
  if (typeof status === "undefined") {
    return types;
  }
  return types[status] || "";
}
