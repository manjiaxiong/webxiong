import store from "../store";
import {
  getConfig
} from "../config";
import {
  getToken
} from "./auth";
import {
  Message
} from "element-ui";
import _ from 'lodash'

let timer;

function getTime() {
  let t = getConfig('timeoutLogout')
  if (!t || isNaN(t) || t === 0) return false
  return t
}

function resetTimeout() {
  let t = getTime()
  if (!t) return;
  if (timer) clearTimeout(timer)
  timer = setTimeout(() => {
    if (!getToken()) return
    Message({
      message: "长时间未操作，请重新登录",
      type: "error",
      duration: 3 * 1000,
    });
    store.dispatch("FedLogOut")
  }, t)
}

export function startTimeoutListener() {
  let t = getTime()
  if (!t) return;
  resetTimeout()
  document.addEventListener('mousemove', _.debounce(() => {
    if (!getToken()) return
    resetTimeout()
  }, 2000, {
    maxWait: 2000
  }))
}
