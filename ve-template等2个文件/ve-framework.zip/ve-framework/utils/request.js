import axios from "axios";
import { Message } from "element-ui";
import store from "../store";
import router from "../router";
import { getToken } from "./auth";
import { json2param } from "./index";
import { getConfig } from "../config";
import { getLang } from "../lang";
import { logout } from "../api/login";

const service = axios.create({
  timeout: 30000, // request timeout
  headers: {
    "Content-Type": "application/json",
    "X-Content-Type": "application/json",
    "x-requested-with": "XMLHttpRequest" // null为同步请求, XMLHttpRequest 为 Ajax 请求
    // XMLHttpRequest: true
  }
});

const formatToken = token => {
  return "Bearer " + token;
};

service.interceptors.request.use(
  config => {
    const { method, params, url } = config;
    // 修复 输入 [ ] 特殊字符后台报错
    if (method.toLowerCase() === "get") {
      if (
        params &&
        Object.keys(params).some(
          k =>
            typeof params[k] === "string" &&
            (params[k].indexOf("[") > -1 || params[k].indexOf("]") > -1)
        )
      ) {
        config.url =
          url + (url.indexOf("?") > -1 ? "&" : "?") + json2param(params);
        delete config.params;
      }
    }
    let publicRouters = ["/refreshToken", "/login", "/serverConfig"];
    const publicApi = getConfig("public.apis");
    if (Array.isArray(publicApi) && publicApi.length) {
      publicRouters = publicRouters.concat(publicApi);
    }
    config.headers["accept-language"] = getLang() === 'zh' ? 'zh-CN,zh' : 'en-US,en';  //  en-US,en  zh-CN,zh
    return publicRouters.some(v => config.url.indexOf(v) > -1)
      ? config
      : new Promise(resolve => {
          const tokenString = getToken();
          if (tokenString) {
            const data = JSON.parse(tokenString);
            const now = new Date().getTime();
            const expired = parseInt(data.expires) - now <= 0;
            // debugger
            if (expired) {
              store.dispatch("refreshToken", data).then(data => {
                config.headers["Authorization"] = formatToken(data.accessToken);
                resolve(config);
              });
            } else {
              config.headers["Authorization"] = formatToken(data.accessToken);
              resolve(config);
            }
          } else {
            resolve(config);
          }
        });
  },
  error => {
    console.log(error); // for debug
    Promise.reject(error);
  }
);

// 是否已经显示登录过期提示
let loginExpiredShowed = false;

service.interceptors.response.use(
  response => {
    const { data, headers } = response;
    if (
      data &&
      data instanceof Blob &&
      headers &&
      headers["content-disposition"]
    ) {
      const arr = headers["content-disposition"].split("=");
      return {
        data,
        fileName:
          arr.length > 1
            ? decodeURIComponent(arr[1])
            : headers["content-disposition"]
      };
    }
    // Message.closeAll(); 强制关闭弹窗提示不太合适
    return data;
  },
  error => {
    // console.log(error.response)
    if (error.response) {
      const {
        data,
        status,
        config: { url }
      } = error.response;
      if (status === 401) {
        const token = getToken();
        if (token) {
          if (!loginExpiredShowed) {
            loginExpiredShowed = true;
            return Message({
              message: "登录状态已过期，请重新登录",
              type: "error",
              duration: 3 * 1000,
              onClose() {
                loginExpiredShowed = false;
                store.dispatch("FedLogOut")
                // 如果是刷新token 或者 退出登录接口 401，则直接前端退出，无需再掉退出登录接口
                if (
                  url.indexOf("/refreshToken") > -1 ||
                  url.indexOf("/logout") > -1
                )
                  return;
                // 只调用退出登录接口，前端不依赖接口返回结果
                logout();
              }
            });
          }
          return;
        } else {
          const location = window.location;
          if (location.href.indexOf("/login") === -1) {
            return location.reload();
          }
        }
      }
      if (status !== 200 && data.message) {
        Message({
          message: data.message || error,
          type: "error",
          duration: 5 * 1000
        });
      }
      return Promise.reject(data);
    }
    return Promise.resolve(error);
  }
);

export default service;
