let scriptLoaderCache = [];

export const loadCss = src => {
  let element = document.createElement("link");
  element.rel = "stylesheet";
  element.href = src;
  document.body.appendChild(element);
};

export const loadScript = src => {
  return new Promise(resolve => {
    if (scriptLoaderCache.includes(src)) {
      resolve();
    } else {
      let element = document.createElement("script");
      element.src = src;
      document.body.appendChild(element);
      element.onload = () => {
        scriptLoaderCache.push(src);
        resolve();
      };
    }
  });
};

export const loadScriptConcurrent = srcList => {
  return new Promise(resolve => {
    if (Array.isArray(srcList)) {
      const len = srcList.length;
      if (len > 0) {
        let count = 0;
        srcList.forEach(src => {
          if (src) {
            loadScript(src).then(() => {
              count++;
              if (count === len) {
                resolve();
              }
            });
          }
        });
      }
    }
  });
};
