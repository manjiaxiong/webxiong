import Cookies from "js-cookie";

const defaultKey = "x-authorized-token";

let TokenKey = defaultKey;

export function setTokenKey(key) {
  if (key) {
    TokenKey = key;
  }
}

export function getToken() {
  if (TokenKey === defaultKey) {
    return sessionStorage.getItem(TokenKey);
  }
  return Cookies.get(TokenKey);
}

export function setToken(token, expires) {
  expires > 0
    ? Cookies.set(TokenKey, token, {
        expires: expires / 86400000
      })
    : Cookies.set(TokenKey, token);

  return sessionStorage.setItem(TokenKey, token);
}

export function removeToken() {
  Cookies.remove(TokenKey);
  return sessionStorage.removeItem(TokenKey);
}

// 单点登录时，cookie 的 token copy 到 sessionStorage
export function getTokenBySSO() {
  let token = Cookies.get(TokenKey);
  if (token) sessionStorage.setItem(TokenKey, token);
  return token;
}

// cachedViews信息
// const cachedViewsKey = "cachedViews";
export function setCachedViews(cachedViews) {
  sessionStorage.setItem("cachedViews", JSON.stringify(cachedViews));
}
export function getCachedViews() {
  let cachedViews = JSON.parse(sessionStorage.getItem("cachedViews") || "[]");
  return cachedViews;
}

// VisitedViews信息
// const visitedViewsKey = "visitedViews";
export function getVisitedViews() {
  let visitedViews = JSON.parse(sessionStorage.getItem("visitedViews") || "[]");
  return visitedViews;
}

export function setVisitedViews(visitedViews) {
  let views = visitedViews.map(view => {
    return {
      name: view.name,
      path: view.path,
      title: view.title || view.name || "no-name",
      query: view.query
    };
  });

  sessionStorage.setItem("visitedViews", JSON.stringify(views));
}
