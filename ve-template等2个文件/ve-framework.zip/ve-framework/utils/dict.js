import { getAllDict } from "../api/dict";
import { getConfig } from "../config";

/**
 * 全局字典
 * 挂在到  Vue.prototype.$dict
 */
export default class DICT {
  static getInstance() {
    if (!DICT.instance) {
      DICT.instance = new DICT();
    }
    return DICT.instance;
  }
  constructor() {
    this.rawData = null;  // 原始数据
    this.data = null  // 格式化数据
  }
  // 初始化，重置
  init() {
    const dictEnable = getConfig("dictEnable");
    if (dictEnable === false) {
      return;
    }
    return getAllDict().then(data => {
      /**
       * 关于字典的变化
       * 微服务字典模块由于人员工作失误，中间有几个版本接口返回的是数组，正常应该是map
       * 数组版本字典会兼容性的存在几个版本，后期将移除
       */
      if (
        Array.isArray(data) ||
        Object.prototype.toString.call(data) === "[object Array]"
      ) {
        this.rawData = data
        let dict = {}
        data.map(it => {
          let { dictType, fieldName, fieldType } = it
          if (!dict[dictType]) {
            dict[dictType] = []
          }
          dict[dictType].push({ label: fieldName, value: fieldType })
        })
        this.data = dict
      } else {
        // 字典返回格式Map版本
        this.rawData = data
        let dict = {}
        Object.keys(data).map(k => {
          data[k].map(it => {
            let { fieldName, fieldType } = it
            if (!dict[k]) {
              dict[k] = []
            }
            dict[k].push({ label: fieldName, value: fieldType })
          })
        })
        this.data = dict
      }
    })
  }
  // 根据key获取格式化字典
  get(key, options = { labelKey: 'label', valueKey: 'value' }) {
    let arr = this.data[key] || []
    let { labelKey, valueKey } = options
    return arr.map(it => {
      let { label, value } = it
      let item = {}
      item[labelKey] = label
      item[valueKey] = value
      return item
    })
  }
  // 常用快捷操作：按照 {id,name} 格式输出, 常用于 AutoTable > dialog.options
  getFormatByIdName(key) {
    return this.get(key, { labelKey: 'name', valueKey: 'id' })
  }
  
  // 通过value获取选项名称
  getTextById(key,value){
    var dicOptions = this.get(key);
    var option = dicOptions.find(opt=>opt.value==value);
    return option?option.label:''
  }
}
