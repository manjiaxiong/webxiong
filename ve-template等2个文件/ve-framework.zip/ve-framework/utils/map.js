const getZoom = (maxLng, minLng, maxLat, minLat, map, BMap) => {
  const zoom = [
    "50",
    "100",
    "200",
    "500",
    "1000",
    "2000",
    "5000",
    "10000",
    "20000",
    "25000",
    "50000",
    "100000",
    "200000",
    "500000",
    "1000000",
    "2000000"
  ]; //级别18到3。
  const pointA = new BMap.Point(maxLng, maxLat); // 创建点坐标A
  const pointB = new BMap.Point(minLng, minLat); // 创建点坐标B
  const distance = map.getDistance(pointA, pointB).toFixed(1); //获取两点距离,保留小数点后两位
  for (let i = 0, zoomLen = zoom.length; i < zoomLen; i++) {
    if (zoom[i] - distance > 0) {
      return 18 - i + 3; //之所以会多3，是因为地图范围常常是比例尺距离的10倍以上。所以级别会增加3。
    }
  }
};

const setZoom = (points, map, BMap) => {
  if (points.length > 0) {
    let maxLng = points[0].lng;
    let minLng = points[0].lng;
    let maxLat = points[0].lat;
    let minLat = points[0].lat;
    let res;
    for (let i = points.length - 1; i >= 0; i--) {
      res = points[i];
      if (res.lng > maxLng) maxLng = res.lng;
      if (res.lng < minLng) minLng = res.lng;
      if (res.lat > maxLat) maxLat = res.lat;
      if (res.lat < minLat) minLat = res.lat;
    }
    const cenLng = (parseFloat(maxLng) + parseFloat(minLng)) / 2;
    const cenLat = (parseFloat(maxLat) + parseFloat(minLat)) / 2;
    const zoom = getZoom(maxLng, minLng, maxLat, minLat, map, BMap);
    map.centerAndZoom(new BMap.Point(cenLng, cenLat), zoom);
  } else {
    //没有坐标，显示全中国
    map.centerAndZoom(new BMap.Point(103.388611, 35.563611), 5);
  }
};

//计算两点之间的距离
const calculationDistance = (point1, point2) => {
  let lat1 = point1.latitude;
  let lat2 = point2.latitude;
  let lng1 = point1.longitude;
  let lng2 = point2.longitude;
  let radLat1 = (lat1 * Math.PI) / 180.0;
  let radLat2 = (lat2 * Math.PI) / 180.0;
  let a = radLat1 - radLat2;
  let b = (lng1 * Math.PI) / 180.0 - (lng2 * Math.PI) / 180.0;
  let s =
    2 *
    Math.asin(
      Math.sqrt(
        Math.pow(Math.sin(a / 2), 2) +
          Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)
      )
    );
  return s * 6370996.81;
};
//计算点pX到点pA和pB所确定的直线的距离
const distToSegment = (start, end, center) => {
  let a = Math.abs(calculationDistance(start, end));
  let b = Math.abs(calculationDistance(start, center));
  let c = Math.abs(calculationDistance(end, center));
  let p = (a + b + c) / 2.0;
  let s = Math.sqrt(Math.abs(p * (p - a) * (p - b) * (p - c)));
  return (s * 2.0) / a;
};
//递归方式压缩轨迹
const compressLine = (coordinate, result, start, end, dMax) => {
  if (start < end) {
    let maxDist = 0;
    let currentIndex = 0;
    let startPoint = coordinate[start];
    let endPoint = coordinate[end];
    for (let i = start + 1; i < end; i++) {
      let currentDist = distToSegment(startPoint, endPoint, coordinate[i]);
      if (currentDist > maxDist) {
        maxDist = currentDist;
        currentIndex = i;
      }
    }
    if (maxDist >= dMax) {
      //将当前点加入到过滤数组中
      result.push(coordinate[currentIndex]);
      //将原来的线段以当前点为中心拆成两段，分别进行递归处理
      compressLine(coordinate, result, start, currentIndex, dMax);
      compressLine(coordinate, result, currentIndex, end, dMax);
    }
  }
  return result;
};

/**
 *
 *@param coordinate 原始轨迹Array<{latitude,longitude}>
 *@param dMax 允许最大距离误差
 *@return douglasResult 抽稀后的轨迹
 *
 */
const douglasPeucker = (coordinate, dMax = 10) => {
  if (!coordinate || !(coordinate.length > 2)) {
    return null;
  }
  coordinate.forEach((item, index) => {
    item.id = index;
  });
  let result = compressLine(coordinate, [], 0, coordinate.length - 1, dMax);
  result.push(coordinate[0]);
  result.push(coordinate[coordinate.length - 1]);
  let resultLatLng = result.sort((a, b) => {
    if (a.id < b.id) {
      return -1;
    } else if (a.id > b.id) return 1;
    return 0;
  });
  resultLatLng.forEach(item => {
    item.id = undefined;
  });
  return resultLatLng;
};

const formatLatLng = v => {
  const pt = v.split(",");
  return {
    lat: parseFloat(pt[1]),
    lng: parseFloat(pt[0])
  };
};

const formatPoints = (list, type) => {
  let points = {};
  if (type === 1) {
    list.forEach(v => {
      points[v.borderName] =
        v.borderName === "point" ? formatLatLng(v.borderValue) : v.borderValue;
    });
  } else {
    points = list.map(v => formatLatLng(v.borderValue));
  }
  return points;
};

const pointArray2String = data => {
  if (data && data.length) {
    data = Object.clone(data);
  }
  const latList = [];
  const lngList = [];
  data.forEach(v => {
    const fix = fixPosition(v, { reverse: true });
    latList.push(fix.lat);
    lngList.push(fix.lng);
  });
  return {
    latInputO: latList.join(","),
    lngInputO: lngList.join(",")
  };
};

/**
 * Created by Wandergis on 2015/7/8.
 * 提供了百度坐标（BD09）、国测局坐标（火星坐标，GCJ02）、和WGS84坐标系之间的转换
 */

//定义一些常量
var x_PI = (3.14159265358979324 * 3000.0) / 180.0;
var PI = 3.1415926535897932384626;
var a = 6378245.0;
var ee = 0.00669342162296594323;

/**
 * 百度坐标系 (BD-09) 与 火星坐标系 (GCJ-02)的转换
 * 即 百度 转 谷歌、高德
 * @param bd_lon
 * @param bd_lat
 * @returns {*[]}
 */
function bd09togcj02(bd_lon, bd_lat) {
  var x_pi = (3.14159265358979324 * 3000.0) / 180.0;
  var x = bd_lon - 0.0065;
  var y = bd_lat - 0.006;
  var z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi);
  var theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi);
  var gg_lng = z * Math.cos(theta);
  var gg_lat = z * Math.sin(theta);
  return { lng: gg_lng, lat: gg_lat };
}

/**
 * 火星坐标系 (GCJ-02) 与百度坐标系 (BD-09) 的转换
 * 即谷歌、高德 转 百度
 * @param lng
 * @param lat
 * @returns {*[]}
 */
function gcj02tobd09(lng, lat) {
  var z = Math.sqrt(lng * lng + lat * lat) + 0.00002 * Math.sin(lat * x_PI);
  var theta = Math.atan2(lat, lng) + 0.000003 * Math.cos(lng * x_PI);
  var bd_lng = z * Math.cos(theta) + 0.0065;
  var bd_lat = z * Math.sin(theta) + 0.006;
  return { lng: bd_lng, lat: bd_lat };
}

/**
 * WGS84转GCj02
 * @param lng
 * @param lat
 * @returns {*[]}
 */
function wgs84togcj02(lng, lat) {
  if (out_of_china(lng, lat)) {
    return { lng: lng, lat: lat };
  } else {
    var dlat = transformlat(lng - 105.0, lat - 35.0);
    var dlng = transformlng(lng - 105.0, lat - 35.0);
    var radlat = (lat / 180.0) * PI;
    var magic = Math.sin(radlat);
    magic = 1 - ee * magic * magic;
    var sqrtmagic = Math.sqrt(magic);
    dlat = (dlat * 180.0) / (((a * (1 - ee)) / (magic * sqrtmagic)) * PI);
    dlng = (dlng * 180.0) / ((a / sqrtmagic) * Math.cos(radlat) * PI);
    var mglat = lat + dlat;
    var mglng = lng + dlng;
    return { lng: mglng, lat: mglat };
  }
}

/**
 * GCJ02 转换为 WGS84
 * @param lng
 * @param lat
 * @returns {*[]}
 */
function gcj02towgs84(lng, lat) {
  if (out_of_china(lng, lat)) {
    return { lng: lng, lat: lat };
  } else {
    var dlat = transformlat(lng - 105.0, lat - 35.0);
    var dlng = transformlng(lng - 105.0, lat - 35.0);
    var radlat = (lat / 180.0) * PI;
    var magic = Math.sin(radlat);
    magic = 1 - ee * magic * magic;
    var sqrtmagic = Math.sqrt(magic);
    dlat = (dlat * 180.0) / (((a * (1 - ee)) / (magic * sqrtmagic)) * PI);
    dlng = (dlng * 180.0) / ((a / sqrtmagic) * Math.cos(radlat) * PI);
    var mglat = lat + dlat;
    var mglng = lng + dlng;
    return { lng: lng * 2 - mglng, lat: lat * 2 - mglat };
  }
}

function transformlat(lng, lat) {
  var ret =
    -100.0 +
    2.0 * lng +
    3.0 * lat +
    0.2 * lat * lat +
    0.1 * lng * lat +
    0.2 * Math.sqrt(Math.abs(lng));
  ret +=
    ((20.0 * Math.sin(6.0 * lng * PI) + 20.0 * Math.sin(2.0 * lng * PI)) *
      2.0) /
    3.0;
  ret +=
    ((20.0 * Math.sin(lat * PI) + 40.0 * Math.sin((lat / 3.0) * PI)) * 2.0) /
    3.0;
  ret +=
    ((160.0 * Math.sin((lat / 12.0) * PI) + 320 * Math.sin((lat * PI) / 30.0)) *
      2.0) /
    3.0;
  return ret;
}

function transformlng(lng, lat) {
  var ret =
    300.0 +
    lng +
    2.0 * lat +
    0.1 * lng * lng +
    0.1 * lng * lat +
    0.1 * Math.sqrt(Math.abs(lng));
  ret +=
    ((20.0 * Math.sin(6.0 * lng * PI) + 20.0 * Math.sin(2.0 * lng * PI)) *
      2.0) /
    3.0;
  ret +=
    ((20.0 * Math.sin(lng * PI) + 40.0 * Math.sin((lng / 3.0) * PI)) * 2.0) /
    3.0;
  ret +=
    ((150.0 * Math.sin((lng / 12.0) * PI) +
      300.0 * Math.sin((lng / 30.0) * PI)) *
      2.0) /
    3.0;
  return ret;
}

/**
 * 判断是否在国内，不在国内则不做偏移
 * @param lng
 * @param lat
 * @returns {boolean}
 */
function out_of_china(lng, lat) {
  return (
    lng < 72.004 || lng > 137.8347 || (lat < 0.8293 || lat > 55.8271 || false)
  );
}

/** 获取两点间的距离*/
// function getDistance(lat1, lng1, lat2, lng2) {
//   var a = rad(lat1) - rad(lat2);
//   var b = rad(lng1) - rad(lng2);
//   var s =
//     2 *
//     Math.asin(
//       Math.sqrt(
//         Math.pow(Math.sin(a / 2), 2) +
//           Math.cos(rad(lat1)) *
//             Math.cos(rad(lat2)) *
//             Math.pow(Math.sin(b / 2), 2)
//       )
//     );
//   s = s * 6378137.0;
//   s = Math.round(s * 10000) / 10000;
//   return s;
// }

// function rad(number) {
//   return number * (Math.PI / 180);
// }

function wgs84tobd09(lng2, lat2) {
  const { lng, lat } = wgs84togcj02(parseFloat(lng2), parseFloat(lat2));
  return gcj02tobd09(lng, lat);
}

function bd09towgs84(lng2, lat2) {
  const { lng, lat } = bd09togcj02(parseFloat(lng2), parseFloat(lat2));
  return gcj02towgs84(lng, lat);
}

// map baidu, gaode
const funcMap = {
  baidu: [wgs84tobd09, bd09towgs84],
  gaode: [wgs84togcj02, gcj02towgs84]
};
function fixPosition(point, config = {}) {
  // console.log("old point", point);
  let fields = [
    {
      lat: "lat",
      lng: "lng"
    }
  ];
  let defaults = {
    map: "baidu",
    reverse: false
  };
  const { reverse, map, fields: fields2 } = Object.assign(defaults, config);
  if (fields2) {
    fields = fields.concat(fields2);
  }
  // console.log(fields);
  // console.log(options);
  const func = funcMap[map][reverse ? 1 : 0];
  if (func) {
    // console.log(fields);
    fields.forEach(v => {
      const lng = point[v.lng];
      const lat = point[v.lat];
      if (lng && lat) {
        const fix = func(parseFloat(lng), parseFloat(lat));
        point[v.lat] = fix.lat;
        point[v.lng] = fix.lng;
      }
    });
  }
  // console.log("new point", point);
  return point;
}

function getBounds(points) {
  // bounds [xMin, yMin][xMax, yMax]
  var bounds = [[], []];
  var latitude;
  var longitude;
  for (var j = 0; j < points.length; j++) {
    longitude = points[j][0];
    latitude = points[j][1];
    bounds[0][0] = bounds[0][0] < longitude ? bounds[0][0] : longitude;
    bounds[1][0] = bounds[1][0] > longitude ? bounds[1][0] : longitude;
    bounds[0][1] = bounds[0][1] < latitude ? bounds[0][1] : latitude;
    bounds[1][1] = bounds[1][1] > latitude ? bounds[1][1] : latitude;
  }
  return bounds;
}

export {
  getZoom,
  setZoom,
  douglasPeucker,
  formatPoints,
  wgs84togcj02,
  wgs84tobd09,
  fixPosition,
  pointArray2String,
  getBounds
};
