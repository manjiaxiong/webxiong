import Vue from "vue";
import Router from "vue-router";
import store from "../store";
import { getToken } from "../utils/auth"; // getToken from cookie
// 加载项目配置，不支持热更新
import serverConfig from "@/../public/serverConfig.json";

const originalPush = Router.prototype.push;
Router.prototype.push = function push(location) {
  const result = originalPush.call(this, location);
  return result.catch ? result.catch(err => err) : result;
};

Vue.use(Router);

// 静态路由
export const constantRoutes = [
  {
    path: "/login",
    component: () => import("@/views/login/index")
  },
  {
    path: "/404",
    component: () => import("../views/errorPage/404")
  },
  // 新增SSO登录失败时展示页面，而不是跳转此系统的登录页
  {
    path: "/errors/401",
    component: () => import("../views/errorPage/401")
  },
  {
    path: "/errors/403",
    component: () => import("../views/errorPage/403")
  },
];

const createRouter = router => {
  return new Router({
    mode:
      serverConfig.router && serverConfig.router.mode
        ? serverConfig.router.mode
        : "hash", // require service support
    base: process.env.BASE_URL,
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes.concat(router ? router.getRoutes() : [])
  });
};

const router = createRouter();

export default router;

let routers = [];
router.registerRoutes = routes => {
  if (routes && routes.length) {
    routers = routes;
    router.addRoutes(routes);
  }
};
router.getRoutes = () => routers;

// 重置全部路由
export function resetRouter() {
  const newRouter = createRouter(router);
  // 新路由实例matcer，赋值给旧路由实例的matcher，（相当于replaceRouter）
  router.matcher = newRouter.matcher;
}

// 动态添加路由
export const initRouterMap = systemId => {
  const token = getToken();
  if (token) {
    return store.dispatch("GenerateRoutes", systemId).then(data => {
      // 动态添加可访问路由表
      router.addRoutes(store.getters.addRouters);
      return data;
    });
  }
  return null;
};
