const production = process.env.NODE_ENV === "production";
const maphost = production
  ? "http://218.28.140.213:10521"
  : // ? "http://cloud.tiamaes.com:11226"
    "http://192.168.240.164:8090"; // 超图服务器
export const getSuperMapUrl = name =>
  [
    maphost,
    "/iserver/services",
    name,
    "/zxyTileImage.png?z={z}&x={x}&y={y}"
  ].join("");
export default {
  data() {
    return {
      restdataurl: maphost + "/iserver/services/data-TXTILAYER/rest/data",
      restmapurl: maphost + "/iserver/services/map-ZhengZhou/rest/maps",
      bufferAnalysisUrl:
        maphost +
        "/iserver/services/ugcSpatialProvider_MPG_BUS_PLATE/restjsr/spatialanalyst"
    };
  },
  methods: {
    // 经纬度转web墨卡托
    lonLat2WebMercator(lng, lat) {
      const x = (lng * 20037508.34) / 180;
      const ly =
        Math.log(Math.tan(((90 + lat) * Math.PI) / 360)) / (Math.PI / 180);
      const y = (ly * 20037508.34) / 180;
      return [x, y];
    },
    // web墨卡托转经纬度
    WebMercator2lonLat(x, y) {
      const lng = (x / 20037508.34) * 180;
      const lata = (y / 20037508.34) * 180;
      const lat =
        (180 / Math.PI) *
        (2 * Math.atan(Math.exp((lata * Math.PI) / 180)) - Math.PI / 2);
      return [lng, lat];
    },
    // 私有方法，超图数据格式转化
    _format(data) {
      const format = v => {
        if (v.geometry && v.geometry.coordinates) {
          const { coordinates, type } = v.geometry;
          if (type === "Point") {
            v.geometry.coordinates = this.WebMercator2lonLat(
              coordinates[0],
              coordinates[1]
            );
          } else {
            v.geometry.coordinates.forEach((v2, i) => {
              if (v2 && v2.length) {
                if (type === "MultiPolygon") {
                  v2.forEach(v3 => {
                    if (v3 && v3.length) {
                      v3.forEach((v4, k) => {
                        if (v4 && v4.length === 2) {
                          v3[k] = this.WebMercator2lonLat(v4[0], v4[1]);
                        }
                      });
                    }
                  });
                } else if (type === "MultiLineString") {
                  v2.forEach((v3, n) => {
                    if (v3 && v3.length) {
                      v2[n] = this.WebMercator2lonLat(v3[0], v3[1]);
                    }
                  });
                } else if (type === "LineString") {
                  v.geometry.coordinates[i] = this.WebMercator2lonLat(
                    v2[0],
                    v2[1]
                  );
                }
              }
            });
          }
        }
      };
      if (data) {
        if (data.type === "FeatureCollection") {
          if (data.features) {
            data.features.forEach(v => {
              format(v);
            });
          }
        } else if (data.type === "Feature") {
          format(data);
        }
      }
      return data;
    },
    // 私有方法，获取链接
    _getUrl({ serviceUrl, topic }) {
      if (serviceUrl) {
        return serviceUrl;
      }
      if (typeof topic === "string") {
        return this.restdataurl.replace("TXTILAYER", topic);
      }
      return this.restdataurl;
    },
    // 私有方法
    _getFeatureParams(opts, condition) {
      if (typeof opts.toIndex !== "undefined") {
        condition.toIndex = opts.toIndex;
      }
      if (typeof opts.fromIndex !== "undefined") {
        condition.fromIndex = opts.fromIndex;
      }
      return condition;
    },
    /**sql查询公用方法
     *@param opts 查询需要用到的参数
     * {
     *   layerName:'',//图层名称，必填
     *   fields:[],//要查询的字段，默认为全部字段
     *   serviceUrl:'',//超图服务地址，必填
     *   joinItems:[],//关联查询时需要的查询条件，可不传
     *   attributeFilter:''//sql查询时的查询条件，可不传
     *
     * }
     */
    queryBySQL(opts, type = "features") {
      const queryParam = new SuperMap.FilterParameter({
        name: opts.layerName,
        fields: opts.fields || null,
        joinItems: opts.joinItems || null,
        attributeFilter: opts.attributeFilter || ""
      });
      const features = type === "features";
      const condition = {
        queryParameter: queryParam,
        datasetNames: opts.datasetNames || []
      };
      const queryBySQLParams = new SuperMap[
        features ? "GetFeaturesBySQLParameters" : "QueryBySQLParameters"
      ](
        features
          ? this._getFeatureParams(opts, condition)
          : {
              queryParams: [queryParam]
            }
      );
      // 设置数据最大返回条数
      if (opts.maxFeatures) {
        queryBySQLParams.maxFeatures = opts.maxFeatures;
      }
      return new Promise(resolve => {
        new mapboxgl.supermap.FeatureService(
          this._getUrl(opts)
        ).getFeaturesBySQL(queryBySQLParams, serviceResult => {
          // 释放引用资源
          queryBySQLParams.destroy();
          const result = serviceResult.result;
          if (result && result.features) {
            resolve(
              opts.format !== false
                ? this._format(result.features)
                : result.features
            );
          }
        });
      });
    },
    // 路径缓冲分析
    bufferAnalysis(options = {}, sourceGeometrySRID = 4326) {
      // 结果是否增加返回[lng, lat]格式
      const returnLngLat = sourceGeometrySRID === 4326;
      const defaultParams = {
        url: this.bufferAnalysisUrl,
        path: [],
        distance: 400,
        endType: SuperMap.BufferEndType.ROUND
      };
      const params = Object.assign(defaultParams, options);
      const { path, url, distance, endType } = params;
      if (path && path.length > 0) {
        const geometryLine = {
          type: "Feature",
          geometry: {
            type: "LineString",
            coordinates: path.map(v => this.lonLat2WebMercator(v[0], v[1]))
          }
        };
        const bufferDistance = new SuperMap.BufferDistance({
          value: distance
        });
        const geoBufferAnalystParams = new SuperMap.GeometryBufferAnalystParameters(
          {
            sourceGeometry: geometryLine,
            // 4326 (wgs84) || 3857 (默认墨卡托投影)
            // sourceGeometrySRID: 3857,
            bufferSetting: new SuperMap.BufferSetting({
              endType, // ROUND || FLAT
              leftDistance: bufferDistance,
              rightDistance: bufferDistance,
              semicircleLineSegment: 10
            })
          }
        );
        return new Promise(resolve => {
          new mapboxgl.supermap.SpatialAnalystService(url).bufferAnalysis(
            geoBufferAnalystParams,
            serviceResult => {
              const result = serviceResult.result.resultGeometry;
              const returnData = { result };
              if (returnLngLat) {
                returnData.lngLatResult = this._format(Object.clone(result));
              }
              resolve(returnData);
            }
          );
        });
      }
    },
    // 获取区域内元素信息
    QueryByGeometryService(options = {}) {
      if (options.geometry) {
        const params = new SuperMap.QueryByGeometryParameters({
          queryParams: {
            name:
              options.name ||
              ["TM_SM_STATION_GIS_INFO", "SUPERMAPXWGH"].join("@")
          },
          geometry: options.geometry,
          spatialQueryMode:
            options.spatialQueryMode || SuperMap.SpatialQueryMode.INTERSECT
        });
        const url = options.url || this.restmapurl + "/MPG_BUS_LINE_STATION";
        return new Promise(resolve => {
          new mapboxgl.supermap.QueryService(url).queryByGeometry(
            params,
            serviceResult => {
              const recordsets =
                serviceResult &&
                serviceResult.result &&
                serviceResult.result.recordsets;
              const features =
                recordsets && recordsets[0] && recordsets[0].features;
              resolve(this._format(features));
            }
          );
        });
      }
    }
  }
};
