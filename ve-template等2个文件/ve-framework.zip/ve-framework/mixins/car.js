import { mapGetters, mapActions, mapMutations } from "vuex";
import { getCarIcon, getCarStatus } from "../utils";
export default {
  computed: {
    ...mapGetters(["carList", "trackList", "vision"])
  },
  methods: {
    ...mapActions(["setTrackList", "updateTrackList", "setVision"]),
    ...mapMutations({
      setCarList: "SET_CAR_LIST",
      updateCarList: "UPDATE_CAR_LIST",
      removeCarList: "REMOVE_CAR_LIST"
    }),
    updateCar(key, value) {
      this.updateCarList({
        key,
        value
      });
    },
    updateCarKey(key, subKey, value) {
      if (this.getCar(key)) {
        this.updateCarList({
          key,
          subKey,
          value
        });
      }
    },
    getCar(key) {
      return this.carList[key];
    },
    formatPoints() {
      return Object.keys(this.carList).map(v => {
        return {
          lat: this.carList[v].lat,
          lng: this.carList[v].lng
        };
      });
    },
    getCarIcon(data) {
      return getCarIcon(data);
    },
    getCarStatus(data) {
      return getCarStatus(data);
    }
  }
};
