export default {
  beforeRouteEnter(_, __, next) {
    next(vm => {
      vm.$nextTick(() => {
        if (vm.$el) {
          // 通过 `vm` 访问组件实例
          let iframe = vm.$el.querySelector("iframe");
          // 如果页面存在 iframe 标签，同时又没有添加 nocache 属性，那么默认有缓存行为
          if (iframe && typeof iframe.getAttribute("nocache") !== "string") {
            vm.$store.commit("pushCachePath", vm.$route.path === '/' ? '/home' : vm.$route.path);
          }
        }
      });
    });
  }
};
