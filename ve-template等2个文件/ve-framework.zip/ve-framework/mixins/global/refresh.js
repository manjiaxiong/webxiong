export default {
  methods: {
    _onRenderData() {
      if (typeof this.onRefreshData === "function") {
        this.onRefreshData();
      }
    }
  },
  created() {
    this._hasCreated = true;
    this._onRenderData();
  },
  deactivated() {
    this._hasCreated = false;
  },
  activated() {
    if (!this._hasCreated) {
      this._onRenderData();
    }
  }
};
