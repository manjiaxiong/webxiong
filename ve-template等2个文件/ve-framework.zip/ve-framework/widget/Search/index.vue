<template>
  <div class="search-container">
    <div class="settings" v-popover:settings-popover v-if="mode.includes('settings')">
      <i class="iconfont">&#xe62a;</i>
    </div>
    <el-select
      v-if="remote"
      v-model="text"
      clearable
      filterable
      remote
      :remote-method="remoteMethod"
      :loading="selectLoading"
      :placeholder="placeholder2"
      @clear="handleClear"
      @change="handleBusChange"
      @focus="focus"
    >
      <el-option
        v-for="(item, index) in busOptions"
        :key="index"
        :label="item.name"
        :value="item.id"
      >
        <template v-if="item.tips">
          <span>{{ item.name }}</span>
          <span style="float: right; color: #aaa; font-size: 12px">
            {{
            item.tips
            }}
          </span>
        </template>
      </el-option>
    </el-select>
    <el-input
      v-else
      size="small"
      :placeholder="placeholder2"
      @input="change"
      v-model="text"
      :clearable="true"
    />
    <el-button
      v-if="mode.includes('refresh')"
      :class="['refresh', loading ? 'loading' : '']"
      :disabled="loading"
      @click="refresh"
      icon="el-icon-refresh"
    />
    <div class="menu" v-if="mode.includes('menu')" v-popover:menu-popover>
      <i class="iconfont">&#xe605;</i>
    </div>

    <el-popover
      v-if="mode.includes('settings')"
      popper-class="v-popover"
      ref="settings-popover"
      placement="bottom-start"
      width="300"
    >
      <div v-for="(item, key) in filters" :key="key">
        <div class="title">
          <el-radio v-model="radio" :label="key">{{ item.label }}</el-radio>
        </div>

        <el-row :gutter="0">
          <el-col
            :span="24 / maxColumn"
            v-for="(item2, key2) in getModLength(item.children.length)"
            :key="key2"
          >
            <template v-if="item.children[key2]">
              <el-radio
                v-if="item.radio"
                v-model="item.radio"
                :disabled="item.children[key2].disabled || radio !== key"
                :label="item.children[key2].key"
              >{{ item.children[key2].label }}</el-radio>
              <el-checkbox
                v-else
                v-model="item.children[key2].checked"
                :disabled="item.children[key2].disabled || radio !== key"
                @change="filterChange"
              >{{ item.children[key2].label }}</el-checkbox>
            </template>
          </el-col>
        </el-row>
      </div>
    </el-popover>

    <el-popover
      v-if="mode.includes('menu')"
      popper-class="v-popover"
      ref="menu-popover"
      placement="right-start"
      width="300"
    >
      <div class="title">统计显示</div>
      <el-row :gutter="0">
        <el-col
          :span="24 / maxColumn"
          v-for="(item, key) in getModLength(labels.length)"
          :key="key"
        >
          <el-checkbox
            v-if="labels[key]"
            v-model="labels[key].checked"
            @change="checkChange"
          >{{ labels[key].label }}</el-checkbox>
        </el-col>
      </el-row>
    </el-popover>
  </div>
</template>

<script>
export default {
  name: "Search",
  props: {
    remote: {
      type: Boolean,
      default: false
    },
    mode: {
      type: Array,
      default: () => ["settings", "refresh", "menu"]
    },
    placeholder: {
      type: String,
      default: ""
    },
    tree: null,
    params: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      nodeData: null,
      busOptions: [],
      selectLoading: false,
      radio: 0,
      text: "",
      maxColumn: 3,
      loading: false
    };
  },
  computed: {
    filters() {
      return this.params.filters || [];
    },
    labels() {
      return this.params.labels || [];
    },
    filter() {
      const filters = this.filters[this.radio];
      if (filters) {
        const filter = filters.children.filter(
          v => v && (filters.radio ? v.key === filters.radio : v.checked)
        );
        if (this.tree && this.tree.setFilter) {
          this.tree.setFilter({
            group: filters.key,
            fields: filter.map(v => v.key)
          });
        }
        return filter;
      }
      return [];
    },
    condition() {
      return this.filter.length ? this.filter[0].key : "vehicleNo";
    },
    placeholder2() {
      if (this.placeholder) {
        return this.placeholder;
      }
      return "搜索" + this.filter.map(v => v.label).join(". ");
    }
  },
  watch: {
    condition() {
      this.handleClear();
    }
  },
  methods: {
    resize() {
      const ref = this.$refs["menu-popover"];
      if (ref && ref.updatePopper) {
        ref.updatePopper();
      }
    },
    getModLength(len) {
      if (len > 0) {
        const mod = len % this.maxColumn;
        if (mod > 0) {
          return len + this.maxColumn - mod;
        }
        return len;
      }
      return 0;
    },
    focus() {
      const ref = this.$refs["settings-popover"];
      if (ref && ref.doClose) {
        ref.doClose();
      }
    },
    change() {
      if (this.$listeners && this.$listeners.change) {
        return this.$emit("change", this.text, this.condition);
      }
      this.tree && this.tree.filter(this.text, this.condition);
    },
    checkChange() {
      this.$emit("labelChange");
    },
    filterChange() {},
    getCompanyList(query = "") {
      if (this.tree) {
        return this.tree
          .getTreeData()
          .map(v => {
            return {
              id: v.id,
              name: v.name
            };
          })
          .filter(v => v.name.indexOf(query) > -1)
          .slice(0, 200);
      }
      return [];
    },
    getVehicleNo(query = "") {
      if (this.nodeData) {
        return this.nodeData
          .filter(
            v =>
              (v.data.lastStage || v.data.last) &&
              v.data.name.toLowerCase().indexOf(query.toLowerCase()) > -1
          )
          .slice(0, 200)
          .map(v => {
            const parent = v.parent.level === 1 ? v.parent : v.parent.parent;
            return { id: v.data.id, name: v.data.name, tips: parent.data.name };
          });
      }
      return [];
    },
    getTerminalNo(query = "") {
      if (this.nodeData) {
        return this.nodeData
          .filter(
            v =>
              (v.data.lastStage || v.data.last) &&
              v.data.properties &&
              v.data.properties.terminalNo &&
              v.data.properties.terminalNo
                .toLowerCase()
                .indexOf(query.toLowerCase()) > -1
          )
          .slice(0, 200)
          .map(v => {
            return {
              id: v.data.id,
              name: v.data.properties.terminalNo,
              tips: v.data.name
            };
          });
      }
      return [];
    },
    getOptions(query) {
      if (this.condition === "vehicleNo") {
        return this.getVehicleNo(query);
      } else if (this.condition === "terminalNo") {
        return this.getTerminalNo(query);
      } else if (this.condition === "companyName") {
        return this.getCompanyList(query);
      }
      return [];
    },
    remoteMethod(query) {
      if (query !== "") {
        this.selectLoading = true;
        if (this.nodeData === null && this.tree) {
          this.nodeData = this.tree.getAllNodeData();
        }
        this.busOptions = this.getOptions(query);
        this.selectLoading = false;
      } else {
        this.busOptions = [];
      }
    },
    handleBusChange(value) {
      if (!value || !this.tree) {
        return;
      }
      const node = this.tree.getNode(value);
      if (node) {
        if (this.condition === "companyName") {
          // 当点击公司搜索结果，单独处理
          if (!node.checked) {
            this.tree.setCheckedKey(node.key, true, true);
            this.$nextTick(() => {
              this.tree.check(node.data);
            });
          }
        } else {
          this.tree.nodeClick(node.data, node);
        }
      }
      //定位车辆树形菜单位置
      if (!node.parent.expanded) {
        this.tree.loading(true);
        this.delay(500).then(() => {
          node.parent.expand();
          this.delay(3600).then(() => {
            this.tree.scrollIntoView(node.id);
          });
        });
      } else {
        this.tree.scrollIntoView(node.id);
      }
    },
    handleClear() {
      this.text = "";
      this.busOptions = [];
      this.change();
    },
    refresh() {
      // const checkedKeys = this.tree.getCheckedKeys();
      if (this.text) {
        this.text = "";
        this.change();
      }
      this.loading = true;
      // 刷新地图车辆数据
      this.$bus.$emit("refreshCars");
      this.tree &&
        this.tree.refresh().then(() => {
          this.nodeData = null;
          // this.tree.setCheckedKeys(checkedKeys);
          this.loading = false;
          this.$message({
            message: "刷新成功",
            type: "success"
          });
        });
    }
  }
};
</script>

<style lang="scss">
@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.search-container {
  display: flex;
  margin: 2px;

  input {
    border-radius: 0;
  }

  .settings,
  .menu,
  .refresh {
    cursor: pointer;
    padding: 0 10px;
    background-color: #f5f7fa;
    color: #909399;
    border: 1px solid #dcdfe6;

    display: flex;
    align-items: center;

    &:hover {
      background-color: #fff;
    }
  }

  .settings {
    border-right: none;
  }
  .menu,
  .refresh {
    border-left: none;
  }

  .refresh {
    border-radius: 0;
    &.loading {
      i {
        animation: spin 1s linear infinite;
      }
    }
  }
}
.v-popover {
  border-top: 0;
  border-color: #ddd;
  border-radius: 0;
  margin: 0;
  padding: 0;

  &[x-placement^="right"] {
    .popper__arrow {
      border-right-color: #ccc !important;
      &::after {
        border-right-color: #efefef !important;
      }
    }
  }

  &[x-placement^="bottom"] {
    .popper__arrow {
      border-bottom-color: #ccc !important;
      &::after {
        border-bottom-color: #efefef !important;
      }
    }
  }

  .title {
    border-top: 1px solid #ddd;
    padding: 8px 6px;
    background-color: #efefef;
  }

  .el-col {
    height: 36px;
    border-left: 1px solid #ddd;
    border-top: 1px solid #ddd;
    display: flex;
    align-items: center;
    justify-content: center;
    &:first-child {
      border-left: none;
    }
  }
}
</style>
