<template>
  <div class="simple-tree flex-vertical">
    <div class="search-form">
      <el-input
        size="small"
        prefix-icon="el-icon-search"
        clearable
        v-model="searchValue"
        placeholder="请输入区域名称"
        @input="change"
      ></el-input>
    </div>

    <tree ref="tree" :exclude="exclude" :toolbar="false" @select="select" />
  </div>
</template>

<script>
import tree from "../../components/Tree/region";
export default {
  components: {
    tree
  },
  props: {
    exclude: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      searchValue: "",
      caseSensitive: false
    };
  },
  watch: {
    exclude(v) {
      this.change(v);
    }
  },
  methods: {
    select(data) {
      this.$emit("node-click", data);
    },
    clearInput() {
      this.searchValue = "";
    },
    change(v) {
      this.$refs.tree.filter(v || this.searchValue);
    }
  }
};
</script>

<style lang="scss" scoped>
.simple-tree {
  user-select: none;
  height: 100%;

  .search-form {
    margin-bottom: 12px;
  }

  .car-tree {
    overflow-y: auto;
  }

  .el-form-item {
    margin-bottom: 15px;
  }
}
</style>
