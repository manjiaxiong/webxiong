<template>
  <div class="search-tree no-select">
    <search class="search-input" :mode="[]" placeholder="输入进行查询" :tree="tree" />
    <div class="btn-group">
      <el-button v-if="options.group" type="primary" size="mini" @click="open">新增分类</el-button>
      <el-button size="mini" :disabled="addRegionDisabled" @click="drawRegion">新增区域</el-button>
      <el-button type="danger" size="mini" v-if="addRegionDisabled" @click="exitEdit">退出编辑</el-button>
    </div>
    <tree ref="tree" :addRegionDisabled="addRegionDisabled" :params="options" />
  </div>
</template>

<script>
import Search from "../Search";
import Tree from "../../components/Tree/region";
export default {
  // eventBus: ["setAddRegionDisabled"],
  components: {
    Search,
    Tree
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    options() {
      return Object.merge(
        {
          group: true,
          scope: "region"
        },
        this.params
      );
    }
  },
  data() {
    return {
      addRegionDisabled: false,
      tree: null
    };
  },
  methods: {
    setAddRegionDisabled(b) {
      this.addRegionDisabled = b;
    },
    open() {
      this.$dialog.open(this.options.scope, "category", { pid: 0 });
    },
    drawRegion() {
      this.setAddRegionDisabled(true);
      this.$bus.$emit("drawRegion", 0);
    },
    exitEdit() {
      this.setAddRegionDisabled(false);
      this.$bus.$emit("stopEditRegion");
    }
  },
  mounted() {
    this.tree = this.$refs.tree;
  }
};
</script>

<style lang="scss" scoped>
.search-tree {
  user-select: none;
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100%;

  .search-input {
    padding: 10px;
  }

  .btn-group {
    padding-left: 12px;
    padding-bottom: 8px;
  }
}
</style>
