<template>
  <v-select ref="select" placeholder="请选择区域" v-model="region">
    <tree ref="tree" :toolbar="false" @select="select" />
  </v-select>
</template>

<script>
import Tree from "../../components/Tree/region";
import Select from "../../components/Select";
export default {
  components: {
    "v-select": Select,
    Tree
  },
  props: {
    value: {
      type: [Number, String],
      default: 0
    }
  },
  data() {
    return {
      region: ""
    };
  },
  watch: {
    value(v) {
      const ref = this.$refs.tree;
      if (v) {
        this.delay(100).then(() => {
          ref.setCurrentKey(v);
          const node = ref.getNode(v);
          if (node) {
            const { data } = node;
            if (data) {
              const { regionName } = data;
              if (regionName) {
                this.region = regionName;
              }
            }
          }
        });
      } else {
        this.region = "";
        ref.setCurrentKey(null);
      }
    }
  },
  methods: {
    select(data) {
      const { id, regionName } = data;
      if (id > 0 && regionName) {
        this.region = regionName;
        this.$emit("input", id);
      }
      this.$refs.select.hide();
    }
  }
};
</script>

<style lang="scss" scoped>
</style>
