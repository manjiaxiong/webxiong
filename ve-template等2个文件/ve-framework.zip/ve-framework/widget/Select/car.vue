<template>
  <v-select ref="select" placeholder="请选择车辆" v-model="data">
    <el-checkbox v-model="checkedAll" style="margin-left: 24px; margin-bottom: 3px;"
      >全选</el-checkbox
    >
    <tree ref="tree" :toolbar="false" :info="false" @select="select" />
  </v-select>
</template>

<script>
import Tree from "../../components/Tree/car";
import Select from "../../components/Select";
export default {
  components: {
    "v-select": Select,
    Tree
  },
  props: {
    value: {
      type: Array,
      default: []
    }
  },
  data() {
    return {
      checkedAll: false,
      data: ""
    };
  },
  watch: {
    value(v, o) {
      if (v.length === 0 && o.length === 0) {
        return false;
      }
      // console.log("watch", v, o);
      const ref = this.$refs.tree;
      if (ref) {
        if (v.length === 0) {
          this.data = "";
          // ref.setCurrentKey(null);
          ref.setCheckedKeys([]);
        }
      }
    },
    checkedAll(v) {
      const tree = this.$refs.tree;
      if (tree) {
        if (v) {
          const data = tree.getTreeData();
          if (data && data.length) {
            tree.setCheckedKeys(data.map(v => v.id));
          }
          // console.log(data);
        } else {
          tree.setCheckedKeys([]);
        }
        this.select();
      }
    }
  },
  methods: {
    setData(v) {
      const ref = this.$refs.tree;
      if (ref) {
        if (v && v.length) {
          if (v[0].refType) {
            const keys = v.map(v => v.refContent);
            this.delay(600).then(() => {
              ref.setCheckedKeys(keys);
              this.select();
            });
          }
        }
      }
    },
    formatData(v) {
      return v.length > 5 ? v.slice(0, 5).concat("...") : v;
    },
    select() {
      const tree = this.$refs.tree;
      const checkedData = tree
        .getCheckedKeys()
        .map(v => tree.getNode(v))
        .filter(v => v.parent && !v.parent.checked)
        .map(v => {
          return v.data
            ? {
                id: v.data.id,
                name: v.data.name,
                level: v.data.level
              }
            : null;
        });

      this.data = this.formatData(checkedData)
        .map(v => v.name || v)
        .join(", ");
      if (JSON.stringify(this.value) !== JSON.stringify(checkedData)) {
        this.$emit("input", checkedData);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
</style>
