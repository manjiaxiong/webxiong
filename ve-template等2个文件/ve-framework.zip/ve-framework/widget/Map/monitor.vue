<template>
  <div class="map no-select">
    <baidu-map
      class="canvas"
      :minZoom="5"
      @ready="ready"
      :zoom="$config.map.zoom"
      :center="$config.map.center"
      :scroll-wheel-zoom="true"
      :map-click="false"
    >
      <slot name="controls"></slot>
      <bm-scale anchor="BMAP_ANCHOR_BOTTOM_RIGHT" :offset="{ width: 10, height: 2 }"></bm-scale>

      <bm-navigation
        v-if="mapParams.navigation.show"
        :anchor="mapParams.navigation.anchor"
        :offset="mapParams.navigation.offset"
      ></bm-navigation>

      <bm-control
        v-if="mapParams.control.show"
        :anchor="mapParams.control.anchor"
        :offset="mapParams.control.offset"
      >
        <el-card class="v-card">
          <el-checkbox v-model="showVisionCar">显示所有车辆</el-checkbox>
          <el-checkbox v-model="showCarNo">显示车牌号</el-checkbox>
          <bm-distance-tool v-if="map" :map="map" class="v-ds-tool"></bm-distance-tool>
          <slot name="tools"></slot>
        </el-card>
      </bm-control>

      <bm-traffic-control
        v-if="mapParams.traffic.show"
        :anchor="mapParams.traffic.anchor"
        :offset="mapParams.traffic.offset"
      ></bm-traffic-control>

      <bm-legend
        v-if="mapParams.legend.show"
        :anchor="mapParams.legend.anchor"
        :offset="mapParams.legend.offset"
      />

      <v-marker
        v-if="allMarkers.length"
        ref="vmarker"
        :icon="icon"
        :markers="allMarkers"
        :showCarNo="showCarNo"
        :exclude="markerData.vehicleNo ? [markerData.vehicleNo] : []"
        :scope-filter="true"
        @click="open"
      ></v-marker>

      <bm-marker
        :key="index"
        v-for="(marker, index) in trackMarkers"
        :position="{ lng: marker.lng, lat: marker.lat }"
        :rotation="marker.direction * 2 - 90"
        :icon="getIcon(marker)"
        @click="open(marker)"
      >
        <bm-label
          v-if="showCarNo"
          :content="marker.vehicleNo"
          :offset="{ width: -18, height: 36 }"
          :position="{ lng: marker.lng, lat: marker.lat }"
          :labelStyle="{
            color: '#fff',
            fontSize: '14px',
            backgroundColor: 'rgba(128, 128, 128, .8)',
            borderColor: 'gray',
            padding: '0 4px 0 4px'
          }"
        />
      </bm-marker>

      <bm-marker
        v-if="markerData.vehicleNo && !trackKeys.includes(markerData.vehicleNo)"
        :position="{ lng: markerData.lng, lat: markerData.lat }"
        :rotation="markerData.direction * 2 - 90"
        :icon="getIcon(markerData)"
        :smoothMove="false"
        @click="open(markerData)"
      >
        <bm-label
          v-if="showCarNo"
          :content="markerData.vehicleNo"
          :offset="{ width: -20, height: 35 }"
          :position="{ lng: markerData.lng, lat: markerData.lat }"
          :labelStyle="{
            color: '#fff',
            fontSize: '14px',
            backgroundColor: 'rgba(128, 128, 128, .8)',
            borderColor: 'gray',
            padding: '1px 6px 1px 5px'
          }"
        />
      </bm-marker>

      <template>
        <div v-for="(item, key) in trackList" :key="key">
          <bm-polyline :path="item" stroke-color="blue" :stroke-opacity="0.5" :stroke-weight="5"></bm-polyline>
        </div>
      </template>
      <component v-if="overlay" :is="overlay" :show.sync="show" :data="markerData" />
    </baidu-map>
    <slot name="overlays"></slot>
  </div>
</template>

<script>
import { debounce } from "throttle-debounce";
import { getCars, getAllCars } from "../../api/monitor";
import carMixin from "../../mixins/car";
import { fixPosition } from "../../utils/map";
import { getCarIconBase64 } from "../../utils";
export default {
  eventBus: [
    "setCarIntoView",
    "onCarClick",
    "refreshCars",
    {
      CarChecked: "carCheckedChange",
      MESSAGE: "onPositionChange"
    }
  ],
  mixins: [carMixin],
  timers: {
    getCheckedCars: {
      time: 15000,
      autostart: true,
      repeat: true,
      isSwitchTab: true
    }
  },
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    allMarkers() {
      return this.showVisionCar ? this.allCars : this.markerList;
    },
    markerList() {
      return this.carKeys.map(v => this.carList[v]);
    },
    carKeys() {
      return Object.keys(this.carList);
    },
    trackKeys() {
      return Object.keys(this.trackList);
    },
    trackMarkers() {
      return this.trackKeys.map(v => {
        var data = this.trackList[v];
        if (data.length > 0) {
          return data[data.length - 1];
        }
      });
    },
    currentRowKey() {
      return this.markerData.vehicleNo || null;
    },
    overlay() {
      return this.mapParams.overlay || null;
    },
    mapParams() {
      return Object.merge(
        {
          legend: {
            show: true,
            anchor: "BMAP_ANCHOR_TOP_RIGHT",
            offset: { width: 15, height: 197 }
          },
          traffic: {
            show: true,
            anchor: "BMAP_ANCHOR_TOP_RIGHT",
            offset: { width: 100, height: 20 }
          },
          control: {
            show: true,
            anchor: "BMAP_ANCHOR_TOP_LEFT",
            offset: { width: 10, height: 10 },
            showAllCar: true,
            showLabel: true
          },
          navigation: {
            show: true,
            anchor: "BMAP_ANCHOR_TOP_RIGHT"
          }
        },
        this.params
      );
    },
    icon() {
      return this.mapParams.icon || this.defaultIcon;
    },
    showVisionCar: {
      get() {
        return this.showAllCar !== null
          ? this.showAllCar
          : this.mapParams.control.showAllCar;
      },
      set(v) {
        this.showAllCar = v;
      }
    },
    showCarNo: {
      get() {
        return this.showLabel !== null
          ? this.showLabel
          : this.mapParams.control.showLabel;
      },
      set(v) {
        this.showLabel = v;
      }
    }
  },
  data() {
    return {
      showAllCar: null,
      showLabel: null,
      allCars: [],
      markerData: {},
      show: false,
      map: null,
      BMap: null,
      defaultIcon: {
        0: {
          src: getCarIconBase64(0),
          width: 36,
          height: 20
        },
        1: {
          src: getCarIconBase64(1),
          width: 36,
          height: 20
        },
        2: {
          src: getCarIconBase64(2),
          width: 36,
          height: 20
        }
      }
    };
  },
  watch: {
    showVisionCar(v) {
      if (!v) {
        this.show = false;
      } else {
        if (this.allMarkers.length === 0) {
          // 如果还没有获取车辆数据，获取数据
          this.getCheckedCars();
        }
        if (!this.show) {
          this.markerData = {};
        }
      }
    }
  },
  methods: {
    refreshCars() {
      this.$timer.stop("getCheckedCars");
      this.getCheckedCars(false);
      this.$timer.start("getCheckedCars");
    },
    getIcon({ vehStatus, warningStatus }) {
      let data;
      if (
        warningStatus &&
        warningStatus == 1 &&
        (vehStatus == 1 || vehStatus == 2)
      ) {
        data = this.icon[parseInt(vehStatus) + 3];
      } else data = this.icon[vehStatus];

      if (data) {
        const { src, width, height } = data;
        return {
          url: src,
          size: {
            width: width || 36,
            height: height || 20
          }
        };
      }
    },
    getCheckedCars(flag = true) {
      if (!this.showVisionCar && this.carKeys.length === 0) {
        return;
      }
      if (this.showVisionCar) {
        getAllCars().then(data => {
          this.allCars = this.formatData(data, true);
        });
      } else {
        getCars(this.carKeys.join(",")).then(data => {
          this.formatData(data);
        });
      }
      // 通知树形菜单刷新数据
      if (flag) {
        this.$bus.$emit("carTreeRefresh");
      }
    },
    boundsChange() {
      if (this.show) {
        return false;
      }
      // 没有跟踪车辆并且不显示视野车辆
      if (this.func2 && !this.vision) {
        this.func2();
      }
    },
    ready({ BMap, map }) {
      map.addEventListener("moveend", this.moveend);
      map.addEventListener("zoomend", this.zoomend);
      this.map = map;
      this.BMap = BMap;
      this.getCheckedCars();
      this.func2 = debounce(500, () => {
        this.$refs.vmarker && this.$refs.vmarker.update();
      });
    },
    moveend({ target }) {
      this.boundsChange(target);
    },
    zoomend({ target }) {
      this.zoom = target.getZoom();
      this.boundsChange(target);
    },
    getMap() {
      return this.map;
    },
    markerOpen(data) {
      if (!data.address || data.address === "-") {
        const point = new this.BMap.Point(data.lng, data.lat);
        this.getAddress(point, res => {
          if (res.address) {
            this.$set(data, "address", res.address);
            this.open(data);
          } else {
            this.open(data);
          }
        });
      }
    },
    open(marker) {
      if (marker && marker.positionTime) {
        this.setViewport([marker]);
        this.markerData = marker;
        this.$nextTick(() => {
          this.delay(20).then(() => {
            this.show = true;
          });
        });
      }
    },
    setViewport(data) {
      if (!data) {
        data = this.formatPoints();
      }
      this.map &&
        this.map.setViewport(data, {
          // margins: [100, 100, 200, 100],
          zoomFactor: -1
        });
    },
    // 点击车辆，全局暴露
    onCarClick(data, vision) {
      if (!data) {
        return false;
      }
      if (vision || (data.properties && data.name)) {
        data = this.getCar(vision ? data.vehicleNo : data.name);
      }
      if (data && data.lat && data.lng) {
        if (data.address && data.address !== "-") {
          this.open(data);
        } else {
          this.markerOpen(data);
        }
      }
    },
    // 获取经纬度地址
    getAddress(point, func) {
      const geoc = new this.BMap.Geocoder();
      geoc.getLocation(point, func);
    },
    // websocket 接收到车辆信息，全局暴露
    onPositionChange(data) {
      const key = data.vehicleNo;
      // const time = Math.round(new Date(data.positionTime).getTime() / 1000);
      // const lastTime = this.lastTime[key] || 0;
      // if (time - lastTime < 1) {
      //   return false;
      // }
      if (Math.trunc(data.lat) === 0 || Math.trunc(data.lng) === 0) {
        return false;
      }
      // this.lastTime[key] = time;
      // console.log(data);
      if (!this.getCar(key)) {
        return false;
      }
      //修正坐标偏移
      data = fixPosition(data);
      if (this.trackList[key]) {
        this.updateTrackList({
          key,
          value: data
        });
      }
      // 更新车辆树形菜单状态
      this.updateCarData(data);
      // 获取经纬度地址
      const point = new this.BMap.Point(data.lng, data.lat);
      // console.log(data);
      const currentShow = this.show && key === this.markerData.vehicleNo;
      this.getAddress(point, res => {
        if (res.address) {
          data.address = res.address;
          this.updateCar(key, data);
        }
        if (currentShow) {
          this.delay(100).then(() => {
            this.open(data);
          });
        } else if (this.vision === key) {
          if (this.show) {
            this.delay(100).then(() => {
              this.open(data);
            });
          } else {
            this.setViewport([point]);
          }
        }
      });
    },
    //更新树形菜单数据
    updateCarData(data = {}, hasKey = false) {
      const { vehicleNo, driverName, vehStatus } = data;
      if (vehicleNo) {
        this.$bus.$emit("updateCarData", vehicleNo, {
          status: vehStatus,
          driverName: !hasKey ? undefined : driverName || ""
        });
      }
    },
    //格式化车辆数据
    formatData(data, checkExist = false, storage = true) {
      return data
        .filter(v => Math.trunc(v.lat) !== 0 && Math.trunc(v.lng) !== 0)
        .map(v => {
          v.address = "-";
          v = fixPosition(v);
          this.updateCarData(v);
          if (storage) {
            if ((checkExist && this.getCar(v.vehicleNo)) || !checkExist) {
              this.updateCar(v.vehicleNo, v);
            }
          }
          if (this.currentRowKey === v.vehicleNo) {
            if (this.show) {
              if (!this.vision) {
                this.markerOpen(v);
              }
            } else {
              this.setViewport([v]);
              this.markerData = v;
            }
          }
          return v;
        });
    },
    // 全局暴露，直接定位到车辆
    setCarIntoView(id) {
      id &&
        getCars(id).then(data => {
          if (data && data.length) {
            data = this.formatData(data, false, false);
            if (data.length) {
              this.onCarClick(data[0]);
            } else {
              this.$message.error("暂无车辆定位信息");
            }
          } else {
            this.$message.error("暂无车辆定位信息");
          }
        });
    },
    // 树形菜单复选框选中状态发生变化，全局暴露
    carCheckedChange(data) {
      const { isCar, checked, relationCars, localData } = data;
      if (checked) {
        if (!this.vision) {
          this.$bus.$emit("selectTrackTab", "location");
        }
        //是否直接点击跟踪车辆
        if (localData) {
          const point = new this.BMap.Point(localData.lng, localData.lat);
          this.getAddress(point, res => {
            if (res.address) {
              localData.address = res.address;
              this.updateCar(relationCars[0], localData);
            }
          });
        } else {
          getCars(relationCars.join(",")).then(data => {
            data = this.formatData(data);
            if (isCar) {
              if (data.length) {
                this.onCarClick(data[0]);
              } else {
                this.$message.error("暂无车辆定位信息");
              }
            }
          });
        }
      } else {
        // 复选框取消，同步更新地图和表格数据
        relationCars.forEach(v => {
          const carData = this.getCar(v);
          if (carData) {
            if (this.trackList[v]) {
              this.$bus.$emit("trackChange", { vehicleNo: v }, false);
            }
            if (this.markerData.vehicleNo === v) {
              if (this.show) {
                this.show = false;
              }
              this.markerData = {};
            }
            this.removeCarList(v);
          }
        });
        this.show = false;
      }
    }
  },
  destroyed() {
    if (this.map) {
      this.map.removeEventListener("moveend", this.moveend);
      this.map.removeEventListener("zoomend", this.zoomend);
    }

    //清除缓存数据
    this.setCarList({});
    this.setTrackList({});
    this.setVision("");
  },
  created() {
    if (window.devicePixelRatio !== 1) {
      this.$notify.warning(
        "当前浏览器缩放比例非100%可能会造成地图车辆位置错乱"
      );
    }
  },
  deactivated() {
    this.show = false;
  }
};
</script>

<style lang="scss" scoped>
.v-card {
  ::v-deep .el-card__body {
    padding: 5px 15px;
    display: flex;

    .el-checkbox {
      display: flex;
      align-items: center;
    }

    .v-ds-tool {
      margin-left: 15px;
    }
  }
}
</style>
