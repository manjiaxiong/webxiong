<template>
  <div class="map no-select">
    <baidu-map
      class="canvas"
      :minZoom="5"
      :zoom="zoom"
      :center="center"
      :scroll-wheel-zoom="true"
      :map-click="false"
      @ready="ready"
    >
      <bm-scale anchor="BMAP_ANCHOR_BOTTOM_RIGHT" :offset="{width: 10, height: 2}"></bm-scale>
      <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>
      <slot></slot>
    </baidu-map>
  </div>
</template>

<script>
export default {
  props: {
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    zoom() {
      return this.params.zoom || this.$config.map.zoom;
    },
    center() {
      return this.params.center || this.$config.map.center;
    }
  },
  data() {
    return {
      map: null,
      BMap: null
    };
  },
  methods: {
    ready({ map, BMap }) {
      this.map = map;
      this.BMap = BMap;
    },
    getViewport() {
      return this.map.getViewport();
    },
    setViewport(viewport) {
      return this.map.setViewport(viewport);
    },
    setCenter(point) {
      if (this.map && this.BMap && point && point.lat && point.lng) {
        this.map.setCenter(new this.BMap.Point(point.lng, point.lat));
      }
    }
  }
};
</script>
