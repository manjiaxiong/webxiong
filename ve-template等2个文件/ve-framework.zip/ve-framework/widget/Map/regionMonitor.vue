<template>
  <div class="map no-select">
    <baidu-map
      class="canvas"
      :minZoom="5"
      @ready="ready"
      :zoom="zoom"
      :center="center"
      :scroll-wheel-zoom="true"
      :map-click="false"
    >
      <bm-scale anchor="BMAP_ANCHOR_BOTTOM_RIGHT" :offset="{ width: 10, height: 2 }"></bm-scale>
      <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>

      <bm-control :offset="{ width: 10, height: 10 }">
        <el-card class="v-card">
          <el-checkbox v-model="showCarNo">显示车牌号</el-checkbox>
        </el-card>
      </bm-control>

      <v-marker
        v-if="markers && markers.length > 0"
        :markers="markers"
        :showCarNo="showCarNo"
        @click="open"
      ></v-marker>

      <template>
        <bm-circle
          v-if="regionType === 1"
          @load="load"
          :center="points.point"
          :radius="points.radius"
          stroke-color="blue"
          :stroke-opacity="0.5"
          :stroke-weight="2"
          :fill-opacity="out ? 0.6 : 0.3"
          :editing="false"
        ></bm-circle>

        <bm-polygon
          v-else-if="regionType && regionType !== 1"
          @load="load"
          :path="points"
          stroke-color="blue"
          :stroke-opacity="0.6"
          :stroke-weight="2"
          :fill-opacity="out ? 0.6 : 0.3"
          :editing="false"
        />
      </template>
      <component
        v-if="overlay2 && markerData.vehicleNo"
        :is="overlay2"
        :track="false"
        :show.sync="show"
        :data="markerData"
      />
    </baidu-map>
  </div>
</template>

<script>
import { throttle, debounce } from "throttle-debounce";
import { pointArray2String, fixPosition } from "../../utils/map";
export default {
  eventBus: ["onCarClick"],
  timers: {
    getScopeCars: {
      time: 15000,
      autostart: true,
      repeat: true,
      isSwitchTab: true
    }
  },
  props: {
    items: {
      type: Array,
      default: () => []
    },
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    out() {
      return this.params.out || false;
    },
    overlay2() {
      return this.params.overlay || null;
    },
    center() {
      return this.params.center || this.$config.map.center;
    },
    zoom() {
      return this.params.zoom || this.defaultZoom;
    }
  },
  data() {
    return {
      showCarNo: true,
      regionType: "",
      markers: [],
      points: [],
      carNo: "",
      overlay: null,
      markerData: {},
      defaultZoom: 8,
      show: false,
      map: null,
      BMap: null
    };
  },
  methods: {
    ready({ BMap, map }) {
      this.map = map;
      this.BMap = BMap;
      map.addEventListener("moveend", this.moveend);
      map.addEventListener("zoomend", this.zoomend);
      // map.addEventListener("resize", this.resize);
      if (!this.func) {
        this.func = debounce(1000, () => {
          this.$timer.stop("getScopeCars");
          this.delay(300).then(() => {
            this.getScopeCars();
            this.$timer.start("getScopeCars");
          });
        });
      }

      if (this.items.length) {
        const { regionType, regionName, points } = this.items[0];
        this.regionType = regionType;
        this.points = points;
      }
    },
    boundsChange(target) {
      if (this.func) {
        this.func();
      }
    },
    moveend({ target }) {
      this.boundsChange(target);
    },
    zoomend({ target }) {
      this.boundsChange(target);
    },
    // resize() {
    //   this.setViewport();
    // },
    load(overlay) {
      this.overlay = overlay;
      this.setViewport();
      // this.getScopeCars();
    },
    open(marker) {
      if (marker.positionTime) {
        this.markerData = marker;
        this.delay(10).then(() => {
          this.show = true;
        });
      }
    },
    setViewport() {
      const { overlay, regionType, map, points } = this;
      if (map) {
        if (regionType === 1) {
          const bounds = overlay.getBounds();
          map.setViewport([bounds.getSouthWest(), bounds.getNorthEast()], {
            zoomFactor: this.out ? -2 : 0
          });
        } else {
          map.setViewport(points, {
            zoomFactor: this.out ? -2 : 0
          });
        }
      }
    },
    getScopeCars() {
      if (!this.overlay) {
        return false;
      }
      const params = pointArray2String(this.overlay.getPath());
      this.$axios({
        url: this.out ? "/region/region/list/out" : "/region/region/list",
        method: "get",
        params
      }).then(data => {
        if (data) {
          const { carList: list, ...rest } = data;
          if (list) {
            this.markers = list.map(v => fixPosition(v));
          }
          this.$emit("render", rest, list);
        }
      });
      // console.log(params);
    },
    onCarClick(data, vision) {
      if (vision || (data.detail && data.name)) {
        data = this.getCar(vision ? data.vehicleNo : data.name);
      }
      // this.$bus.$emit("setAutoPan", true);
      this.open(data);
    }
  },
  destroyed() {
    if (this.map) {
      this.map.removeEventListener("moveend", this.moveend);
      this.map.removeEventListener("zoomend", this.zoomend);
      // this.map.removeEventListener("resize", this.resize);
    }
  },
  activated() {
    this.getScopeCars();
  },
  deactivated() {
    this.show = false;
  }
};
</script>

<style lang="scss" scoped>
.v-card {
  ::v-deep .el-card__body {
    padding: 10px 15px;
  }
}
</style>
