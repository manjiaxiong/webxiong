<template>
  <div class="map no-select">
    <baidu-map
      class="canvas"
      :minZoom="5"
      @ready="ready"
      :zoom="zoom"
      :center="center"
      :scroll-wheel-zoom="true"
      :map-click="false"
    >
      <bm-scale anchor="BMAP_ANCHOR_BOTTOM_RIGHT" :offset="{width: 10, height: 2}"></bm-scale>
      <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>

      <bm-control :offset="{width: 10, height: 10}">
        <bm-auto-complete :sugStyle="{zIndex: 1}" localSearch>
          <el-input v-model="keyword" :clearable="true" placeholder="请输入地名关键字"></el-input>
        </bm-auto-complete>
      </bm-control>

      <v-draw ref="draw" @drawEnd="drawEnd" @render="render"></v-draw>
    </baidu-map>
  </div>
</template>

<script>
const drawModeMap = {
  circle: 1,
  rectangle: 2,
  polygon: 3
};
export default {
  eventBus: [
    "drawRegion",
    "stopEditRegion",
    "editRegion"
  ],
  props: {
    showControl: {
      type: Boolean,
      default: false
    },
    formatter: {
      type: Function
    },
    params: {
      type: Object,
      default: () => ({})
    },
    tree: {
      type: Object,
      default: () => null
    }
  },
  computed: {
    center() {
      return this.params.center || this.$config.map.center;
    },
    zoom() {
      return this.params.zoom || this.$config.map.zoom;
    }
  },
  data() {
    return {
      keyword: "",
      markers: [],
      show: false,
      map: null,
      BMap: null,
      pid: 0,
      drawManager: null,
      data: null
    };
  },
  methods: {
    ready({ BMap, map }) {
      this.map = map;
      this.BMap = BMap;
    },
    setAddRegionDisabled(b) {
      if (this.tree) {
        this.tree.setAddRegionDisabled(b);
      }
      // this.$bus.$emit("setAddRegionDisabled", b);
    },
    openControl() {
      this.drawManager && this.drawManager.openControl();
    },
    closeControl() {
      this.drawManager && this.drawManager.closeControl();
    },
    resetRegion(overlay, points) {
      return () => {
        if (this.drawManager) {
          if (points.radius) {
            this.drawManager.drawCircle(points, overlay);
          } else {
            this.drawManager.drawPolygon(points, overlay);
          }
        }
      };
    },
    saveRegionEdit(a, b, overlay) {
      const { regionType, regionName, id, points } = this.data;
      if (id > 0) {
        let type = regionType;
        if (type === 2 && !Object.isEqual(points, overlay.getPath())) {
          type = 3;
        }
        let params = {
          title: "编辑区域",
          id,
          borderList: this.getOverlayPath(overlay),
          regionType: type,
          regionName,
          pid: 0
        };
        this.$dialog.open("region", "region", params);
      }
    },
    drawRegion(pid) {
      this.pid = pid;
      this.openControl();
    },
    stopEditRegion(b) {
      this.setAddRegionDisabled(b || false);
      this.removeContextMenu();
      this.closeControl();
      this.clearOverlays();
    },
    editRegion(data) {
      this.stopEditRegion(true);
      const { id, regionName, regionType, points } = data;
      let overlay = null;
      if (regionType === 1) {
        overlay = this.drawManager.drawCircle(points);
        const bounds = overlay.getBounds();
        this.map.setViewport([bounds.getSouthWest(), bounds.getNorthEast()]);
      } else {
        overlay = this.drawManager.drawPolygon(points);
        this.map.setViewport(points);
      }
      if (overlay) {
        // this.editOverlay = overlay;
        this.data = data;
        this.addContextMenu(
          [
            {
              name: "保存",
              callback: this.saveRegionEdit
            },
            {
              name: "重置",
              callback: this.resetRegion(overlay, points)
            }
          ],
          overlay
        );
      }
    },
    render(handler) {
      this.drawManager = handler;
      if (this.showControl) {
        this.openControl();
      }
    },
    removeContextMenu() {
      this.$refs.draw.removeContextMenu();
    },
    removeRegion(s, ss, marker) {
      this.removeContextMenu();
      this.map.removeOverlay(marker);
      this.openControl();
    },
    getOverlayPath(overlay) {
      let borderList = [];
      if (overlay.getCenter) {
        const point = overlay.getCenter();
        const radius = overlay.getRadius();
        [
          {
            name: "point",
            value: [point.lng, point.lat].join(",")
          },
          {
            name: "radius",
            value: Math.round(radius)
          }
        ].forEach(v => {
          borderList.push({
            borderName: v.name,
            borderValue: v.value
          });
        });
      } else if (overlay.getPath) {
        const paths = overlay.getPath();
        const { formatter } = this;
        if (formatter) {
          return formatter(paths);
        }
        paths.forEach(v => {
          borderList.push({
            borderName: "point",
            borderValue: [v.lng, v.lat].join(",")
          });
        });
      }
      return borderList;
    },
    saveRegion(a, b, overlay) {
      const { save } = this.$listeners;
      if (save) {
        this.stopEditRegion();
        this.$emit("save", overlay.getPath());
      } else {
        const mode = this.drawManager.getDrawingMode();
        let params = {
          borderList: this.getOverlayPath(overlay),
          regionType: drawModeMap[mode],
          pid: this.pid
        };
        this.$dialog.open("region", "region", params);
      }
    },
    clearOverlays() {
      // this.map && this.map.clearOverlays();
      if (this.map) {
        const overlays = this.map.getOverlays();
        // 保留marker标注点
        overlays.forEach(v => {
          if (typeof v.getPath === "function") {
            this.map.removeOverlay(v);
          }
        });
      }
    },
    addContextMenu(list, overlay) {
      return this.$refs.draw.addContextMenu(list, overlay);
    },
    drawEnd(e, { overlay }) {
      this.closeControl();
      if (overlay) {
        //创建右键菜单
        this.addContextMenu(
          [
            {
              name: "取消",
              callback: this.removeRegion
            },
            {
              name: "确定",
              callback: this.saveRegion
            }
          ],
          overlay
        );
      }
    }
  },
  destroyed() {
    this.setAddRegionDisabled(false);
  }
};
</script>
