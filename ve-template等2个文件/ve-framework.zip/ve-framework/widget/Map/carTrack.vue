<template>
  <div class="map no-select">
    <baidu-map
      class="canvas"
      :minZoom="5"
      @ready="ready"
      :zoom="zoom"
      :center="center"
      :scroll-wheel-zoom="true"
      :map-click="false"
    >
      <bm-scale anchor="BMAP_ANCHOR_BOTTOM_RIGHT" :offset="{ width: 10, height: 2 }"></bm-scale>
      <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>

      <!-- <bm-control :offset="{width: 10, height: 10}">
        <el-card class="v-card">
          <el-checkbox v-model="showLine">显示轨迹</el-checkbox>
        </el-card>
      </bm-control>-->

      <bm-marker
        :key="key"
        v-for="(marker, key) in cars"
        :position="{ lng: marker.lng, lat: marker.lat }"
        :rotation="2 * marker.direction - 90"
        :icon="getCarIcon(marker)"
        @click="open(marker)"
      >
        <bm-label
          :content="marker.vehicleNo"
          :offset="{ width: -18, height: 40 }"
          :position="{ lng: marker.lng, lat: marker.lat }"
          :labelStyle="{
            color: '#fff',
            fontSize: '14px',
            backgroundColor: 'rgba(128, 128, 128, .8)',
            borderColor: 'gray',
            padding: '0 4px 0 4px'
          }"
        />
      </bm-marker>

      <bm-polyline :path="points" stroke-color="blue" :stroke-opacity="0.5" :stroke-weight="3"></bm-polyline>

      <component v-if="overlay" :is="overlay" :track="false" :show.sync="show" :data="markerData" />
    </baidu-map>
  </div>
</template>

<script>
import { getCars } from "../../api/monitor";
import { fixPosition } from "../../utils/map";
import { getCarIconBase64 } from "../../utils";

// 默认获取车辆图标方法
const getCarIcon = ({ vehStatus }) => {
  return {
    url: getCarIconBase64(vehStatus),
    size: { width: 36, height: 20 }
  };
};
export default {
  props: {
    items: {
      type: Array,
      default: () => []
    },
    list: {
      type: Array,
      default: () => []
    },
    params: {
      type: Object,
      default: () => ({})
    }
  },
  timers: {
    getScopeCars: {
      time: 10000,
      autostart: true,
      repeat: true,
      isSwitchTab: true
    }
  },
  computed: {
    cars() {
      return this.positions.length ? this.positions : this.items;
    },
    leave() {
      return this.list.includes(this.carNo);
    },
    getCarIcon() {
      return this.params.getCarIcon || getCarIcon;
    },
    overlay() {
      return this.params.overlay || null;
    },
    center() {
      return this.params.center || this.$config.map.center;
    }
  },
  data() {
    return {
      positions: [],
      points: [],
      carNo: "",
      markerData: {},
      zoom: 8,
      show: false,
      map: null,
      BMap: null
    };
  },
  methods: {
    ready({ BMap, map }) {
      this.map = map;
      this.BMap = BMap;
      map.addEventListener("resize", this.resize);
      if (this.items.length) {
        const { vehicleNo, positions, points } = this.items[0];
        this.carNo = vehicleNo;
        if (positions && points) {
          this.positions = positions;
          this.points = points;
        } else {
          this.points.push(this.items[0]);
        }
      }
      this.setViewport();
    },
    resize() {
      this.setViewport();
    },
    open(marker) {
      if (marker.positionTime) {
        this.markerData = marker;
        this.delay(10).then(() => {
          this.show = true;
        });
      }
    },
    setViewport() {
      this.map &&
        this.cars.length &&
        this.map.setViewport(this.cars, {
          // margins: [100, 100, 200, 100],
          zoomFactor: -1
        });
    },
    getScopeCars() {
      if (this.carNo) {
        getCars(this.carNo).then(data => {
          if (data && data.length) {
            this.onPositionChange(data[0]);
          }
        });
      }
    },
    onPositionChange(data) {
      const key = data.vehicleNo;
      if (key !== this.carNo) {
        return false;
      }
      // const time = Math.round(new Date(data.positionTime).getTime() / 1000);
      // 过滤无效定位坐标
      if (Math.trunc(data.lat) === 0 || Math.trunc(data.lng) === 0) {
        return false;
      }
      // 修正坐标偏移
      data = fixPosition(data);
      this.positions = [data];
      this.points.push(data);
      const { lat, lng } = data;
      const geoc = new this.BMap.Geocoder();
      const point = new this.BMap.Point(lng, lat);
      geoc.getLocation(point, res => {
        if (res.address) {
          data.address = res.address;
        }
        if (this.show && key === this.markerData.vehicleNo) {
          this.delay(30).then(() => {
            this.open(data);
          });
        }
      });
      this.setViewport();
    }
  },
  destroyed() {
    if (this.map) {
      this.map.removeEventListener("resize", this.resize);
    }
    if (this.leave) {
      this.items[0].points = this.points;
      this.items[0].positions = this.positions;
    }
  },
  deactivated() {
    this.show = false;
  }
};
</script>

<style lang="scss" scoped>
.v-card {
  ::v-deep .el-card__body {
    padding: 10px 15px;
  }
}
</style>
