/*
 * @Author: yanhao
 * @Date: 2020-12-02 18:56:00
 * @LastEditTime: 2020-12-10 09:02:40
 * @LastEditors: Please set LastEditors
 * @Description: Paquete de idioma español
 * @FilePath: \lang\es.js
 */
const _tm = {
  routes: {

  },
  navbar: {
    logOut: "Desconectar",
    dashboard: "Hogar",
    updatePassword:"Cambia la contraseña",
    oldPass: 'Contraseña anterior',
    newPass: 'Nueva contraseña',
    confirmPass: 'Confirmar contraseña',
    theme: "Peladura",
    size: "Tamaño del diseño",
    navHome: 'Volver a la página de inicio',
    navMode: 'Modo de navegación',
    theme: 'Estilo del tema',
    background: 'Antecedentes del tema',
    otherSettings: 'Otros ajustes',
    menuLeft: 'Menú de la izquierda',
    menuTop: 'Menu principal',
    multiPage: 'Modo de varias pestañas',
    userMenu: 'Menú del Usuario',
  },
  login: {
    title: "Inicio de sesión del sistema",
    logIn: "Iniciar sesión",
    username: "Número de cuenta",
    password: "Contraseña",
    tip: 'Inicie sesión con la contraseña de la cuenta',
  },

  permission: {
    roles: "Tu autoridad",
  },

  common: {
    date: 'Fecha',
    roleFeat: '(Rol funcional)',
    roleData: '(Rol de datos)',
    dataType: 'Tipo de datos',
    type: 'Tipos de',
    desc: 'Descripción',
    yes: 'Si',
    no: 'No',
    day: 'Día',
    hour: 'Hora',
    to: 'A',
    show: 'Monitor',
    hide: 'Esconder',
    user: 'Usuario',
    role: 'Roles',
  },

  components: {
    message_0: 'Desbloquear usuario',
    message_1: 'Desbloquear',
    message_2: 'Haga clic en cargar',
    message_3: '',
    message_4: '',
    message_5: '',
    message_6: '',
    message_7: '',
    message_8: '',
    message_9: '',
    message_10: '',
  },

  table: {
    columns: {
      // user
      username: 'Cuenta de usuario',
      password: 'Contraseña',
      authorities: 'Rol de propiedad',
      organization: 'Organización',
      nickname: 'Nombre de usuario',
      mobile: 'Número de teléfono móvil',
      email: 'Email',
      enabled: 'Estado',
      locked: 'Esta bloqueado',
      createDate: 'Tiempo de creación',
      // log
      module: 'Módulo',
      operation: 'Operando',
      description: 'Contenido de la operación',
      detail: "Detalles de la operación",
      operator: 'Operador',
      cast: 'Pérdida de tiempo',
      time: 'Tiempo de funcionamiento',
      alias: 'Alias',
      tenant: 'Tipos de',
      remarks: 'Observaciones',
      remark: 'Observaciones',

      // resource
      menuName: 'Nombre del menú',
      resName: 'Nombre del recurso',
      menuType: 'Tipos de',
      menuPath: 'Ruta de recursos',
      menuIcon: 'Icono',
      tableName: 'Nombre de la tabla',
      engine: 'Tipo de motor',
      comments: 'Observaciones',
      createTime: 'Tiempo de creación',
      // group
      group: {
        organization: 'Nombre de la asociación',
        alias: 'Alias ​​de organización',
        tenant: 'Multiinquilino',
        type_0: 'Organización general',
        type_1: 'Multiinquilino',
        type_2: 'Inquilino',
        addChildren: 'Agregar suborganización'

      },

      // role
      role: {
        roleType: 'Tipos de',
        roleFeat: 'Rol funcional',
        roleData: 'Rol de datos',
        alias: 'Alias ​​de rol',
        remarks: 'Notas de rol',
      },
      // dict
      dict: {
        dictType: 'Tipo de diccionario',
        dictName: 'Nombre del diccionario',
        fieldType: 'Valor de campo',
        fieldName: 'Nombre del campo',
        fieldDesc: 'Campo Descripción',
        enableState: 'Estado habilitado',
        sort: 'Número de cola',
        state_0: 'No disponible',
        state_1: 'Habilitar',

      },

      // res
      res: {
        pathType: 'Tipo de ruta',
        method: 'Método de fondo',
        icon: 'Icono de recurso',
        hidden: 'Ya sea para mostrar',
        type1: 'Menú',
        type2: 'Enlace externo',
        type3: 'Botón',

      },

      seq: 'Número de serie',

    },
    actions: {
      detail: "Detalles",
      add: 'Añadir',
      append: 'Añadir',
      edit: "Editar",
      delete: "Eliminar",
      update: 'Modificar',
      search: 'Preguntar',
      addResource: 'Agregar recursos',
      resetPassword: 'Restablecer la contraseña',
      enable: 'Habilitar',
      disable: 'Inhabilitar',
      unlock: 'Desbloquear',
      addUser: 'Usuarios nuevos',
      addMenuChildren: 'Agregar subrecurso',
      generator: 'Generar codigo',
      print: 'Impresión',
      refresh: 'Actualizar',
      openAll: 'Expandir todo',
      zipAll: 'Desplegar todo',
      addOrganization: 'Agregar organización',
      addRole: 'Nuevo rol',
      setRole: 'Configuración de permisos',
      submit: 'Enviar',
      reset: 'Reiniciar',
      dict: {
        add: 'Nuevo tipo de diccionario de nodo raíz',
        edit: 'Tipo de edición',
        addChild: 'Nuevo subtipo',
        manage: 'Administrar claves',
      }
    },
    noData: 'Sin datos',
  },

  dialog: {
    cancel: 'Cancelar',
    save: 'Salvar',
    confirm: "Determinar",
    tip: 'Rápido',
    continueAsk: 'Si continuar?',
    title: {
      resourceIcon: 'Icono de recurso',
      resourceAdd: 'Agregar recursos',
      resourceEdit: 'Modificar recursos',
      dictCategory: 'Clasificación de diccionario',
      dictData: 'Datos del diccionario',
    },
    roleSettings: 'Configuración de permisos de rol',
    dataSettings: 'Configuración de permisos de datos',
    chartDetail: 'Detalles del gráfico',

  },

  forms: { // 不知道起啥名字
    dictType: 'Clasificación de diccionario'
  },

  excel: {
    export: "Exportar",
    selectedExport: "Exportar elementos seleccionados",
    placeholder: "Ingrese el nombre del archivo(defecto excel-list)"
  },

  tagsView: {
    refresh: "Actualizar",
    close: "Apagar",
    closeOthers: "Cerrar otro",
    closeAll: "Cierra todo"
  },

  errorPage: {
    401: 'Error al iniciar sesión, compruebe su información.',
    403: 'No se muestra contenido',
    404: 'Verifique si la URL que ingresó es correcta, haga clic en el botón a continuación para regresar a la página de inicio o enviar un informe de error'
  },
  // this.message(...)
  messages: {
    tip_0: 'Modo de desarrollo, no salte temporalmente',
    tip_1: 'Error de configuración del enlace del sistema',
    tip_2: 'Desarrollo del sistema, así que estad atentos',
    tip_3: 'La nueva contraseña y la contraseña actual no pueden ser iguales',
    tip_4: 'Las dos contraseñas ingresadas son inconsistentes',
    tip_5: 'Modificado correctamente, volverá a iniciar sesión',
    tip_6: 'El usuario se agregó correctamente',
    tip_7: 'Esta operación restablece la contraseña de inicio de sesión del usuario a 123456',
    tip_8: 'Contraseña restablecida con éxito!',
    tip_9: 'Esta operación deshabilitará al usuario, ¿quieres continuar?',
    tip_10: 'Esta operación desbloqueará al usuario, si desea continuar?',
    tip_11: 'Esta operación eliminará permanentemente el dato, ya sea para continuar?',
    tip_12: 'Eliminado con éxito!',
    tip_13: 'Elija al menos uno',
    tip_14: 'Esta operación deshabilitará la organización, ¿quieres continuar?',
    tip_15: 'Modificado con éxito!',
    tip_16: 'Agregado exitosamente!',
    tip_17: 'Consulte las condiciones de la consulta',
    tip_18: 'Error de formato de datos',
    tip_19: 'El tamaño del archivo de carga no puede exceder',
    tip_20: 'El archivo de carga solo puede ser',
    tip_21: 'El formato del archivo cargado es incorrecto',
    tip_22: 'formato!',
    tip_23: 'Datos importados correctamente',
    tip_24: 'Solo se puede cargar',
    tip_25: 'Archivos, y no más de',
    tip_26: 'Editar con éxito!',
    tip_27: 'Guardado exitosamente!',
    tip_28: 'Contraseña de desbloqueo incorrecta',
    tip_29: 'Establezca una contraseña de pantalla de bloqueo',
    tip_30: 'la contraseña no puede estar en blanco',
    tip_31: 'El rango de tiempo no puede exceder',
    tip_32: 'La hora de inicio no puede ser mayor que la hora de finalización',
    tip_33: 'La hora de finalización no puede ser menor que la hora de inicio.',
    tip_34: 'Usar la contraseña predeterminada del sistema',
    tip_35: '',
    tip_36: '',
    tip_37: '',
    tip_38: '',
    tip_39: '',


  },
  // 校验规则的message
  rules: {
    message_0: 'Ingrese la contraseña original',
    message_1: 'la contraseña no puede estar en blanco',
    message_2: 'La longitud no es inferior a 6 caracteres.',
    message_3: 'Ingrese la cuenta de usuario',
    message_4: 'La cuenta de usuario no puede estar vacía',
    message_5: 'La cuenta de usuario no puede ingresar chino',
    message_6: 'El rol propietario no puede estar vacío',
    message_7: 'Formato de número de teléfono incorrecto',
    message_8: 'Formato de correo electrónico incorrecto',
    message_9: 'No puedo ingresar chino',
    message_10: 'El tipo de diccionario no puede estar vacío',
    message_11: 'El nombre del diccionario no puede estar vacío',
    message_12: 'Seleccione el estado de inicio',
    message_13: 'Se requiere el número de clasificación',
    message_14: 'Se requiere el tipo de diccionario',
    message_15: 'Seleccione la hora de finalización',
    message_16: 'Seleccione la hora de inicio',
    message_17: 'Más',
    message_18: 'Pequeño',
    message_19: 'Grande',
    message_20: 'No puede estar vacío',
    message_21: 'No tiene el formato correcto',
    message_22: 'El valor mínimo es',
    message_23: 'El valor máximo es',
    message_24: 'El rango de valores es',
    message_25: 'Seleccione el estado habilitado',
    message_26: '',
    message_27: '',
    message_28: '',
    message_29: '',
    message_30: '',
    message_31: '',


  },

  placeholders: {
    message_0: 'Seleccione el rol',
    message_1: 'Seleccione una organización',
    message_2: 'Ingrese el nombre de usuario',
    message_3: 'Por favor ingrese el numero de telefono',
    message_4: 'Por favor ingrese su correo electrónico',
    message_5: 'Nombre de la tabla',
    message_6: 'Nombre del módulo',
    message_7: 'Nombre del operador',
    message_8: 'Tipo de operación',
    message_9: 'Por favor ingrese una nota',
    message_10: 'Ingrese el nombre de una organización',
    message_11: 'Ingresa un alias de organización',
    message_12: 'Ingrese el alias del rol',
    message_13: 'Ingrese los comentarios del rol para identificar las características del rol, las personas aplicables, etc.',
    message_14: 'Utilice alias chinos para distinguir roles',
    message_15: 'Nombre del campo',
    message_16: 'Ingrese el tipo de diccionario',
    message_17: 'Ingrese el nombre del diccionario',
    message_18: 'Nombre del diccionario',
    message_19: 'Ingrese el valor del campo',
    message_20: 'Ingrese el número de clasificación',
    message_21: 'Ingrese una descripción',
    message_22: 'Por favor introduzca la contraseña',
    message_23: 'Mes de inicio',
    message_24: 'Fecha de inicio',
    message_25: 'Mes final',
    message_26: 'Fecha final',
    message_27: 'Por favor elige',
    message_28: 'Tiempo de empezar',
    message_29: 'Hora de finalización',
    message_30: 'Elija rango de tiempo',
    message_31: 'Período de selección',
    message_32: 'Seleccione fecha',
    message_33: 'Introduzca el estilo del icono o haga clic en el botón de la derecha para seleccionar',
    message_34: 'Ingrese el método de fondo',
    message_35: 'Ingrese el nombre del recurso',
    message_36: 'Ingrese la ruta del recurso',
    message_37: 'Introduzca comentarios de campo',
    message_38: 'Ingrese el nombre del campo',
    message_39: '',
    message_40: '',
    message_41: '',
    message_42: '',
    message_43: '',


  }
};


export default {
  _tm
}
