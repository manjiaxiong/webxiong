/*
 * @Author: yanhao
 * @Date: 2020-12-02 18:56:00
 * @LastEditTime: 2020-12-10 19:12:55
 * @LastEditors: Please set LastEditors
 * @Description: 英文语言包
 * @FilePath: \lang\en.js
 */
const _tm = {
  routes: {

  },
  navbar: {
    logOut: "Log Out",
    dashboard: "Dashboard",
    updatePassword: "Update Password",
    oldPass: 'Original Password',
    newPass: 'New Password',
    confirmPass: 'Confirm Password',
    theme: "Theme",
    size: "Global Size",
    navHome: 'Back To Home',
    navMode: 'Navigation Mode',
    background: 'Background',
    otherSettings: 'Other Settings',
    menuLeft: 'Left Menu',
    menuTop: 'Top Menu',
    multiPage: 'Multi Tab',
    userMenu: 'User Menu',
  },
  login: {
    title: "Login Form",
    logIn: "Log in",
    username: "Username",
    password: "Password",
    tip: 'Please log in with account password',

  },

  permission: {
    roles: "Your roles",

  },

  common: {
    date: 'Date',
    roleFeat: '(Functional Role)',
    roleData: '(Data Role)',
    dataType: 'Data Type',
    type: 'Type',
    desc: 'Description',
    yes: 'Yes',
    no: 'No',
    day: 'Day',
    hour: 'Hour',
    to: 'To',
    show: 'Show',
    hide: 'Hide',
    user: 'User',
    role: 'Role',
  },

  components: {
    message_0: 'Unlock User',
    message_1: 'Unlock',
    message_2: 'Click Upload',
    message_3: '',
    message_4: '',
    message_5: '',
    message_6: '',
    message_7: '',
    message_8: '',
    message_9: '',
    message_10: '',
  },

  table: {
    columns: {
      // user
      username: 'User Account',
      password: 'User Password',
      authorities: 'Role',
      organization: 'Organization',
      nickname: 'Nickname',
      mobile: 'Mobile',
      email: 'Email',
      enabled: 'Status',
      locked: 'Locked',
      createDate: 'CreateDate',
      // log
      module: 'Module',
      operation: 'Operation',
      description: 'Description',
      detail: "Detail",
      operator: 'Operator',
      cast: 'Time Consuming',
      time: 'Operating Time',
      alias: 'Alias',
      tenant: 'Type',
      remarks: 'Remarks',
      remark: 'Remarks',

      // resource
      menuName: 'Menu Name',
      menuType: 'Type',
      menuPath: 'Resource Path',
      menuIcon: 'Icon',
      tableName: 'Table Name',
      engine: 'Engine Type',
      comments: 'Comments',
      createTime: 'CreateTime',
      resName: 'Resource Name',
      // group
      group: {
        organization: 'Organization',
        alias: 'Alias',
        tenant: 'Multi-tenant',
        type_0: 'General Organization',
        type_1: 'Multi-tenant',
        type_2: 'Tenant',
        addChildren: 'Add Sub-organization'
      },

      // role
      role: {
        roleType: 'Type',
        roleFeat: 'Functional Role',
        roleData: 'Data Role',
        alias: 'Alias',
        remarks: 'Remarks',
      },
      // dict
      dict: {
        dictType: 'Type',
        dictName: 'Name',
        fieldType: 'FieldType',
        fieldName: 'FieldName',
        fieldDesc: 'FieldDesc',
        enableState: 'EnableState',
        sort: 'Sort',
        state_0: 'Not Enabled',
        state_1: 'Enabled',

      },

      // res
      res: {
        pathType: 'Type',
        method: 'Method',
        icon: 'Icon',
        hidden: 'Whether To Show',
        type1: 'Menu',
        type2: 'Link',
        type3: 'Button',

      },

      seq: 'NO.',


    },
    actions: {
      detail: "Detail",
      add: 'Add',
      append: 'AddTo',
      edit: "Edit",
      delete: "Delete",
      update: 'Update',
      search: 'Search',
      addResource: 'AddResource',
      resetPassword: 'ResetPassword',
      enable: 'Enable',
      disable: 'Disable',
      unlock: 'Unlock',
      addUser: 'AddUser',
      addMenuChildren: 'Add SubResource',
      generator: 'Generate code',
      print: 'Print',
      refresh: 'Refresh',
      openAll: 'Expand All',
      zipAll: 'Collapse All',
      addOrganization: 'Add Organization',
      addRole: 'New Role',
      setRole: 'Permission Settings',
      submit: 'Submit',
      reset: 'Reset',
      dict: {
        add: 'New Root Node Dictionary Type',
        edit: 'Edit',
        addChild: 'New Subtype',
        manage: 'Manage Keys',
      }
    },
    noData: 'No Data',

  },

  dialog: {
    cancel: 'Cancel',
    save: 'Save',
    confirm: "Determine",
    tip: 'Prompt',
    continueAsk: 'Whether to continue?',
    title: {
      resourceIcon: 'Icon',
      resourceAdd: 'Add',
      resourceEdit: 'Edit',
      dictCategory: 'Dictionary classification',
      dictData: 'Dictionary data'
    },
    roleSettings: 'Role Permission Settings',
    dataSettings: 'Data Permission Settings',
    chartDetail: 'Chart Details',

  },

  forms: { // 不知道起啥名字
    dictType: 'Dictionary Classification'
  },


  excel: {
    export: "Export",
    selectedExport: "Export Selected Items",
    placeholder: "Please enter the file name(default excel-list)"
  },



  tagsView: {
    refresh: "Refresh",
    close: "Close",
    closeOthers: "Close Others",
    closeAll: "Close All"
  },

  errorPage: {
    401: 'Login failed, Please check your information！',
    403: 'No content displayed',
    404: 'Please check if the URL you entered is correct, Please click the button below to return to the homepage or send an error report'
  },
  // this.message(...)
  messages: {
    tip_0: 'Development mode, do not jump temporarily',
    tip_1: 'System link configuration error',
    tip_2: 'System development, So stay tuned',
    tip_3: 'The new password and the current password cannot be the same',
    tip_4: 'The two passwords entered are inconsistent',
    tip_5: 'Modified successfully, Will log in again',
    tip_6: 'The user is added successfully',
    tip_7: 'This operation resets the user login password to 123456',
    tip_8: 'Password reset successfully!',
    tip_9: 'This action will disable the user, Whether to continue?',
    tip_10: 'This operation will unlock the user, Whether to continue?',
    tip_11: 'This operation will permanently delete the piece of data, Whether to continue?',
    tip_12: 'Successfully deleted!',
    tip_13: 'Choose at least one',
    tip_14: 'This operation will disable the organization, Do you want to continue?',
    tip_15: 'Successfully modified!',
    tip_16: 'Added successfully!',
    tip_17: 'Please check query conditions',
    tip_18: 'Data format error',
    tip_19: 'Upload file size cannot exceed',
    tip_20: 'Upload file can only be',
    tip_21: 'The format of the uploaded file is incorrect',
    tip_22: 'format!',
    tip_23: 'Data imported successfully',
    tip_24: 'Can only upload',
    tip_25: 'Files, and no more than',
    tip_26: 'Edit successfully!',
    tip_27: 'Saved successfully!',
    tip_28: 'Incorrect unlock password',
    tip_29: 'Please set a lock screen password',
    tip_30: 'Password can not be blank',
    tip_31: 'Time range cannot exceed',
    tip_32: 'The start time cannot be greater than the end time',
    tip_33: 'The end time cannot be less than the start time',
    tip_34: 'When it is empty, the system default password is used',
    tip_35: '',
    tip_36: '',
    tip_37: '',
    tip_38: '',
    tip_39: '',


  },
  // 校验规则的message
  rules: {
    message_0: 'Please enter the original password',
    message_1: 'Password can not be blank',
    message_2: 'The length is not less than 6 characters',
    message_3: 'Please enter user account',
    message_4: 'User account cannot be empty',
    message_5: 'User account cannot enter Chinese',
    message_6: 'Owning role cannot be empty',
    message_7: 'Incorrect phone number format',
    message_8: 'Incorrect email format',
    message_9: `Can't input Chinese`,
    message_10: 'Dictionary type cannot be empty',
    message_11: 'Dictionary name cannot be empty',
    message_12: 'Please select start state',
    message_13: 'Sort number is required',
    message_14: 'Dictionary type is required',
    message_15: 'Please select the end time',
    message_16: 'Please select start time',
    message_17: 'The',
    message_18: 'Smallest',
    message_19: 'Largest',
    message_20: 'Can not be empty',
    message_21: 'Is not in the correct format',
    message_22: 'The minimum value is',
    message_23: 'The maximum value is',
    message_24: 'The range of values is',
    message_25: 'Please select the enabled state',
    message_26: '',
    message_27: '',
    message_28: '',
    message_29: '',
    message_30: '',
    message_31: '',


  },

  placeholders: {
    message_0: 'Please select the role',
    message_1: 'Please select an organization',
    message_2: 'Please enter user name',
    message_3: 'Please enter the phone number',
    message_4: 'Please enter email',
    message_5: 'Table name',
    message_6: 'Module name',
    message_7: 'Operator name',
    message_8: 'Operation type',
    message_9: 'Please enter a note',
    message_10: 'Please enter an organization name',
    message_11: 'Please enter an organization alias',
    message_12: 'Please enter the role alias',
    message_13: 'Please enter the role remarks to identify the characteristics of the role, applicable people, etc.',
    message_14: 'Use Chinese aliases to distinguish roles',
    message_15: 'Field Name',
    message_16: 'Please enter the dictionary type',
    message_17: 'Please enter the dictionary name',
    message_18: 'Dictionary name',
    message_19: 'Please enter field value',
    message_20: 'Please enter the sort number',
    message_21: 'Please enter a description',
    message_22: 'Please enter the password',
    message_23: 'Start month',
    message_24: 'Start date',
    message_25: 'End month',
    message_26: 'End date',
    message_27: 'Please choose',
    message_28: 'Starting time',
    message_29: 'End Time',
    message_30: 'Choose time range',
    message_31: 'Selection period',
    message_32: 'Select date',
    message_33: 'Please enter the icon style or click the button on the right to select',
    message_34: 'Please enter the background method',
    message_35: 'Please enter the resource name',
    message_36: 'Please enter the resource path',

    message_37: 'Please enter field remarks',
    message_38: 'Please enter the field name',
    message_39: '',
    message_40: '',
    message_41: '',
    message_42: '',
    message_43: '',


  }


};


export default {
  _tm
}
