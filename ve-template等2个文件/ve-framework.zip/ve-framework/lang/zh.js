/*
 * @Author: yanhao
 * @Date: 2020-12-02 18:56:00
 * @LastEditTime: 2020-12-09 20:33:05
 * @LastEditors: Please set LastEditors
 * @Description: 中文语言包
 * @FilePath: \lang\zh.js
 */
const _tm = {
  routes: {
    
  },
  navbar: {
    logOut: "退出登录",
    dashboard: "首页",
    updatePassword:"修改密码",
    oldPass: '原密码',
    newPass: '新密码',
    confirmPass: '确认密码',
    theme: "换肤",
    size: "布局大小",
    navHome: '返回首页',
    navMode: '导航模式',
    theme: '主题风格',
    background: '主体背景',
    otherSettings: '其它设置',
    menuLeft: '左侧菜单',
    menuTop: '顶部菜单',
    multiPage: '多页签模式',
    userMenu: '用户菜单',
  },
  login: {
    title: "系统登录",
    logIn: "登录",
    username: "账号",
    password: "密码",
    tip: '请使用账号密码登录',
  },
  
  permission: {
    roles: "你的权限",
  },

  common: {
    date: '日期',
    roleFeat: '(功能角色)',
    roleData: '(数据角色)',
    dataType: '数据类型',
    type: '类型',
    desc: '描述',
    yes: '是',
    no: '否',
    day: '天',
    hour: '小时',
    to: '至',
    show: '显示',
    hide: '隐藏',
    user: '用户',
    role: '角色',
  },
  
  components: {
    message_0: '解锁用户',
    message_1: '解锁',
    message_2: '点击上传',
    message_3: '',
    message_4: '',
    message_5: '',
    message_6: '',
    message_7: '',
    message_8: '',
    message_9: '',
    message_10: '',
  },
  
  table: {
    columns: {
      // user
      username: '用户账号',
      password: '登录密码',
      authorities: '所属角色',
      organization: '所属组织',
      nickname: '用户姓名',
      mobile: '手机号码',
      email: '电子邮箱',
      enabled: '状态',
      locked: '是否锁定',
      createDate: '创建时间',
      // log
      module: '模块',
      operation: '操作',
      description: '操作内容',
      detail: "操作详情",
      operator: '操作人',
      cast: '耗时',
      time: '操作时间',
      alias: '别名',
      tenant: '类型',
      remarks: '备注',
      remark: '备注',

      // resource
      menuName: '菜单名称',
      resName: '资源名称',
      menuType: '类型',
      menuPath: '资源路径',
      menuIcon: '图标',
      tableName: '表名',
      engine: '引擎类型',
      comments: '备注',
      createTime: '创建时间',
      // group
      group: {
        organization: '组织名称',
        alias: '组织别名',
        tenant: '是否多租户',
        type_0: '普通组织',
        type_1: '多租户',
        type_2: '租户',
        addChildren: '新增子组织'

      },

      // role
      role: {
        roleType: '类型',
        roleFeat: '功能角色',
        roleData: '数据角色',
        alias: '角色别名',
        remarks: '角色备注',
      },
      // dict
      dict: {
        dictType: '字典类型',
        dictName: '字典名称',
        fieldType: '字段值',
        fieldName: '字段名称',
        fieldDesc: '字段描述',
        enableState: '启用状态',
        sort: '排序号',
        state_0: '未启用',
        state_1: '启用',

      },

      // res
      res: {
        pathType: '路径类型',
        method: '后台方法',
        icon: '资源图标',
        hidden: '是否显示',
        type1: '菜单',
        type2: '外链',
        type3: '按钮',

      },
      
      seq: '序号',

    },
    actions: {
      detail: "详情",
      add: '新增',
      append: '添加',
      edit: "编辑",
      delete: "删除",
      update: '修改',
      search: '查询',
      addResource: '新增资源',
      resetPassword: '重置密码',
      enable: '启用',
      disable: '禁用',
      unlock: '解锁',
      addUser: '新增用户',
      addMenuChildren: '新增子资源',
      generator: '生成代码',
      print: '打印',
      refresh: '刷新',
      openAll: '全部展开',
      zipAll: '全部折叠',
      addOrganization: '新增组织',
      addRole: '新增角色',
      setRole: '权限设置',
      submit: '提交',
      reset: '重置',
      dict: {
        add: '新增根节点字典类型',
        edit: '编辑类型',
        addChild: '新增子类型',
        manage: '管理键值',
      }
    },
    noData: '暂无数据',
  },

  dialog: {
    cancel: '取消',
    save: '保存',
    confirm: "确定",
    tip: '提示',
    continueAsk: '是否继续?',
    title: {
      resourceIcon: '资源图标',
      resourceAdd: '新增资源',
      resourceEdit: '修改资源',
      dictCategory: '字典分类',
      dictData: '字典数据',
    },
    roleSettings: '角色权限设置',
    dataSettings: '数据权限设置',
    chartDetail: '图表详情',

  },

  forms: { // 不知道起啥名字
    dictType: '字典分类'
  },
  
  excel: {
    export: "导出",
    selectedExport: "导出已选择项",
    placeholder: "请输入文件名(默认excel-list)"
  },
  
  tagsView: {
    refresh: "刷新",
    close: "关闭",
    closeOthers: "关闭其它",
    closeAll: "关闭所有"
  },

  errorPage: {
    401: '登录失败，请检查您的信息！',
    403: '无显示内容',
    404: '请检查您输入的网址是否正确，请点击以下按钮返回主页或者发送错误报告'
  },
  // this.message(...)
  messages: {
    tip_0: '开发模式，暂不跳转',
    tip_1: '系统链接配置错误',
    tip_2: '系统开发中，敬请期待',
    tip_3: '新密码和当前密码不能相同',
    tip_4: '两次输入的密码不一致',
    tip_5: '修改成功，即将重新登录',
    tip_6: '用户添加成功',
    tip_7: '此操作将用户登录密码重置为 123456',
    tip_8: '重置密码成功!',
    tip_9: '此操作将禁用用户, 是否继续?',
    tip_10: '此操作将解锁用户, 是否继续?',
    tip_11: '此操作将永久删除该条数据, 是否继续?',
    tip_12: '删除成功!',
    tip_13: '"至少选择一项"',
    tip_14: '此操作将禁用组织, 是否继续?',
    tip_15: '修改成功!',
    tip_16: '添加成功!',
    tip_17: '请检查查询条件',
    tip_18: '数据格式错误',
    tip_19: '上传文件大小不能超过',
    tip_20: '上传文件只能是',
    tip_21: '上传文件内容格式不正确',
    tip_22: '格式!',
    tip_23: '数据导入成功',
    tip_24: '只能上传',
    tip_25: '文件，且不超过',
    tip_26: '编辑成功!',
    tip_27: '保存成功!',
    tip_28: '解锁密码错误',
    tip_29: '请设置锁屏密码',
    tip_30: '密码不能为空',
    tip_31: '时间范围不能超过',
    tip_32: '开始时间不能大于结束时间',
    tip_33: '结束时间不能小于开始时间',
    tip_34: '为空时采用系统默认密码',
    tip_35: '',
    tip_36: '',
    tip_37: '',
    tip_38: '',
    tip_39: '',


  },
  // 校验规则的message
  rules: { 
    message_0: '请输入原密码',
    message_1: '密码不能为空',
    message_2: '长度不小于6个字符',
    message_3: '请输入用户账号',
    message_4: '用户账号不能为空',
    message_5: '用户账号不能输入中文',
    message_6: '所属角色不能为空',
    message_7: '手机号码格式不正确',
    message_8: '电子邮箱格式不正确',
    message_9: '不能输入中文',
    message_10: '字典类型不能为空',
    message_11: '字典名称不能为空',
    message_12: '请选择启动状态',
    message_13: '排序号必填',
    message_14: '字典类型必填',
    message_15: '请选择结束时间',
    message_16: '请选择开始时间',
    message_17: '最',
    message_18: '小',
    message_19: '大',
    message_20: '不能为空',
    message_21: '的格式不正确',
    message_22: '的最小值为',
    message_23: '的最大值为',
    message_24: '的取值范围为',
    message_25: '请选择启用状态',
    message_26: '',
    message_27: '',
    message_28: '',
    message_29: '',
    message_30: '',
    message_31: '',


  },

  placeholders: {
    message_0: '请选择所属角色',
    message_1: '请选择所属组织',
    message_2: '请输入用户姓名',
    message_3: '请输入手机号码',
    message_4: '请输入电子邮箱',
    message_5: '表名称',
    message_6: '模块名称',
    message_7: '操作人姓名',
    message_8: '操作类型',
    message_9: '请输入备注',
    message_10: '请输入组织名称',
    message_11: '请输入组织别名',
    message_12: '请输入角色别名',
    message_13: '请输入角色备注以标识角色的特性，适用人群等',
    message_14: '使用中文别名以方便区分角色',
    message_15: '字段名称',
    message_16: '请输入字典类型',
    message_17: '请输入字典名称',
    message_18: '字典名称',
    message_19: '请输入字段值',
    message_20: '请输入排序号',  
    message_21: '请输入描述',  
    message_22: '请输入解屏密码',  
    message_23: '开始月份',  
    message_24: '开始日期',  
    message_25: '结束月份',  
    message_26: '结束日期',  
    message_27: '请选择',  
    message_28: '开始时间',  
    message_29: '结束时间',  
    message_30: '选择时间范围',  
    message_31: '选择时间',  
    message_32: '选择日期',  
    message_33: '请输入图标样式或点击右侧按钮选择',  
    message_34: '请输入后台方法',  
    message_35: '请输入资源名称',  
    message_36: '请输入资源路径',  
    
    message_37: '请输入字段备注',  
    message_38: '请输入字段名称',  
    message_39: '',  
    message_40: '',  
    message_41: '',  
    message_42: '',  
    message_43: '',  


  }
};


export default {
  _tm
}