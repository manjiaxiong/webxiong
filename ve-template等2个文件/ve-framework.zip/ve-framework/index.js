import Cookies from "js-cookie";
import axios from "axios";
import Element from "element-ui";
import "normalize.css/normalize.css"; // A modern alternative to CSS resets
import "font-awesome/css/font-awesome.css";
import "element-ui/lib/theme-chalk/index.css";
import "./styles/index.scss"; // global css
import i18n from "./lang"; // internationalization
import * as filters from "./filters"; // global filters
import { hasBtnPermission } from "./utils/permission";
import request from "./utils/request";
import DICT from "./utils/dict";
import { setTokenKey } from "./utils/auth";
import TmTable from "./components/TmTable/index";
import AutoTable from "./components/AutoTable/index";
import Pagination from "./components/Pagination/index";
import Screenfull from "./components/Screenfull/index";
import ScrollPane from "./components/ScrollPane/index";
import SuperMap from "./components/SuperMap/index";
import MapBox from "./components/MapBox/index";
import Icon from "./components/Icon";
import ResizeDetector from "./components/ResizeDetector";
import SearchForm from "./components/SearchForm";
import Dialog from "./components/Dialog";
import Form from "./components/Form";
import Collapse from "./components/Collapse";
// 树形表格elementUI 2.7.0 以上版本默认已支持，不需要引入其他组件
import Echarts from "./components/Echarts/index";
import RefreshMixin from "./mixins/global/refresh";
import TimerMixin from "./mixins/global/timer";
import iframeMixin from "./mixins/global/iframe";
import { setConfig, getConfig } from "./config";
import { router, store } from "./permission.js";
import Bootstrap from "./bootstrap";
import "./global";
import 'xe-utils'
import VXETable from 'vxe-table'
import 'vxe-table/lib/style.css'
import {startTimeoutListener} from './utils/timeoutLogout.js'

const components = [
  TmTable,
  AutoTable,
  Pagination,
  Screenfull,
  ScrollPane,
  SuperMap,
  MapBox,
  Echarts,
  Icon,
  ResizeDetector,
  SearchForm,
  Collapse,
  Dialog,
  Form
];
let Vue = null;
const install = function (vue, opts = {}) {
  Vue = vue;
  const { tokenKey } = opts;
  // 支持不同项目同时登录
  if (tokenKey) {
    setTokenKey(tokenKey);
  }
  // vxe-table
  Vue.use(VXETable)
  // 全局挂载
  Vue.use(Bootstrap);
  // 注入数据更新回调全局mixin
  Vue.mixin(RefreshMixin);
  // 注入定时器全局mixin
  Vue.mixin(TimerMixin);
  // 全局混入 iframe 页面相关
  Vue.mixin(iframeMixin);
  // 导入ElementUI
  Vue.use(Element, {
    size: Cookies.get("size") || "medium", // set element-ui default size
    i18n: (key, value) => i18n.t(key, value)
  });
  // 按钮权限控制
  Vue.use(hasBtnPermission);
  // register global utility filters
  Object.keys(filters).forEach(key => {
    Vue.filter(key, filters[key]);
  });

  // 注册全局组件
  components.forEach(component => {
    Vue.component(component.name, component);
  });

  // 兼容Echarts chart 别名 @compatible
  Vue.component("chart", Echarts);

  // 默认注入项目配置，可通过项目配置覆盖
  Vue.prototype.$config = getConfig();
  // 默认注入全局请求方法
  Vue.prototype.$axios = request;
  //默认注入字典
  Vue.prototype.$dict = DICT.getInstance();
  // 默认注入baseUrl
  Vue.prototype.$baseUrl = process.env.BASE_URL;
};

if (typeof window !== "undefined" && window.Vue) {
  install(window.Vue);
}

// 获取项目动态全局配置
function getServerConfig() {
  return axios({
    baseURL: "",
    method: "get",
    url: (Vue.prototype.$baseUrl || "./") + "serverConfig.json"
  }).then(({data:config}) => {
    let $config = Vue.prototype.$config;
    // 自动注入项目配置
    if (Vue && $config && typeof config === "object") {
      $config = Object.merge($config, config);
      Vue.prototype.$config = $config;
      // 设置全局配置
      setConfig($config);
    }
    // 设置全局baseURL
    if (!request.defaults.baseURL && $config.baseURL) {
      request.defaults.baseURL = $config.baseURL;
      Vue.prototype.$baseUrl  = $config.baseURL;
    }
    // 开始监听用户：长时间未操作退出登录
    startTimeoutListener()
    return $config;
  });
}

const VeFramework = {
  version: "1.0.0",
  install
};

export { VeFramework, router, store, request, i18n, getServerConfig };
